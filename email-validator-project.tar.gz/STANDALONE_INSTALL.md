# Installation Guide - Standalone Email Validator

There are multiple ways to use this standalone email validator, from zero-install to pip installation.

## 🚀 Method 1: Direct Download (No Installation)

**Fastest way to get started!**

1. Download just the script file:
   ```bash
   curl -O https://raw.githubusercontent.com/yourrepo/email-validator/main/email_validator_standalone.py
   ```

2. Make it executable (optional):
   ```bash
   chmod +x email_validator_standalone.py
   ```

3. Run it:
   ```bash
   python3 email_validator_standalone.py validate test@gmail.com
   ```

That's it! No dependencies, no installation, just download and run.

## 📦 Method 2: Install as Python Package

**For system-wide access**

1. Clone or download the repository:
   ```bash
   git clone https://github.com/yourrepo/email-validator.git
   cd email-validator
   ```

2. Install the package:
   ```bash
   pip install .
   ```

3. (Optional) Install with DNS support:
   ```bash
   pip install .[dns]
   ```

4. Now you can use it from anywhere:
   ```bash
   email-validator validate test@gmail.com
   email-validator bulk emails.csv
   email-validator interactive
   ```

## 🐍 Method 3: Use in Your Python Project

**For programmatic use**

1. Copy `email_validator_standalone.py` into your project

2. Import and use in your code:
   ```python
   from email_validator_standalone import EmailValidator
   
   # Validate single email
   result = EmailValidator.validate_email("user@example.com")
   print(f"Email: {result.email}")
   print(f"Deliverable: {result.is_deliverable}")
   print(f"Provider: {result.provider}")
   
   # Bulk validation
   emails = ["user1@gmail.com", "user2@outlook.com"]
   results = EmailValidator.validate_bulk(emails)
   
   for r in results:
       if r.is_deliverable:
           print(f"✅ {r.email} - {r.provider}")
   ```

## 🔧 Method 4: Virtual Environment (Recommended for Development)

**Isolated Python environment**

1. Create virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install (optional):
   ```bash
   pip install dnspython  # For better DNS lookups
   ```

3. Run the script:
   ```bash
   python email_validator_standalone.py validate test@example.com
   ```

## ☁️ Method 5: Run on Replit

**No local installation needed**

1. Go to [Replit](https://replit.com)
2. Create a new Python Repl
3. Upload `email_validator_standalone.py`
4. Run it in the shell:
   ```bash
   python email_validator_standalone.py validate test@gmail.com
   ```

## 🐳 Method 6: Docker Container (Advanced)

**Containerized execution**

1. Create a `Dockerfile`:
   ```dockerfile
   FROM python:3.11-slim
   
   WORKDIR /app
   COPY email_validator_standalone.py .
   
   # Optional: Install dnspython
   RUN pip install --no-cache-dir dnspython
   
   ENTRYPOINT ["python", "email_validator_standalone.py"]
   ```

2. Build the image:
   ```bash
   docker build -t email-validator .
   ```

3. Run it:
   ```bash
   docker run email-validator validate test@gmail.com
   docker run -v $(pwd):/data email-validator bulk /data/emails.csv
   ```

## 📋 Optional Dependencies

### dnspython (Recommended)

For better and more reliable MX record lookups:

```bash
pip install dnspython
```

The script will work without it, but DNS resolution will be limited to basic socket lookups.

## ✅ Verify Installation

Test that everything works:

```bash
# Method 1 (direct script)
python3 email_validator_standalone.py validate test@gmail.com

# Method 2 (installed package)
email-validator validate test@gmail.com

# Method 3 (programmatic)
python3 -c "from email_validator_standalone import EmailValidator; print(EmailValidator.validate_email('test@gmail.com'))"
```

Expected output should show:
- ✅ Valid format
- ✅ Deliverable
- Provider: Google

## 🚨 Troubleshooting

### "dnspython not installed" Warning

This is just a warning - the script will still work. Install dnspython for better results:
```bash
pip install dnspython
```

### Permission Denied

Make the script executable:
```bash
chmod +x email_validator_standalone.py
```

### Python Not Found

Ensure Python 3.7+ is installed:
```bash
python3 --version
```

If not installed:
- **Ubuntu/Debian**: `sudo apt install python3`
- **macOS**: `brew install python3`
- **Windows**: Download from [python.org](https://python.org)

### Import Error in Programmatic Use

Make sure the script is in your Python path or current directory:
```python
import sys
sys.path.append('/path/to/script')
from email_validator_standalone import EmailValidator
```

## 📱 Platform-Specific Notes

### Windows
- Use `python` instead of `python3`
- Use backslashes in paths: `python email_validator_standalone.py bulk C:\data\emails.csv`

### macOS
- Python 3 might be installed as `python3`
- You may need to install dnspython: `pip3 install dnspython`

### Linux
- Usually comes with Python 3 pre-installed
- May need to install pip: `sudo apt install python3-pip`

## 🎯 Quick Start Examples

After installation, try these commands:

```bash
# Single email
email-validator validate admin@company.com

# Bulk from CSV
email-validator bulk contacts.csv

# Interactive mode
email-validator interactive

# With custom output
email-validator bulk emails.csv --export results.csv --deliverable valid.txt
```

---

**Choose the method that works best for your workflow!** 🎉
