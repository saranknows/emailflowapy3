# main.py - Standalone Email Sender Guide

## Overview

`main.py` is a **standalone, self-contained email marketing sender** with all SMTP credentials **hardcoded** for easy deployment on Windows and other platforms. It requires **NO environment variables** or `.env` files.

## 🔒 IMPORTANT SECURITY WARNING

**⚠️ CREDENTIALS ARE HARDCODED IN THIS FILE**

- All SMTP credentials (username, password) are stored directly in `main.py`
- **NEVER share this file publicly or commit it to public repositories**
- **NEVER upload it to GitHub, GitLab, or any public source control**
- Keep this file secure with appropriate file permissions
- Only share with trusted personnel who need access
- Consider using encrypted storage when transferring this file

**For production use**, consider:
- Using environment variables instead
- Implementing a secure credential management system
- Encrypting sensitive credentials
- Using cloud secret management services (AWS Secrets Manager, Azure Key Vault, etc.)

## Quick Start

### Windows

**Option 1: Double-Click to Run**
```
Double-click RUN-EMAIL-SENDER.bat
```

**Option 2: Command Prompt**
```cmd
python main.py
```

### Mac/Linux

**Option 1: Shell Script**
```bash
chmod +x RUN-EMAIL-SENDER.sh
./RUN-EMAIL-SENDER.sh
```

**Option 2: Direct Python**
```bash
python3 main.py
```

## Configuration

All configuration is done by editing the `EMAIL_CONFIG` dictionary at the top of `main.py`. **No .env file needed!**

### 1. SMTP Provider Selection

```python
EMAIL_CONFIG = {
    'provider': 'ses',  # Options: 'ses' or 'smtp'
    ...
}
```

### 2. Amazon SES Configuration (Default - WORKING)

```python
# Amazon SES Configuration (WORKING - TESTED)
'ses_host': 'email-smtp.eu-central-1.amazonaws.com',
'ses_port': 587,
'ses_username': 'YOUR_SES_USERNAME',  # Hardcoded
'ses_password': 'YOUR_SES_PASSWORD',  # Hardcoded
```

**Current Status**: ✅ Configured and tested with verified email addresses  
**Success Rate**: 100% (8/8 emails sent successfully)

### 3. Generic SMTP Configuration (Alternative)

```python
# Generic SMTP Configuration (Alternative)
'smtp_host': 'smtp.gmail.com',
'smtp_port': 587,
'smtp_username': '',  # Fill in if using SMTP
'smtp_password': '',  # Fill in if using SMTP
```

### 4. Email Delay Configuration

```python
'delay_seconds': 2,  # Wait 2 seconds between emails
```

### 5. QR Code Configuration (Optional)

```python
# QR Code Configuration (Optional)
'enable_qr_code': False,  # Set to True to enable QR code embedding
'qr_code_data': '',  # URL or text to encode in QR code (e.g., 'https://example.com')
'qr_code_size': 300,  # Size of QR code in pixels (default: 300)
```

**To Enable QR Code Embedding:**

1. **Enable the feature**:
   ```python
   'enable_qr_code': True,
   ```

2. **Set the QR code data** (URL, text, contact info, etc.):
   ```python
   'qr_code_data': 'https://yourwebsite.com/special-offer',
   ```

3. **Optional: Adjust size**:
   ```python
   'qr_code_size': 250,  # Pixels (default: 300)
   ```

**Example Use Cases:**
- Landing page URLs: `'https://example.com/promo'`
- Contact information: `'mailto:contact@example.com'`
- Phone numbers: `'tel:+1234567890'`
- WiFi credentials: `'WIFI:T:WPA;S:NetworkName;P:Password;;'`
- Plain text: `'Special discount code: SAVE20'`

**How It Works:**
- QR code is automatically embedded at the bottom of each email
- Same QR code is used for all recipients
- Generated as base64-encoded PNG image
- No external files required
- High error correction for better scanning

### 6. SOCKS Proxy Configuration (Optional)

```python
# SOCKS Proxy Configuration (Optional)
'proxy_type': '',  # Options: 'socks5', 'socks4', 'http', or '' for no proxy
'proxy_host': '',  # Example: '127.0.0.1'
'proxy_port': '',  # Example: '1080'
'proxy_username': '',  # Optional
'proxy_password': '',  # Optional
```

**To Enable Proxy**, edit these values directly in main.py:
```python
'proxy_type': 'socks5',
'proxy_host': '127.0.0.1',
'proxy_port': '1080',
```

## File Structure Requirements

`main.py` expects the following folder structure:

```
your-project/
├── main.py                    ← The standalone sender
├── contacts/
│   └── emails.txt            ← One email per line
├── subjects/
│   ├── subject.txt           ← Subject lines (one per line)
│   └── subject2.txt          ← More subjects (optional)
├── from_emails/
│   └── fromemails.txt        ← Sender addresses (one per line)
└── templates/
    ├── default.html
    ├── template1-professional.html
    └── ...                   ← All your HTML templates
```

## Features

✅ **Fully Standalone** - No dependencies on environment variables or .env files  
✅ **Amazon SES Integration** - Pre-configured with working credentials  
✅ **Subject Line Rotation** - Automatically cycles through all subject lines  
✅ **Sender Email Rotation** - Rotates between verified sender addresses  
✅ **Template Rotation** - Cycles through all HTML templates  
✅ **SOCKS Proxy Support** - Optional SOCKS5/SOCKS4/HTTP proxy routing  
✅ **Progress Tracking** - Real-time console output with status  
✅ **Error Handling** - Detailed error messages and troubleshooting  

## How It Works

### 1. Loading Phase

When you run `main.py`, it:
1. Loads all contacts from `contacts/emails.txt`
2. Loads ALL subject lines from ALL `.txt` files in `subjects/` folder
3. Loads sender emails from `from_emails/fromemails.txt`
4. Loads ALL HTML templates from `templates/` folder
5. Creates rotation cycles for each category

### 2. Connection Phase

1. Connects to SMTP server (Amazon SES by default)
2. Establishes SOCKS proxy tunnel (if configured)
3. Authenticates with hardcoded credentials
4. Waits for your confirmation to start sending

### 3. Sending Phase

For each contact:
1. Selects **next subject** from rotation cycle
2. Selects **next sender email** from rotation cycle
3. Selects **next template** from rotation cycle
4. Composes the email
5. Sends the email
6. Waits for delay period before next email

### Example Output

```
============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 2 files
👤 Loaded 2 sender emails
🎨 Loaded 11 email templates

🔧 Using SES email provider
🌐 Direct connection (no proxy)

Press ENTER to start sending to 8 contacts...

🔌 Connecting to email-smtp.eu-central-1.amazonaws.com:587...
✅ Connected successfully!

📤 Starting to send emails...
------------------------------------------------------------
1/8 | To: user@example.com... | From: info@besthomeimprovement....
         Subject: Amazing Deal Inside!...
         Template: default.html
         ✅ Sent successfully

2/8 | To: user2@example.com... | From: admin@autoblog247.net...
         Subject: Don't Miss Out - Limited Time Offer...
         Template: template1-professional.html
         ✅ Sent successfully
...

------------------------------------------------------------

============================================================
   SENDING COMPLETE!
============================================================
✅ Successfully sent: 8
❌ Failed: 0
📊 Total contacts: 8
============================================================
```

## Troubleshooting

### Error: "Authentication Credentials Invalid"

**Solution**: Edit `main.py` and verify your SMTP credentials in the `EMAIL_CONFIG` section.

For Amazon SES:
```python
'ses_username': 'YOUR_ACTUAL_USERNAME',
'ses_password': 'YOUR_ACTUAL_PASSWORD',
```

### "No contacts found"

**Solution**: Create `contacts/emails.txt` with one email address per line:
```
user1@example.com
user2@example.com
user3@example.com
```

### "No subjects found"

**Solution**: Create `.txt` files in the `subjects/` folder:
```
subjects/promotional.txt
subjects/newsletter.txt
```

Each file should have one subject per line.

### "No sender emails found"

**Solution**: Create `from_emails/fromemails.txt` with sender emails:
```
sales@yourcompany.com
support@yourcompany.com
info@yourcompany.com
```

### "No templates found"

**Solution**: Add `.html` files to the `templates/` folder with your email HTML.

### Proxy Connection Issues

**Solutions**:
1. Verify proxy is running: `telnet proxy_host proxy_port`
2. Check proxy credentials in `EMAIL_CONFIG` in main.py
3. Try without proxy first (set `'proxy_type': ''`)
4. Make sure proxy type is correct (socks5, socks4, or http)

### Email Sending Fails

**For Amazon SES:**
1. Verify sender email addresses in AWS SES console
2. Verify recipient addresses (if in sandbox mode)
3. Check your AWS SES sending limits
4. Make sure account is not in SES sandbox for production

**For Gmail/Generic SMTP:**
1. Use App Passwords (not your regular password)
2. Enable "Less secure app access" if required
3. Check SMTP server settings are correct

## Rotation Behavior

### Subject Line Rotation

If you have 3 subject lines and 8 contacts:
- Email 1: Subject 1
- Email 2: Subject 2
- Email 3: Subject 3
- Email 4: Subject 1 (cycles back)
- Email 5: Subject 2
- And so on...

### Sender Email Rotation

If you have 2 sender addresses and 8 contacts:
- Email 1: sender1@domain.com
- Email 2: sender2@domain.com
- Email 3: sender1@domain.com (cycles back)
- Email 4: sender2@domain.com
- And so on...

### Template Rotation

Same cycling logic applies to HTML templates!

## Security Best Practices

1. **File Permissions**: Restrict access to `main.py`
   ```bash
   chmod 600 main.py  # Unix/Linux/Mac
   ```

2. **Never Share Publicly**: Don't upload to GitHub, forums, or public storage

3. **Secure Transfers**: When sharing `main.py`, use encrypted channels (encrypted email, secure file transfer)

4. **Credential Rotation**: Regularly rotate your SMTP credentials

5. **Access Logs**: Monitor who accesses the file on shared systems

6. **Encryption at Rest**: Store `main.py` in encrypted folders/drives when not in use

## Changing Email Provider

### Switch to Generic SMTP

1. Open `main.py` in a text editor
2. Change `'provider': 'ses'` to `'provider': 'smtp'`
3. Configure SMTP credentials:

```python
'smtp_host': 'smtp.gmail.com',  # Your SMTP server
'smtp_port': 587,               # Usually 587 or 465
'smtp_username': 'your@email.com',
'smtp_password': 'your_app_password',
```

### Gmail Configuration

For Gmail, use **App Passwords**:
1. Enable 2-factor authentication on your Google account
2. Go to Google Account → Security → App Passwords
3. Generate an app password for "Mail"
4. Use that password in `smtp_password`

## SOCKS Proxy Setup

### When to Use SOCKS Proxy

- Bypass network restrictions
- Route traffic through specific geographic locations
- Enhanced privacy and anonymity
- Corporate firewall traversal

### Enabling SOCKS Proxy

1. Start your SOCKS proxy server (e.g., SSH tunnel, commercial proxy service)

2. Edit `main.py` and configure proxy settings:

```python
'proxy_type': 'socks5',           # or 'socks4', 'http'
'proxy_host': '127.0.0.1',        # Proxy server address
'proxy_port': '1080',             # Proxy server port
'proxy_username': 'user',         # Optional authentication
'proxy_password': 'pass',         # Optional authentication
```

3. Run `main.py` - it will automatically route all SMTP traffic through the proxy

## Sending Best Practices

1. **Start with a small test**: Send to 5-10 contacts first
2. **Verify emails**: Make sure sender addresses are verified
3. **Check spam filters**: Test with different email providers
4. **Monitor sending**: Watch for errors and failed sends
5. **Respect limits**: Don't exceed your provider's sending limits
6. **Use delays**: Don't send too fast (2-5 seconds between emails)

## File Portability

This file is designed to be **completely portable**:

✅ Works on Windows, Mac, Linux  
✅ No environment variables needed  
✅ No `.env` file required  
✅ No external configuration  
✅ All credentials included  

Just copy `main.py` along with the folders (`contacts/`, `subjects/`, `from_emails/`, `templates/`) to any system with Python 3.9+ installed!

## Tested Configuration

✅ **Provider**: Amazon SES  
✅ **Region**: EU Central 1 (Frankfurt)  
✅ **Verified Senders**: 
- info@besthomeimprovement.biz
- admin@autoblog247.net

✅ **Test Results**: 8/8 emails sent successfully (100% success rate)  
✅ **Date Tested**: November 17, 2025  

## Related Documentation

- **`SOCKS-PROXY-SETUP.md`** - Detailed proxy setup guide
- **`test-send-emails.py`** - Test script for sending emails
- **`README.md`** - Project overview

## Support

For issues:
1. Check this guide first
2. Review error messages carefully
3. Test with `test-ses-connection.py`
4. Check provider documentation (AWS SES, Gmail, etc.)
5. Verify all files and folders exist

## Advanced Usage

### Custom Content

To customize email content, edit the templates in `templates/` folder. Use `{{content}}` as a placeholder:

```html
<html>
<body>
    <h1>Hello!</h1>
    {{content}}
    <p>Best regards,<br>Your Team</p>
</body>
</html>
```

The `{{content}}` will be replaced with your message.

### Multiple Subject Files

Create multiple .txt files in `subjects/` to organize subject lines:
- `subjects/promotional.txt` - Promotional subject lines
- `subjects/newsletter.txt` - Newsletter subjects
- `subjects/urgent.txt` - Urgent announcements

All will be loaded and rotated automatically!

---

**Remember**: This file contains sensitive credentials. Handle with care! 🔒

**Ready to send?** Just run `python main.py` and press ENTER! 🚀
