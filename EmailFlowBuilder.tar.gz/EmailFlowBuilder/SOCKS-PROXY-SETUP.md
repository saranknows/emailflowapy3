# SOCKS Proxy Setup Guide

## Overview

The Email Marketing Platform now supports SOCKS proxy for all email sending operations. This allows you to route SMTP traffic through a proxy server, which is useful for:

- Bypassing network restrictions or firewalls
- Routing traffic through specific servers
- Enhanced privacy and anonymity
- Accessing services from different geographic locations

## Supported Proxy Types

- **SOCKS5** (recommended) - Most feature-complete, supports authentication
- **SOCKS4** - Basic SOCKS support, no authentication
- **HTTP/HTTPS** - Standard HTTP proxy protocol

## Quick Setup

### Step 1: Configure Your Proxy Settings

Edit your `.env` file and add the following:

```bash
# SOCKS Proxy Configuration
PROXY_TYPE=socks5
PROXY_HOST=127.0.0.1
PROXY_PORT=1080
PROXY_USERNAME=your-username    # Optional
PROXY_PASSWORD=your-password    # Optional
```

### Step 2: Restart the Backend

After configuring your proxy settings:

```bash
cd backend
python3 app.py
```

Or restart the backend workflow in Replit.

### Step 3: Send Emails

All email sending will now automatically route through your SOCKS proxy. No code changes needed!

## Common Proxy Configurations

### Local SOCKS5 Proxy (SSH Tunnel)

Create an SSH tunnel to use as a SOCKS proxy:

```bash
ssh -D 1080 -N -f user@your-server.com
```

Then configure:
```bash
PROXY_TYPE=socks5
PROXY_HOST=127.0.0.1
PROXY_PORT=1080
```

### Remote SOCKS5 Proxy with Authentication

```bash
PROXY_TYPE=socks5
PROXY_HOST=proxy.example.com
PROXY_PORT=1080
PROXY_USERNAME=myusername
PROXY_PASSWORD=mypassword
```

### HTTP Proxy

```bash
PROXY_TYPE=http
PROXY_HOST=proxy.company.com
PROXY_PORT=8080
```

### No Proxy (Direct Connection)

Simply comment out or remove the proxy settings:

```bash
# PROXY_TYPE=socks5
# PROXY_HOST=127.0.0.1
# PROXY_PORT=1080
```

## Testing Your Configuration

Use the included test script to verify your proxy configuration:

```bash
python3 test-ses-connection.py
```

This will:
1. Check your Amazon SES credentials
2. Test the SOCKS proxy connection (if configured)
3. Send a test email through the proxy
4. Report any errors or issues

## How It Works

The system automatically detects proxy configuration from environment variables:

1. **No proxy configured** → Direct SMTP connection
2. **Proxy configured** → All SMTP traffic routed through proxy

This applies to:
- ✓ Amazon SES SMTP connections
- ✓ Generic SMTP server connections
- ✓ All email providers that use SMTP

## Troubleshooting

### Connection Timeout

**Problem**: SMTP connection times out

**Solutions**:
- Verify proxy server is running and accessible
- Check proxy host and port are correct
- Test proxy connection: `curl --socks5 proxy_host:proxy_port https://google.com`

### Authentication Failed

**Problem**: Proxy authentication fails

**Solutions**:
- Verify PROXY_USERNAME and PROXY_PASSWORD are correct
- Some proxies don't require authentication - remove username/password
- Try without authentication first to isolate the issue

### "Unknown proxy type" Warning

**Problem**: System doesn't recognize PROXY_TYPE

**Solutions**:
- Use only: `socks5`, `socks4`, or `http`
- Check for typos in PROXY_TYPE value
- Value is case-insensitive

### Proxy Works but Email Fails

**Problem**: Proxy connects but email sending fails

**Solutions**:
- This usually means proxy is working correctly
- Check Amazon SES credentials and verified addresses
- Verify you're not in SES sandbox or have verified senders
- Check backend logs for specific SMTP errors

## Security Considerations

### ✅ Best Practices

- Use SOCKS5 with authentication when possible
- Keep proxy credentials in `.env` file (never commit to git)
- Use encrypted connections (STARTTLS for SMTP)
- Regularly rotate proxy credentials
- Monitor proxy usage and access logs

### ⚠️ Important Notes

- Proxy credentials are stored in plaintext in `.env`
- Anyone with access to `.env` can use your proxy
- Free public proxies may log your traffic
- Use trusted proxy providers only

## Advanced Usage

### Dynamic Proxy Selection

Currently, the proxy is configured globally via environment variables. All SMTP connections use the same proxy.

**Future Enhancement**: Per-campaign proxy configuration could be added to the campaign settings.

### Proxy Rotation

To rotate between multiple proxies, you would need to:
1. Stop the backend
2. Update `.env` with new proxy settings
3. Restart the backend

**Future Enhancement**: Automatic proxy rotation based on a proxy pool.

### Monitoring Proxy Performance

Check backend logs for proxy connection messages:

```
INFO: Using SOCKS5 proxy 127.0.0.1:1080 for connection to email-smtp.us-east-1.amazonaws.com:587
```

## Technical Details

### Implementation

The platform uses the **PySocks** library to create SOCKS proxy connections. When a proxy is configured:

1. System reads proxy settings from environment variables
2. Creates a SOCKS socket using PySocks
3. Temporarily replaces Python's default socket with SOCKS socket
4. Establishes SMTP connection through the proxy
5. Restores original socket after connection

### Compatibility

- ✓ Python 3.9.9+
- ✓ Works with Amazon SES
- ✓ Works with any SMTP server
- ✓ Compatible with STARTTLS (port 587)
- ✓ Compatible with SSL/TLS (port 465)

## Example Use Cases

### 1. Bypass Corporate Firewall

Your office blocks SMTP ports 587 and 465. Use a SOCKS proxy:

```bash
PROXY_TYPE=socks5
PROXY_HOST=home-proxy.example.com
PROXY_PORT=1080
```

### 2. Route Through Specific Region

You want emails to appear from a specific geographic location:

```bash
PROXY_TYPE=socks5
PROXY_HOST=eu-proxy.example.com
PROXY_PORT=1080
```

### 3. Enhanced Privacy

Route through a privacy-focused proxy service:

```bash
PROXY_TYPE=socks5
PROXY_HOST=privacy-proxy.com
PROXY_PORT=1080
PROXY_USERNAME=user123
PROXY_PASSWORD=secret456
```

## Support

For issues or questions:
1. Check the backend logs for detailed error messages
2. Run `test-ses-connection.py` to diagnose issues
3. Verify proxy is accessible: `telnet proxy_host proxy_port`
4. Review ENV-SETUP-GUIDE.md for credential configuration

## Related Documentation

- `ENV-SETUP-GUIDE.md` - Environment variable configuration
- `.env.example` - All available configuration options
- `README-ENV-CONFIG.md` - Quick start guide for environment setup
- `test-ses-connection.py` - Connection testing script
