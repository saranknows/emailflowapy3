# Random Data Generation - Quick Start

## Overview
Automatically generate random names, emails, numbers, and dates in your email templates - just use the placeholders!

---

## 🎯 **Quick Reference**

| Placeholder | Example Output |
|-------------|----------------|
| `{{firstname}}` | Michael |
| `{{lastname}}` | Smith |
| `{{fullname}}` | John Williams |
| `{{email}}` | john.smith@gmail.com |
| `{{randomnumber}}` | 45821 |
| `{{phone}}` | (555) 123-4567 |
| `{{date}}` | 12/15/2025 |

---

## 💡 **How to Use**

### Just add placeholders to your template:

```html
<html>
<body>
    <h1>Hello {{firstname}}!</h1>
    <p>Your email: {{email}}</p>
    <p>Your ID: {{randomnumber}}</p>
    <p>Contact: {{phone}}</p>
    <p>Date: {{date}}</p>
</body>
</html>
```

### That's it! Placeholders are automatically replaced:

```html
<html>
<body>
    <h1>Hello Michael!</h1>
    <p>Your email: john.smith456@gmail.com</p>
    <p>Your ID: 45821</p>
    <p>Contact: (555) 123-4567</p>
    <p>Date: 12/15/2025</p>
</body>
</html>
```

---

## 📋 **All Available Placeholders**

### Names:
- `{{firstname}}` → James, Mary, Michael
- `{{lastname}}` → Smith, Johnson, Garcia
- `{{fullname}}` → John Williams
- `{{name}}` → Sarah Martinez (alias)

### Contact:
- `{{email}}` → john.smith@gmail.com
- `{{randomemail}}` → mary.j123@yahoo.com (alias)
- `{{phone}}` → (555) 123-4567

### Numbers:
- `{{randomnumber}}` → 45821 (1-99999)
- `{{number}}` → 3456 (1-9999)
- `{{id}}` → 67234 (10000-99999)

### Dates:
- `{{date}}` → 12/15/2025 (next 30 days)
- `{{randomdate}}` → 11/28/2025 (alias)

---

## ✅ **Features**

✅ **Zero Configuration** - Just use placeholders  
✅ **Automatic Replacement** - No code required  
✅ **Realistic Data** - From curated name/email pools  
✅ **Unique Per Email** - Each recipient gets different data  
✅ **50 First Names** - Diverse selection  
✅ **50 Last Names** - Common surnames  
✅ **10 Email Domains** - Gmail, Yahoo, Outlook, etc.  

---

## 📚 **Example Templates**

### DocuSign-Style:
```html
<p>Dear {{firstname}} {{lastname}},</p>
<p>Document ID: DOC-{{randomnumber}}</p>
<p>Due Date: {{date}}</p>
<p>Contact: {{phone}}</p>
```

### Marketing:
```html
<p>Hi {{firstname}}!</p>
<p>Your code: SAVE{{number}}</p>
<p>Email: {{email}}</p>
<p>Expires: {{date}}</p>
```

### Account Notification:
```html
<p>Hello {{fullname}},</p>
<p>Account: {{email}}</p>
<p>Reference: {{id}}</p>
<p>Date: {{date}}</p>
```

---

## 🔧 **7 Core Functions** (Python)

If you need to call them directly:

```python
from main import (
    generate_random_firstname,   # → 'Michael'
    generate_random_lastname,    # → 'Smith'
    generate_random_fullname,    # → 'John Williams'
    generate_random_email,       # → 'john.smith@gmail.com'
    generate_random_number,      # → 45821
    generate_random_phone,       # → '(555) 123-4567'
    generate_random_date         # → '12/15/2025'
)
```

---

## 📖 **Full Documentation**

For complete details, see **RANDOM-DATA-GENERATION-GUIDE.md**

---

**12 automatic placeholders ready to use in your templates!** 🎲
