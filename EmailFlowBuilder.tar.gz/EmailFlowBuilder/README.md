# Email Marketing Platform

A comprehensive email marketing sender platform with Python 3.9.9 backend, React frontend, and advanced rotation features.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.9.9-green)
![Node](https://img.shields.io/badge/node-20.x-green)

## 🚀 Quick Start

### Option 1: Use the Web Interface (Recommended)

**Windows:**
```cmd
start-all.bat
```

**Mac/Linux:**
```bash
chmod +x start-all.sh
./start-all.sh
```

Then open http://localhost:5000 in your browser.

### Option 2: Use main.py (Standalone Command-Line Sender)

> **🔒 SECURITY WARNING**: `main.py` contains hardcoded SMTP credentials for easy deployment. **Never share this file publicly or commit it to public repositories**. Keep it secure and handle with care.

**Windows:**
```cmd
python main.py
```
Or double-click `RUN-EMAIL-SENDER.bat`

**Mac/Linux:**
```bash
python3 main.py
```
Or run `./RUN-EMAIL-SENDER.sh`

📖 **See [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md)** for detailed instructions on using the command-line sender.

## 📋 Prerequisites

- Python 3.9.9
- Node.js 20.x or higher
- npm (comes with Node.js)

## 📦 Installation

See **[INSTALL.md](INSTALL.md)** for complete installation instructions for Windows, Mac, and Linux.

Quick install:
```bash
# Install Python dependencies
pip install -r requirements.txt

# Install Node.js dependencies
npm install

# Run the application
./start-all.sh       # Mac/Linux
start-all.bat        # Windows
```

## ✨ Features

- ✅ **Email Campaign Builder** - Create and manage campaigns
- ✅ **Contact List Management** - Upload CSV/TXT files with drag-and-drop
- ✅ **Subject Line Upload** - Upload subject files directly through UI
- ✅ **From Email Upload** - Upload sender address files
- ✅ **Subject Line Rotation** - Auto-rotate through different subjects
- ✅ **From Email Rotation** - Rotate sender addresses
- ✅ **Template Rotation** - 10 professional email templates with auto-rotation
- ✅ **QR Code Generation** - Embed dynamic QR codes in emails (URLs, contact info, WiFi, text)
- ✅ **Multi-Provider Support** - Amazon SES, Resend, or SMTP
- ✅ **SOCKS Proxy Support** - Route emails through SOCKS5/SOCKS4/HTTP proxies
- ✅ **Bulk Sending** - Send to thousands with configurable delays
- ✅ **Real-time Dashboard** - Monitor sending progress
- ✅ **Campaign Scheduling** - Schedule campaigns for future
- ✅ **Secure File Uploads** - Sanitized and validated uploads
- ✅ **Standalone Sender** - Command-line script (`main.py`) with full rotation support

## 🎨 10 Professional Email Templates

The platform includes 10 pre-built professional templates:

1. **Professional** - Clean business communication
2. **Modern** - Contemporary gradient design
3. **Minimal** - Simple, focused layout
4. **Corporate** - Formal executive style
5. **Newsletter** - Friendly newsletter format
6. **Promotional** - Eye-catching promotional design
7. **Elegant** - Sophisticated gold-accent style
8. **Tech** - Technical/developer themed
9. **Friendly** - Casual, approachable tone
10. **Announcement** - Official announcement format

## 📁 Project Structure

```
email-marketing-platform/
├── backend/           # Python Flask API (Port 8000)
├── frontend/          # React Application (Port 5000)
├── subjects/          # Subject line files
├── from_emails/       # Sender email files
├── contacts/          # Contact lists
├── templates/         # Email HTML templates (10 included)
├── campaigns/         # Campaign configurations
└── requirements.txt   # Python dependencies
```

## 🔧 Configuration

Create a `.env` file in the `backend` folder:

```env
# Amazon SES (Recommended)
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your_username
SES_SMTP_PASSWORD=your_password

# Resend (Alternative)
RESEND_API_KEY=your_api_key

# Generic SMTP (Alternative)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

## 🎯 How to Use

1. **Start the servers** using the start scripts
2. **Upload Contacts** - Go to Contacts page and upload email lists
3. **Add Subjects** - Upload or create subject line files
4. **Configure Senders** - Upload or add sender email addresses
5. **Create Campaign** - Combine elements into a campaign
6. **Send** - Start sending with automatic rotation

## 🌐 Access Points

- **Frontend Dashboard**: http://localhost:5000
- **Backend API**: http://localhost:8000
- **API Health Check**: http://localhost:8000/api/health

## 📊 API Endpoints

```
GET  /api/stats                - Get statistics
GET  /api/subjects             - List subject files
POST /api/subjects/upload      - Upload subject file
GET  /api/from-emails          - List from email files
POST /api/from-emails/upload   - Upload from email file
GET  /api/contacts             - List contact lists
POST /api/contacts/upload      - Upload contact list
GET  /api/templates            - List templates
GET  /api/campaigns            - List campaigns
POST /api/send-campaign        - Send campaign
GET  /api/sending-status       - Get sending status
POST /api/stop-sending         - Stop campaign
```

## 🔒 Security Features

- ✅ Secure filename sanitization (prevents directory traversal)
- ✅ File extension validation
- ✅ Protection against malicious uploads
- ✅ Environment-based secret management

## 🚀 Deployment

For production deployment with Gunicorn:

```bash
# Build frontend
npm run build

# Run production server
cd backend
gunicorn --bind=0.0.0.0:5000 --reuse-port app:app
```

## 🛠️ Tech Stack

- **Backend**: Python 3.9.9, Flask, Werkzeug
- **Frontend**: React 18, Vite, Tailwind CSS
- **Email**: Amazon SES, Resend, SMTP
- **Rotation**: itertools.cycle for seamless rotation

## 📝 Run Scripts

### Windows
- `start-all.bat` - Start both servers
- `start-backend.bat` - Start backend only
- `start-frontend.bat` - Start frontend only

### Mac/Linux
- `start-all.sh` - Start both servers
- `start-backend.sh` - Start backend only
- `start-frontend.sh` - Start frontend only

## 📖 Documentation

- **[INSTALL.md](INSTALL.md)** - Complete installation guide
- **[replit.md](replit.md)** - Full feature documentation

## 🐛 Troubleshooting

**Port already in use?**
- Backend (8000): Change in `backend/app.py`
- Frontend (5000): Change in `package.json`

**Python not found?**
- Make sure Python 3.9.9 is installed
- Add Python to PATH (Windows)
- Use `python3` command (Mac/Linux)

**Dependencies fail to install?**
```bash
pip install --upgrade pip
pip install -r requirements.txt --no-cache-dir
```

## 📄 License

© 2025 Email Marketing Platform. All rights reserved.

## 🎉 Features Overview

- Unlimited subject line variations
- Unlimited sender email addresses
- 10 professional email templates
- Automatic rotation for all elements
- Real-time sending monitoring
- Campaign scheduling
- Multi-provider email support
- Secure file upload system
- Responsive dashboard interface

---

**Need help?** Check [INSTALL.md](INSTALL.md) for detailed installation instructions.
