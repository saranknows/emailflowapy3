// Database schema for Email Validator API
// References: javascript_log_in_with_replit and javascript_database blueprints

import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  bigint,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - username and password based authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique().notNull(),
  passwordHash: varchar("password_hash"),
  licenseKey: varchar("license_key").unique(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  email: varchar("email"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  credits: bigint("credits", { mode: "bigint" }).default(sql`1000000000::bigint`).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Email validations table - stores validation results
export const emailValidations = pgTable("email_validations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  email: varchar("email").notNull(),
  domain: varchar("domain").notNull(),
  isValid: boolean("is_valid").notNull(),
  isDeliverable: boolean("is_deliverable").notNull(),
  provider: varchar("provider"), // Microsoft, Google, Office365, Mimecast, ARSMTP, GoDaddy, etc.
  isMicrosoft: boolean("is_microsoft").default(false).notNull(),
  isGoogle: boolean("is_google").default(false).notNull(),
  isOffice365: boolean("is_office365").default(false).notNull(),
  isMimecast: boolean("is_mimecast").default(false).notNull(),
  isArsmtp: boolean("is_arsmtp").default(false).notNull(),
  isGodaddy: boolean("is_godaddy").default(false).notNull(),
  mxRecords: text("mx_records").array(),
  validationTime: integer("validation_time"), // milliseconds
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_user_validations").on(table.userId),
  index("idx_email").on(table.email),
  index("idx_provider").on(table.provider),
]);

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  emailValidations: many(emailValidations),
  campaigns: many(campaigns),
}));

export const emailValidationsRelations = relations(emailValidations, ({ one }) => ({
  user: one(users, {
    fields: [emailValidations.userId],
    references: [users.id],
  }),
}));

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertEmailValidation = typeof emailValidations.$inferInsert;
export type EmailValidation = typeof emailValidations.$inferSelect;

// Zod Schemas
export const insertEmailValidationSchema = createInsertSchema(emailValidations).omit({
  id: true,
  createdAt: true,
});

export const selectEmailValidationSchema = createSelectSchema(emailValidations);

// Click tracking campaigns table
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: varchar("name").notNull(),
  description: text("description"),
  targetUrl: text("target_url").notNull(), // The actual destination URL
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_user_campaigns").on(table.userId),
]);

// Tracking links table - unique links per recipient
export const trackingLinks = pgTable("tracking_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").notNull().references(() => campaigns.id, { onDelete: 'cascade' }),
  recipientEmail: varchar("recipient_email").notNull(),
  token: text("token").notNull().unique(), // Unique tracking token (long random string)
  clicks: integer("clicks").default(0).notNull(),
  firstClickedAt: timestamp("first_clicked_at"),
  lastClickedAt: timestamp("last_clicked_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_campaign_links").on(table.campaignId),
  index("idx_token").on(table.token),
  index("idx_recipient_email").on(table.recipientEmail),
]);

// Click events table - detailed click tracking
export const clickEvents = pgTable("click_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackingLinkId: varchar("tracking_link_id").notNull().references(() => trackingLinks.id, { onDelete: 'cascade' }),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  referer: text("referer"),
  country: varchar("country"),
  city: varchar("city"),
  clickedAt: timestamp("clicked_at").defaultNow(),
}, (table) => [
  index("idx_tracking_link_clicks").on(table.trackingLinkId),
  index("idx_clicked_at").on(table.clickedAt),
]);

// Relations for click tracking
export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  user: one(users, {
    fields: [campaigns.userId],
    references: [users.id],
  }),
  trackingLinks: many(trackingLinks),
}));

export const trackingLinksRelations = relations(trackingLinks, ({ one, many }) => ({
  campaign: one(campaigns, {
    fields: [trackingLinks.campaignId],
    references: [campaigns.id],
  }),
  clickEvents: many(clickEvents),
}));

export const clickEventsRelations = relations(clickEvents, ({ one }) => ({
  trackingLink: one(trackingLinks, {
    fields: [clickEvents.trackingLinkId],
    references: [trackingLinks.id],
  }),
}));

// Validation request schemas
export const singleEmailValidationSchema = z.object({
  email: z.string().email("Invalid email format"),
});

export const bulkEmailValidationSchema = z.object({
  emails: z.array(z.string().email()).max(10000, "Maximum 10,000 emails per batch"),
});

export type SingleEmailValidationRequest = z.infer<typeof singleEmailValidationSchema>;
export type BulkEmailValidationRequest = z.infer<typeof bulkEmailValidationSchema>;

// License keys table - admin-managed license keys
export const licenseKeys = pgTable("license_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").unique().notNull(), // The actual license key
  assignedUserId: varchar("assigned_user_id").references(() => users.id, { onDelete: 'set null' }),
  status: varchar("status").default("active").notNull(), // active, revoked
  issuedAt: timestamp("issued_at").defaultNow().notNull(),
  assignedAt: timestamp("assigned_at"),
  revokedAt: timestamp("revoked_at"),
}, (table) => [
  index("idx_license_key").on(table.key),
  index("idx_assigned_user").on(table.assignedUserId),
  index("idx_status").on(table.status),
]);

// License keys relations
export const licenseKeysRelations = relations(licenseKeys, ({ one }) => ({
  assignedUser: one(users, {
    fields: [licenseKeys.assignedUserId],
    references: [users.id],
  }),
}));

// Click tracking types
export type InsertCampaign = typeof campaigns.$inferInsert;
export type Campaign = typeof campaigns.$inferSelect;

export type InsertTrackingLink = typeof trackingLinks.$inferInsert;
export type TrackingLink = typeof trackingLinks.$inferSelect;

export type InsertClickEvent = typeof clickEvents.$inferInsert;
export type ClickEvent = typeof clickEvents.$inferSelect;

// License key types
export type InsertLicenseKey = typeof licenseKeys.$inferInsert;
export type LicenseKey = typeof licenseKeys.$inferSelect;

// Click tracking schemas
export const createCampaignSchema = z.object({
  name: z.string().min(1, "Campaign name is required"),
  description: z.string().optional(),
  targetUrl: z.string().url("Valid URL is required"),
});

export const generateTrackingLinksSchema = z.object({
  campaignId: z.string().uuid(),
  recipients: z.array(z.string().email()).max(10000, "Maximum 10,000 recipients per batch"),
});

export type CreateCampaignRequest = z.infer<typeof createCampaignSchema>;
export type GenerateTrackingLinksRequest = z.infer<typeof generateTrackingLinksSchema>;
