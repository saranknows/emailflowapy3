# Image Link Insertion - Quick Start Guide

## Overview
When you convert HTML emails to images, all clickable links are lost. This feature automatically preserves them by extracting links and inserting them as clickable buttons below the image.

---

## 🚀 Quick Setup (30 seconds)

### Enable Image Conversion with Link Preservation:

```python
from main import enable_html_to_image, enable_links_below_image

# Enable HTML-to-image conversion
enable_html_to_image()

# Enable link insertion (default is ON)
enable_links_below_image()

# Done! Run your campaign
```

---

## ⚙️ Configuration in EMAIL_CONFIG

Add these 3 lines to `EMAIL_CONFIG` in `main.py`:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    'convert_to_image': True,  # Enable image conversion
    'insert_links_below_image': True,  # Add clickable links below image
    'link_section_title': 'Important Links:',  # Customize title
    
    # ... other settings ...
}
```

---

## 📊 What Happens

### Original HTML Template:
```html
<h1>Sign the Document</h1>
<a href="https://example.com/sign">Sign Now</a>
<a href="https://example.com/help">Get Help</a>
```

### Result in Email:
```
┌─────────────────────────────┐
│  [Image of HTML template]   │
└─────────────────────────────┘
         ↓
┌─────────────────────────────┐
│ Important Links:            │
│ ┌─────────────────────────┐ │
│ │ ➤ Sign Now              │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ ➤ Get Help              │ │
│ └─────────────────────────┘ │
└─────────────────────────────┘
```

---

## 🔧 4 Management Functions

| Function | Purpose |
|----------|---------|
| `enable_links_below_image()` | Turn ON link insertion |
| `disable_links_below_image()` | Turn OFF link insertion |
| `set_link_section_title('title')` | Set custom title |
| `get_image_links_status()` | Check current settings |

---

## 💡 Common Use Cases

### Use Case 1: DocuSign-Style Emails
```python
enable_html_to_image()
enable_links_below_image()
set_link_section_title('Action Required')
# Result: Professional image + "Sign" button below
```

### Use Case 2: Image Only (No Links)
```python
enable_html_to_image()
disable_links_below_image()
# Result: Clean image, no link section
```

### Use Case 3: Custom Title
```python
enable_links_below_image()
set_link_section_title('Quick Access')
# Links section shows "Quick Access" instead of "Important Links:"
```

---

## ✅ Benefits

✅ **Automatic** - No manual link copying  
✅ **Professional** - Styled buttons, mobile-friendly  
✅ **Smart** - Skips placeholders, extracts only real URLs  
✅ **Customizable** - Change titles, styling, layout  
✅ **Compatible** - Works in all email clients  

---

## 📚 Full Documentation

For complete details, see **IMAGE-LINK-INSERTION-GUIDE.md**

---

**Your image emails now preserve all clickable links automatically!** 🔗
