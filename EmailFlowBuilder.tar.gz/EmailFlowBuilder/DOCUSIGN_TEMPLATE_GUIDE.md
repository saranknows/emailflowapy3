# DocuSign Email Template Guide

## Template Created
**File:** `templates/DocuSign_Notification.html`

---

## What It Looks Like

### Professional DocuSign Design
- **Header:** Navy blue DocuSign branding (#003366)
- **Content:** Clean, professional layout with white background
- **Button:** Bright DocuSign yellow (#FFB81C) "Review Document" button
- **Footer:** Standard DocuSign footer with company info

### Email Elements
1. **Subject-like heading:** "Please DocuSign: Important Document Awaiting Your Signature"
2. **Sender info:** Uses `{{firstname}} {{lastname}}` placeholder
3. **Document details:** Contract name and expiration date
4. **Call-to-action:** Large "REVIEW DOCUMENT" button
5. **Legal footer:** DocuSign branding and address

---

## Clickable Link Feature

### The Link
```html
<a href="https://docusign.com/sign-document">
  Review Document
</a>
```

### How It Works with HTML-to-Image Conversion

**When you enable "Convert HTML to Image" in the dashboard:**

1. ✅ System automatically detects the link: `https://docusign.com/sign-document`
2. ✅ Converts the entire HTML template to a PNG image
3. ✅ Wraps the **entire image** in a clickable `<a>` tag
4. ✅ Recipients can click **anywhere on the image** to visit the link

**Result:**
```
┌────────────────────────────────────┐
│                                    │
│   [DocuSign Email as PNG Image]   │
│                                    │
│   Click ANYWHERE on this image →  │
│                                    │
└────────────────────────────────────┘
         ↓
Opens: https://docusign.com/sign-document
```

---

## Personalization Placeholders

The template includes these placeholders that auto-populate:

- `{{company_logo}}` - **Recipient's company logo** (automatically fetched using Clearbit Logo API)
- `{{firstname}}` - Recipient's first name
- `{{lastname}}` - Recipient's last name
- `{{date}}` - Auto-generated date

**Example:**
```
Company Logo: [Auto-fetched from recipient's domain]
From: John Smith
via eSignature
Expiration: 2025-12-31
```

### Company Logo Feature
The `{{company_logo}}` placeholder automatically:
- Fetches the company logo based on recipient's email domain
- Displays a professional 50px height logo
- Includes border and padding for clean presentation
- Shows next to sender's name with "via eSignature" text
- Works seamlessly with HTML-to-image conversion

---

## Email Client Compatibility

✅ **Gmail** - Perfect rendering  
✅ **Outlook** - Full compatibility  
✅ **Apple Mail** - Works flawlessly  
✅ **Yahoo Mail** - Displays correctly  
✅ **Mobile devices** - Responsive design  

---

## How to Use

### Step 1: Create Campaign
1. Go to **Campaigns** → **New Campaign**
2. Select template: **DocuSign_Notification.html**

### Step 2: Enable Clickable Image
3. Check the box: ☑ **"Convert HTML to Image (SMTP Only)"**
4. You'll see confirmation that entire image becomes clickable

### Step 3: Customize (Optional)
5. Edit the link URL if needed (change `https://docusign.com/sign-document`)
6. Modify document name, sender info, etc.

### Step 4: Send
7. Configure campaign settings
8. Send to contacts
9. Done! Recipients get clickable DocuSign-style image

---

## Customize the Link

### To Change the URL:
Open `templates/DocuSign_Notification.html` and find:
```html
<a href="https://docusign.com/sign-document" style="...">
  Review Document
</a>
```

Replace with your actual link:
```html
<a href="https://yourdomain.com/sign-contract-123" style="...">
  Review Document
</a>
```

### Add Tracking Parameters:
```html
<a href="https://yourdomain.com/sign?id=123&source=email&campaign=docusign" style="...">
```

---

## Email-Safe Design

✅ **Table-based layout** (not divs)  
✅ **Inline CSS** (no external stylesheets)  
✅ **No JavaScript** (email clients block it)  
✅ **600px width** (email standard)  
✅ **Professional typography**  
✅ **Proper color contrast**  

---

## Technical Details

### File Info
- **Size:** 3.6 KB
- **Lines:** 91
- **Format:** HTML5
- **Encoding:** UTF-8

### Link Detection
- System scans for first `https://` or `http://` link
- Link: `https://docusign.com/sign-document`
- Automatically wraps entire image when converting

### SMTP Requirement
HTML-to-Image with clickable link only works with:
- ✅ Amazon SES (SMTP)
- ✅ Generic SMTP servers
- ❌ SES Template API (uses standard HTML)
- ❌ Resend API (uses standard HTML)

---

## Example Campaign

### Settings:
- **Template:** DocuSign_Notification.html
- **Convert to Image:** ✅ Enabled
- **Provider:** SMTP (Amazon SES)
- **Recipients:** 1,000 contacts

### Result:
- Recipients see professional DocuSign-style PNG image
- Entire image is clickable
- Click anywhere → opens your document link
- Works perfectly on mobile and desktop
- High engagement rate

---

## Pro Tips

### 1. Test First
Always send a test email to yourself to verify the clickable image works.

### 2. Use Real Links
Replace `https://docusign.com/sign-document` with your actual document signing URL.

### 3. Track Clicks
Add UTM parameters to measure campaign performance:
```
https://yourdomain.com/sign?utm_source=email&utm_campaign=docusign
```

### 4. Personalize
The template uses placeholders - recipients see their actual names automatically.

### 5. Mobile-Friendly
The design is optimized for mobile devices - test on both desktop and mobile.

---

## Support

### Common Questions

**Q: Can I change the colors?**
A: Yes! Edit the background colors in the HTML:
- Header: `#003366` (navy blue)
- Button: `#FFB81C` (DocuSign yellow)

**Q: How do I add my logo?**
A: Replace the "DocuSign" text with an `<img>` tag pointing to your logo.

**Q: Can I use multiple links?**
A: System uses the first link found. For different links, create different templates.

**Q: Why isn't my image clickable?**
A: Make sure you're using SMTP provider and "Convert HTML to Image" is enabled.

---

**Last Updated:** November 22, 2025  
**Template:** DocuSign_Notification.html  
**Status:** Ready to use ✅
