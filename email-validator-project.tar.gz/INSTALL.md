# Email Validator - Installation Instructions

## Prerequisites

- **Python 3.9+** (required for FastAPI backend)
- **Node.js 18+** (required for React frontend)
- **PostgreSQL** (database)
- **Git** (for cloning the repository)

## System Requirements

- Operating System: Linux, macOS, or Windows (with WSL recommended)
- RAM: Minimum 2GB
- Disk Space: At least 500MB free space

---

## Installation Steps

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd email-validator
```

### 2. Set Up Python 3.9 Environment

#### Option A: Using Python Virtual Environment (Recommended)

```bash
# Create virtual environment with Python 3.9
python3.9 -m venv venv

# Activate virtual environment
# On Linux/macOS:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

#### Option B: Using pyenv (Alternative)

```bash
# Install pyenv (if not already installed)
curl https://pyenv.run | bash

# Install Python 3.9
pyenv install 3.9.18

# Set local Python version
pyenv local 3.9.18
```

### 3. Install Python Dependencies

```bash
pip install --upgrade pip

# Install all backend dependencies
pip install \
    fastapi==0.115.5 \
    uvicorn[standard]==0.32.1 \
    sqlalchemy==2.0.36 \
    asyncpg==0.30.0 \
    psycopg2-binary==2.9.10 \
    pydantic==2.10.3 \
    pydantic-settings==2.6.1 \
    email-validator==2.2.0 \
    dnspython==2.7.0 \
    passlib[bcrypt]==1.7.4 \
    python-jose[cryptography]==3.3.0 \
    python-multipart==0.0.20 \
    slowapi==0.1.9 \
    authlib==1.3.2 \
    httpx==0.28.1 \
    python-dotenv==1.0.1 \
    aiofiles==24.1.0 \
    aiodns==3.2.0
```

### 4. Install Node.js Dependencies

```bash
npm install
```

### 5. Set Up PostgreSQL Database

#### Option A: Local PostgreSQL

```bash
# Install PostgreSQL (Ubuntu/Debian)
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib

# Start PostgreSQL service
sudo service postgresql start

# Create database
sudo -u postgres createdb email_validator

# Create user
sudo -u postgres psql -c "CREATE USER email_user WITH PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE email_validator TO email_user;"
```

#### Option B: Using Neon (Serverless PostgreSQL)

1. Sign up at [neon.tech](https://neon.tech)
2. Create a new project
3. Copy the connection string
4. Use it in your `.env` file (next step)

### 6. Configure Environment Variables

Create a `.env` file in the root directory:

```bash
# Copy example environment file
cp .env.example .env
```

Edit `.env` and add your configuration:

```env
# Database Configuration
DATABASE_URL=postgresql://email_user:your_password@localhost:5432/email_validator

# Or for Neon:
# DATABASE_URL=postgresql://user:password@ep-xxx.region.neon.tech/neondb?sslmode=require

# Session Configuration
SESSION_SECRET=your-super-secret-session-key-change-this-in-production

# Application Settings
NODE_ENV=development
PORT=5000

# Rate Limiting (optional, defaults shown)
RATE_LIMIT=60/minute

# Cookie Security (optional, defaults shown)
SECURE_COOKIES=false  # Set to true in production with HTTPS
```

**Important:** Replace `your_password` and `your-super-secret-session-key-change-this-in-production` with strong, unique values.

### 7. Initialize Database Schema

The application will automatically create database tables on first run. If you need to manually create them:

```bash
# Run database migrations (if using Drizzle)
npm run db:push
```

### 8. Verify Python Version

Ensure you're using Python 3.9+:

```bash
python --version
# Should output: Python 3.9.x or higher
```

---

## Running the Application

### Development Mode

Start both backend and frontend in development mode:

```bash
npm run dev
```

This will:
- Start FastAPI backend on `http://localhost:5000`
- Start React frontend on `http://localhost:5173`
- Enable hot-reloading for both services

**Access the application:**
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- API Documentation: http://localhost:5000/docs (Swagger UI)

### Production Mode

```bash
# Build the application
npm run build

# Start in production mode
npm start
```

---

## Verifying Installation

### 1. Check Backend Health

```bash
curl http://localhost:5000/health
```

Expected response:
```json
{"status":"healthy","service":"email-validator-api"}
```

### 2. Check Frontend

Open http://localhost:5173 in your browser. You should see the Email Validator login page.

### 3. Test API Documentation

Visit http://localhost:5000/docs to see the interactive API documentation.

---

## Troubleshooting

### Python Version Issues

**Error:** `ModuleNotFoundError` or syntax errors

**Solution:** Ensure you're using Python 3.9+:
```bash
python --version
which python
```

If using multiple Python versions, specify Python 3.9 explicitly:
```bash
python3.9 -m venv venv
```

### Database Connection Issues

**Error:** `could not connect to server`

**Solutions:**
1. Verify PostgreSQL is running:
   ```bash
   sudo service postgresql status
   ```

2. Check DATABASE_URL in `.env` file

3. Test connection manually:
   ```bash
   psql postgresql://email_user:your_password@localhost:5432/email_validator
   ```

### Port Already in Use

**Error:** `Address already in use`

**Solution:** Kill existing processes:
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>
```

### Missing Dependencies

**Error:** `ModuleNotFoundError: No module named 'fastapi'`

**Solution:** Ensure virtual environment is activated and reinstall:
```bash
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### Node Module Issues

**Error:** `Cannot find module`

**Solution:** Clean install:
```bash
rm -rf node_modules package-lock.json
npm install
```

---

## Default User Account

On first run, you can register a new account through the UI at http://localhost:5173/register

Each new user receives:
- **1,000,000,000 validation credits** (1 billion)
- **60 API requests per minute** rate limit

---

## Project Structure

```
email-validator/
├── backend/              # Python FastAPI backend
│   ├── routers/         # API route handlers
│   ├── services/        # Business logic
│   ├── models.py        # Database models
│   ├── config.py        # Configuration
│   └── main.py          # FastAPI application entry
├── client/              # React frontend
│   └── src/
│       ├── pages/       # Page components
│       ├── components/  # UI components
│       └── lib/         # Utilities
├── server/              # Node.js orchestration
│   └── index.ts         # Starts Python & Vite servers
├── shared/              # Shared TypeScript schemas
├── package.json         # Node.js dependencies
└── .env                 # Environment variables
```

---

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/session` - Get current session

### Validation
- `POST /api/validate/single` - Validate single email
- `POST /api/validate/bulk` - Upload CSV for bulk validation (max 10,000)
- `GET /api/validate/results` - Get validation history
- `GET /api/validate/export/{provider}` - Export emails by provider
- `GET /api/validate/stats` - Get validation statistics

### Analytics
- `GET /api/analytics/health` - API health status

---

## Features

✅ **Single Email Validation**
- Format validation (RFC 5321)
- MX record lookup
- Provider detection (Microsoft, Google, Office365, Mimecast, ARSMTP, GoDaddy)

✅ **Bulk CSV Upload**
- Up to 10,000 emails per upload
- Duplicate detection (case-insensitive)
- Validation caching (1-hour TTL)
- Smart credit deduction (only charges for new validations)

✅ **Security**
- Password authentication with bcrypt
- Secure JWT sessions
- HTTP-only cookies
- Rate limiting (60 requests/minute)

✅ **Credit System**
- 1 billion credits per user
- Credits charged only for uncached validations
- Cached results are free
- Duplicate emails count as one

---

## Development Tips

### Hot Reloading
Both backend and frontend support hot reloading in development mode. Changes are reflected automatically.

### API Testing
Use the Swagger UI at http://localhost:5000/docs to test API endpoints interactively.

### Database Inspection
Use a PostgreSQL client like pgAdmin or command line:
```bash
psql $DATABASE_URL
\dt  # List tables
SELECT * FROM users LIMIT 5;
```

### Clearing Validation Cache
The validation cache automatically expires after 1 hour. To manually clear:
```bash
# Restart the application
npm run dev
```

---

## Next Steps

1. **Register a user account** at http://localhost:5173/register
2. **Test single email validation** on the dashboard
3. **Try bulk CSV upload** with a sample CSV file
4. **Export validated emails** by provider
5. **Check API documentation** at http://localhost:5000/docs

---

## Support

For issues or questions:
- Check the [Troubleshooting](#troubleshooting) section
- Review application logs in the console
- Check backend logs for detailed error messages

---

## Production Deployment

For production deployment:

1. Set environment variables:
   ```env
   NODE_ENV=production
   SECURE_COOKIES=true
   ```

2. Use a production-grade database (not SQLite)

3. Set strong SESSION_SECRET

4. Configure HTTPS/SSL certificates

5. Deploy behind a reverse proxy (nginx, Apache)

6. Monitor logs and performance

7. Set up regular database backups

---

**Happy Validating! 📧✨**
