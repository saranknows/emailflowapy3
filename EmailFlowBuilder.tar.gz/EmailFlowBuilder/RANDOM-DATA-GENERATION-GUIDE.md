# Random Data Generation Functions Guide

## Overview
Automatically generate random names, emails, numbers, phone numbers, and dates for email personalization. These functions integrate seamlessly with the placeholder system - just use the placeholders in your templates and they're automatically filled with realistic random data.

---

## 🎯 **Available Placeholders**

### **Automatic Placeholders (No Configuration Required)**

Just use these in your templates and they'll be automatically replaced:

| Placeholder | Description | Example Output |
|-------------|-------------|----------------|
| `{{firstname}}` | Random first name | James, Mary, Michael |
| `{{lastname}}` | Random last name | Smith, Johnson, Garcia |
| `{{fullname}}` | Random full name | John Williams |
| `{{name}}` | Alias for fullname | Sarah Martinez |
| `{{email}}` | Random email address | john.smith@gmail.com |
| `{{randomemail}}` | Alias for email | mary.j123@yahoo.com |
| `{{randomnumber}}` | Random number (1-99999) | 45821 |
| `{{number}}` | Random number (1-9999) | 3456 |
| `{{id}}` | Random ID (10000-99999) | 67234 |
| `{{phone}}` | Random phone number | (555) 123-4567 |
| `{{date}}` | Random date (next 30 days) | 12/15/2025 |
| `{{randomdate}}` | Alias for date | 11/28/2025 |

---

## 📧 **How to Use in Templates**

### **Example 1: Simple Personalization**

```html
<html>
<body>
    <h1>Hello {{firstname}}!</h1>
    <p>Your account ID is: {{id}}</p>
</body>
</html>
```

**Output:**
```html
<html>
<body>
    <h1>Hello Michael!</h1>
    <p>Your account ID is: 45821</p>
</body>
</html>
```

---

### **Example 2: Full Contact Info**

```html
<div class="contact-card">
    <h2>{{fullname}}</h2>
    <p>Email: {{email}}</p>
    <p>Phone: {{phone}}</p>
    <p>Member since: {{date}}</p>
</div>
```

**Output:**
```html
<div class="contact-card">
    <h2>Sarah Martinez</h2>
    <p>Email: sarah.martinez456@outlook.com</p>
    <p>Phone: (714) 892-3456</p>
    <p>Member since: 12/05/2025</p>
</div>
```

---

### **Example 3: DocuSign-Style Email**

```html
<html>
<body>
    <h1>Document Signature Request</h1>
    <p>Dear {{firstname}} {{lastname}},</p>
    <p>A document requires your signature.</p>
    <p><strong>Document ID:</strong> DOC-{{randomnumber}}</p>
    <p><strong>Due Date:</strong> {{date}}</p>
    <p><strong>Contact:</strong> {{phone}}</p>
    <a href="{{link}}">Sign Document Now</a>
</body>
</html>
```

**Output:**
```html
<html>
<body>
    <h1>Document Signature Request</h1>
    <p>Dear James Wilson,</p>
    <p>A document requires your signature.</p>
    <p><strong>Document ID:</strong> DOC-78945</p>
    <p><strong>Due Date:</strong> 12/10/2025</p>
    <p><strong>Contact:</strong> (858) 234-5678</p>
    <a href="https://example.com/sign">Sign Document Now</a>
</body>
</html>
```

---

## 🔧 **Generation Functions**

### **7 Core Functions**

#### **1. `generate_random_firstname()`**

Generates a random first name from 50 common names.

```python
>>> generate_random_firstname()
'Michael'
>>> generate_random_firstname()
'Sarah'
```

**Name Pool:** 50 names (25 male, 25 female)

---

#### **2. `generate_random_lastname()`**

Generates a random last name from 50 common surnames.

```python
>>> generate_random_lastname()
'Smith'
>>> generate_random_lastname()
'Garcia'
```

**Name Pool:** 50 common surnames

---

#### **3. `generate_random_fullname()`**

Generates a random full name (first + last).

```python
>>> generate_random_fullname()
'John Williams'
>>> generate_random_fullname()
'Emily Martinez'
```

---

#### **4. `generate_random_email()`**

Generates a realistic random email address with variations.

```python
>>> generate_random_email()
'john.smith@gmail.com'
>>> generate_random_email()
'mary.j456@yahoo.com'
>>> generate_random_email()
'mjohnson@outlook.com'
```

**Formats:**
- `firstname.lastname@domain.com`
- `firstname.lastname123@domain.com`
- `firstnamelastname@domain.com`
- `jsmith@domain.com` (first initial + last)
- `firstname_lastname@domain.com`
- `firstname456@domain.com`

**Domains:** Gmail, Yahoo, Outlook, Hotmail, iCloud, Mail.com, AOL, ProtonMail, Zoho, GMX

---

#### **5. `generate_random_number(min_val=1, max_val=99999)`**

Generates a random number in specified range.

```python
>>> generate_random_number()
45821
>>> generate_random_number(1, 100)
73
>>> generate_random_number(10000, 99999)
67234
```

**Default Range:** 1 to 99,999

---

#### **6. `generate_random_phone()`**

Generates a random US phone number.

```python
>>> generate_random_phone()
'(555) 123-4567'
>>> generate_random_phone()
'(714) 892-3456'
```

**Format:** (XXX) XXX-XXXX

---

#### **7. `generate_random_date()`**

Generates a random date in the next 30 days.

```python
>>> generate_random_date()
'12/15/2025'
>>> generate_random_date()
'11/28/2025'
```

**Format:** MM/DD/YYYY  
**Range:** 1-30 days from today

---

## ⚙️ **Advanced Usage**

### **Manual Function Calls**

You can also call these functions directly in your Python code:

```python
from main import (
    generate_random_firstname,
    generate_random_email,
    generate_random_number
)

# Generate data
name = generate_random_firstname()
email = generate_random_email()
id_num = generate_random_number(1000, 9999)

# Use in custom placeholder dictionary
custom_data = {
    'customer_name': name,
    'customer_email': email,
    'order_id': str(id_num)
}

# Apply to template
result = replace_template_placeholders(template, custom_data)
```

---

### **Override Auto-Generated Values**

You can override any auto-generated placeholder by providing custom values:

```python
# Template with {{firstname}} and {{email}}
template = "<p>Hello {{firstname}}! Email: {{email}}</p>"

# Override firstname but keep email auto-generated
custom_placeholders = {
    'firstname': 'Custom Name'
}

result = replace_template_placeholders(template, custom_placeholders)
# Result: <p>Hello Custom Name! Email: john.smith@gmail.com</p>
```

---

### **Disable Auto-Generation**

```python
# Disable auto-generation (only use provided placeholders)
result = replace_template_placeholders(
    template, 
    placeholders={'firstname': 'John'},
    auto_generate=False
)
```

---

## 📊 **Data Pools**

### **First Names (50 total)**

**Male (25):**
James, John, Robert, Michael, William, David, Richard, Joseph, Thomas, Charles, Daniel, Matthew, Anthony, Donald, Mark, Paul, Steven, Andrew, Kenneth, Joshua, Christopher, Brian, Kevin, George, Edward

**Female (25):**
Mary, Patricia, Jennifer, Linda, Elizabeth, Barbara, Susan, Jessica, Sarah, Karen, Nancy, Lisa, Betty, Margaret, Sandra, Ashley, Dorothy, Kimberly, Emily, Donna, Ronald, Timothy, Jason, Jeffrey, Ryan

---

### **Last Names (50 total)**

Smith, Johnson, Williams, Brown, Jones, Garcia, Miller, Davis, Rodriguez, Martinez, Hernandez, Lopez, Gonzalez, Wilson, Anderson, Thomas, Taylor, Moore, Jackson, Martin, Lee, Perez, Thompson, White, Harris, Sanchez, Clark, Ramirez, Lewis, Robinson, Walker, Young, Allen, King, Wright, Scott, Torres, Nguyen, Hill, Flores, Green, Adams, Nelson, Baker, Hall, Rivera, Campbell, Mitchell, Carter, Roberts

---

### **Email Domains (10 total)**

gmail.com, yahoo.com, outlook.com, hotmail.com, icloud.com, mail.com, aol.com, protonmail.com, zoho.com, gmx.com

---

## 💡 **Use Cases**

### **Use Case 1: Personalized Marketing Emails**

```html
<p>Hi {{firstname}},</p>
<p>Special offer just for you! Use code: SAVE{{number}}</p>
<p>Expires: {{date}}</p>
```

Each recipient gets unique personalization without maintaining a database.

---

### **Use Case 2: Document Signing Requests**

```html
<h1>Signature Required</h1>
<p>{{fullname}}, please sign document #{{id}}</p>
<p>Deadline: {{date}}</p>
<p>Questions? Call {{phone}}</p>
```

Professional appearance with realistic data.

---

### **Use Case 3: Account Notifications**

```html
<p>Hello {{firstname}},</p>
<p>Your account {{email}} has been updated.</p>
<p>Reference ID: {{randomnumber}}</p>
<p>Date: {{date}}</p>
```

Unique tracking for each email.

---

### **Use Case 4: Survey Invitations**

```html
<p>Dear {{firstname}} {{lastname}},</p>
<p>Survey ID: {{id}}</p>
<p>Complete by: {{date}}</p>
<p>Contact: {{phone}}</p>
```

Trackable survey invitations.

---

## 🎯 **Best Practices**

### **1. Use Realistic Combinations**

✅ **Good:**
```html
<p>Contact {{firstname}} at {{phone}}</p>
```

❌ **Less Effective:**
```html
<p>Email: {{randomnumber}}</p>  <!-- Numbers don't make sense for emails -->
```

---

### **2. Mix Auto and Custom Placeholders**

```python
# Auto-generate names but use specific content
placeholders = {
    'company': 'ACME Corporation',
    'product': 'Premium Widget',
    'price': '$99.99'
}
# {{firstname}}, {{email}}, etc. still auto-generated
```

---

### **3. Test Output First**

Before sending large campaigns, test with a few emails to verify output:

```python
# Test template replacement
template = load_template('your_template.html')
result = replace_template_placeholders(template)
print(result)  # Check the output
```

---

### **4. Use Appropriate Ranges**

```python
# Order numbers (higher range)
generate_random_number(10000, 99999)  # → 45821

# Discount codes (lower range)
generate_random_number(10, 99)  # → 47
```

---

## 🔄 **Integration with Other Features**

### **Works With:**

✅ **Template Rotation** - Each template gets unique random data  
✅ **Subject Lines** - Can use placeholders in subjects too  
✅ **Link Rotation** - Combine with {{link}} placeholders  
✅ **QR Codes** - Use {{randomnumber}} in QR data  
✅ **HTML to Image** - Random data preserved in images  

### **Example with Multiple Features:**

```html
<!-- Template with rotation + random data + links -->
<h1>Hello {{firstname}}!</h1>
<p>Your unique code: {{randomnumber}}</p>
<p>Visit: {{website}}</p>
<p>Contact: {{phone}}</p>
<p>Valid until: {{date}}</p>
<a href="{{link}}">Claim Offer</a>
```

**Result:**
- `{{firstname}}` → Random name
- `{{randomnumber}}` → Random number
- `{{website}}` → Rotated link from links/website.txt
- `{{phone}}` → Random phone
- `{{date}}` → Random date
- `{{link}}` → Rotated link from links/link.txt

---

## 📚 **Quick Reference**

### **Name Placeholders:**
```
{{firstname}}  → Michael
{{lastname}}   → Smith
{{fullname}}   → John Williams
{{name}}       → Sarah Garcia
```

### **Contact Placeholders:**
```
{{email}}      → john.smith@gmail.com
{{phone}}      → (555) 123-4567
```

### **Number Placeholders:**
```
{{randomnumber}} → 45821 (1-99999)
{{number}}       → 3456 (1-9999)
{{id}}           → 67234 (10000-99999)
```

### **Date Placeholders:**
```
{{date}}       → 12/15/2025
{{randomdate}} → 11/28/2025
```

---

## ✅ **Summary**

**7 Generation Functions:**
1. `generate_random_firstname()` - First names
2. `generate_random_lastname()` - Last names
3. `generate_random_fullname()` - Full names
4. `generate_random_email()` - Email addresses
5. `generate_random_number()` - Random numbers
6. `generate_random_phone()` - Phone numbers
7. `generate_random_date()` - Future dates

**12 Automatic Placeholders:**
- firstname, lastname, fullname, name
- email, randomemail
- randomnumber, number, id
- phone
- date, randomdate

**Key Features:**
- ✅ Automatic replacement (no configuration)
- ✅ Realistic data from curated pools
- ✅ Override with custom values
- ✅ Integrates with all rotation features
- ✅ 50 first names, 50 last names, 10 email domains

---

**Your email templates now support automatic random data generation for personalization!** 🎲
