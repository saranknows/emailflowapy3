// Landing page for logged-out users
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, Shield, Zap, Globe } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

export default function Landing() {
  const [loginData, setLoginData] = useState({ username: '', password: '', licenseKey: '' });
  const [signupData, setSignupData] = useState({ username: '', password: '', licenseKey: '', email: '' });
  const { login, signup } = useAuth();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(loginData);
      toast({
        title: 'Logged in successfully',
        description: 'Welcome back to Email Validator!'
      });
    } catch (error) {
      toast({
        title: 'Login failed',
        description: error instanceof Error ? error.message : 'Please check your credentials',
        variant: 'destructive'
      });
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signup(signupData);
      toast({
        title: 'Account created successfully',
        description: 'Welcome to Email Validator! You have 1 billion validation credits.'
      });
    } catch (error) {
      toast({
        title: 'Signup failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-purple-50 dark:from-violet-950 dark:via-background dark:to-purple-950">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold tracking-tight mb-4">
            Email Validator
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional email validation service with multi-provider detection. 
            Validate single emails or bulk CSV uploads up to 10,000 emails.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card>
            <CardHeader>
              <CheckCircle2 className="h-8 w-8 text-primary mb-2" />
              <CardTitle className="text-lg">Multi-Provider Detection</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Detect Microsoft, Google, Office365, Mimecast, ARSMTP, and GoDaddy email providers
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Zap className="h-8 w-8 text-primary mb-2" />
              <CardTitle className="text-lg">Bulk Processing</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Upload CSV files and validate up to 10,000 emails at once
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="h-8 w-8 text-primary mb-2" />
              <CardTitle className="text-lg">MX Record Validation</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Advanced DNS verification to check email deliverability
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Globe className="h-8 w-8 text-primary mb-2" />
              <CardTitle className="text-lg">1 Billion Credits</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Every user gets 1 billion validation credits to get started
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Auth Card */}
        <div className="max-w-md mx-auto">
          <Card className="shadow-2xl">
            <CardHeader>
              <CardTitle className="text-2xl">Get Started</CardTitle>
              <CardDescription>
                Create an account or sign in to start validating emails
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="login" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login" data-testid="tab-login">Login</TabsTrigger>
                  <TabsTrigger value="signup" data-testid="tab-signup">Sign Up</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-username" data-testid="label-login-username">Username</Label>
                      <Input
                        id="login-username"
                        type="text"
                        placeholder="Enter your username"
                        value={loginData.username}
                        onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                        required
                        data-testid="input-login-username"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="login-password" data-testid="label-login-password">Password</Label>
                      <Input
                        id="login-password"
                        type="password"
                        placeholder="Enter your password"
                        value={loginData.password}
                        onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                        required
                        data-testid="input-login-password"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="login-license-key" data-testid="label-login-license-key">License Key</Label>
                      <Input
                        id="login-license-key"
                        type="text"
                        placeholder="Enter your license key"
                        value={loginData.licenseKey}
                        onChange={(e) => setLoginData({ ...loginData, licenseKey: e.target.value })}
                        required
                        data-testid="input-login-license-key"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      data-testid="button-login"
                    >
                      Login
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="signup">
                  <form onSubmit={handleSignup} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-username" data-testid="label-signup-username">Username</Label>
                      <Input
                        id="signup-username"
                        type="text"
                        placeholder="Choose a username"
                        value={signupData.username}
                        onChange={(e) => setSignupData({ ...signupData, username: e.target.value })}
                        required
                        minLength={3}
                        data-testid="input-signup-username"
                      />
                      <p className="text-xs text-muted-foreground">At least 3 characters</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password" data-testid="label-signup-password">Password</Label>
                      <Input
                        id="signup-password"
                        type="password"
                        placeholder="Create a password"
                        value={signupData.password}
                        onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                        required
                        minLength={8}
                        data-testid="input-signup-password"
                      />
                      <p className="text-xs text-muted-foreground">At least 8 characters</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-license-key" data-testid="label-signup-license-key">License Key</Label>
                      <Input
                        id="signup-license-key"
                        type="text"
                        placeholder="Enter your license key"
                        value={signupData.licenseKey}
                        onChange={(e) => setSignupData({ ...signupData, licenseKey: e.target.value })}
                        required
                        data-testid="input-signup-license-key"
                      />
                      <p className="text-xs text-muted-foreground">Contact admin for a license key</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-email" data-testid="label-signup-email">Email (optional)</Label>
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="you@example.com"
                        value={signupData.email}
                        onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                        data-testid="input-signup-email"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      data-testid="button-signup"
                    >
                      Create Account
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
