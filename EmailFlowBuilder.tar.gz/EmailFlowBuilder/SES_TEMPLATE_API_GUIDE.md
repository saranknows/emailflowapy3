# AWS SES Template Management via API ✅

## Overview
You can now create, update, and delete email templates in AWS SES programmatically using Python functions with your AWS credentials.

---

## ✅ Functions Added to main.py

### 1. **create_ses_template()** - Create New Template
Create a new email template in AWS SES programmatically.

**Function:**
```python
create_ses_template(template_name, subject_part, html_part, text_part='')
```

**Parameters:**
- `template_name` (str): Unique name for the template
- `subject_part` (str): Email subject (can include {{placeholders}})
- `html_part` (str): HTML body content (can include {{placeholders}})
- `text_part` (str, optional): Plain text fallback

**Example Usage:**
```python
from main import create_ses_template

create_ses_template(
    template_name='welcome-email',
    subject_part='Welcome {{firstname}}!',
    html_part='<html><body><h1>Hello {{firstname}}!</h1></body></html>',
    text_part='Hello {{firstname}}!'
)
```

**Output:**
```
✅ SES template created: welcome-email
```

---

### 2. **update_ses_template()** - Update Existing Template
Update an existing SES template (partial updates supported).

**Function:**
```python
update_ses_template(template_name, subject_part=None, html_part=None, text_part=None)
```

**Parameters:**
- `template_name` (str): Name of existing template
- `subject_part` (str, optional): New subject (None = keep existing)
- `html_part` (str, optional): New HTML body (None = keep existing)
- `text_part` (str, optional): New text body (None = keep existing)

**Example Usage:**
```python
from main import update_ses_template

# Update only the subject
update_ses_template(
    'welcome-email',
    subject_part='Welcome {{firstname}} {{lastname}}!'
)

# Update HTML and keep subject
update_ses_template(
    'welcome-email',
    html_part='<html><body><h1>New Design!</h1></body></html>'
)
```

**Output:**
```
✅ SES template updated: welcome-email
```

---

### 3. **delete_ses_template()** - Delete Template
Delete a template from AWS SES.

**Function:**
```python
delete_ses_template(template_name)
```

**Parameters:**
- `template_name` (str): Name of template to delete

**Example Usage:**
```python
from main import delete_ses_template

delete_ses_template('old-template')
```

**Output:**
```
✅ SES template deleted: old-template
```

---

### 4. **fetch_ses_templates()** - List All Templates
Get list of all templates in AWS SES.

**Function:**
```python
fetch_ses_templates()
```

**Returns:**
- List of template names

**Example Usage:**
```python
from main import fetch_ses_templates

templates = fetch_ses_templates()
print(f"Found {len(templates)} templates: {templates}")
```

**Output:**
```
Found 3 templates: ['professional-welcome', 'document-notification', 'invoice-template']
```

---

### 5. **get_ses_template()** - Get Template Details
Retrieve complete details of a specific template.

**Function:**
```python
get_ses_template(template_name)
```

**Returns:**
- Dictionary with: name, subject, html, text

**Example Usage:**
```python
from main import get_ses_template

template = get_ses_template('professional-welcome')
print(f"Subject: {template['subject']}")
print(f"HTML: {template['html'][:100]}...")
```

---

## 🎯 Real-World Example: Bulk Template Creation

```python
#!/usr/bin/env python3
from main import create_ses_template, fetch_ses_templates

# Define templates
templates_to_create = [
    {
        'name': 'welcome-template',
        'subject': 'Welcome {{firstname}} - Get Started Today!',
        'html': '''
        <html>
        <body style="font-family: Arial; padding: 20px;">
            <h1>Welcome {{firstname}}!</h1>
            <p>Account ID: {{id}}</p>
            <p>Created: {{date}}</p>
        </body>
        </html>
        ''',
        'text': 'Welcome {{firstname}}! Account ID: {{id}}'
    },
    {
        'name': 'notification-template',
        'subject': 'Important Update for {{fullname}}',
        'html': '''
        <html>
        <body style="font-family: Arial; padding: 20px;">
            <h2>Dear {{firstname}} {{lastname}},</h2>
            <p>Reference: {{randomnumber}}</p>
            <p>Date: {{date}}</p>
        </body>
        </html>
        ''',
        'text': 'Update for {{fullname}}. Ref: {{randomnumber}}'
    },
    {
        'name': 'invoice-template',
        'subject': 'Invoice #{{randomnumber}} - {{date}}',
        'html': '''
        <html>
        <body>
            <h1>Invoice</h1>
            <p>Customer: {{fullname}}</p>
            <p>Email: {{email}}</p>
            <p>Invoice: {{randomnumber}}</p>
        </body>
        </html>
        ''',
        'text': 'Invoice {{randomnumber}} for {{fullname}}'
    }
]

# Create all templates
print("Creating templates...")
for template in templates_to_create:
    create_ses_template(
        template['name'],
        template['subject'],
        template['html'],
        template['text']
    )

# Verify creation
print("\nVerifying...")
all_templates = fetch_ses_templates()
print(f"✅ Total templates in SES: {len(all_templates)}")
for t in all_templates:
    print(f"   - {t}")
```

---

## 📧 Test Results

### Successfully Created 3 Templates:

```
======================================================================
   TEMPLATE CREATION SUMMARY
======================================================================
✅ professional-welcome - Created successfully
✅ document-notification - Created successfully
✅ invoice-template - Created successfully

======================================================================
   FETCHING ALL TEMPLATES FROM SES
======================================================================

✅ Found 3 template(s) in AWS SES:
   1. invoice-template
   2. document-notification
   3. professional-welcome
======================================================================
```

---

## 🎨 Template Placeholders

All templates support these placeholders:

| Placeholder | Replacement | Example |
|------------|-------------|---------|
| `{{firstname}}` | Random first name | "James" |
| `{{lastname}}` | Random last name | "Smith" |
| `{{fullname}}` | Full name | "James Smith" |
| `{{email}}` | Random email | "james.smith@gmail.com" |
| `{{id}}` | Random ID | "54321" |
| `{{randomnumber}}` | Random number | "98765" |
| `{{phone}}` | Random phone | "(555) 123-4567" |
| `{{date}}` | Random date | "12/15/2025" |

**Example Template:**
```html
<h1>Welcome {{firstname}} {{lastname}}!</h1>
<p>Your ID is {{id}}</p>
<p>Contact: {{phone}}</p>
<p>Date: {{date}}</p>
```

**Rendered Output:**
```html
<h1>Welcome James Smith!</h1>
<p>Your ID is 54321</p>
<p>Contact: (555) 123-4567</p>
<p>Date: 12/15/2025</p>
```

---

## ✅ Available Templates

### 1. **professional-welcome**
- **Subject:** Welcome {{firstname}} - Account Created
- **Style:** Professional with blue button, clean design
- **Use:** New user onboarding

### 2. **document-notification**
- **Subject:** Document #{{id}} Ready - {{date}}
- **Style:** Yellow highlight, green button
- **Use:** Document alerts, notifications

### 3. **invoice-template**
- **Subject:** Invoice #{{randomnumber}} - {{date}}
- **Style:** Professional invoice layout
- **Use:** Billing, invoices, receipts

---

## 🚀 How to Use in Your Emails

### Option 1: Python Script
```python
from main import create_ses_template

# Create your custom template
create_ses_template(
    'my-custom-template',
    'Subject: {{firstname}} - Important!',
    '<html><body><h1>Hello {{firstname}}!</h1></body></html>'
)

# Run your email sender
# The system will automatically fetch and randomly rotate all SES templates
```

### Option 2: Interactive Python
```python
python3
>>> from main import create_ses_template, fetch_ses_templates
>>> create_ses_template('test', 'Test {{firstname}}', '<h1>Hi {{firstname}}!</h1>')
✅ SES template created: test
>>> fetch_ses_templates()
['professional-welcome', 'document-notification', 'invoice-template', 'test']
```

---

## 🛠️ Common Operations

### Create Template:
```python
from main import create_ses_template

create_ses_template(
    'alert-template',
    'URGENT: Action Required {{firstname}}',
    '<html><body><h1>Alert for {{firstname}}!</h1></body></html>',
    'Alert for {{firstname}}!'
)
```

### Update Template:
```python
from main import update_ses_template

update_ses_template(
    'alert-template',
    subject_part='NEW: Action Required {{firstname}}'
)
```

### Delete Template:
```python
from main import delete_ses_template

delete_ses_template('alert-template')
```

### List All Templates:
```python
from main import fetch_ses_templates

templates = fetch_ses_templates()
for t in templates:
    print(f"- {t}")
```

---

## 📊 Benefits

### vs AWS Console:
✅ **Faster**: Create multiple templates instantly  
✅ **Automated**: Script template creation  
✅ **Version Control**: Templates in code  
✅ **Bulk Operations**: Create/update many at once  
✅ **CI/CD Ready**: Integrate into deployment pipelines  

### vs Local Templates:
✅ **Centralized**: Managed in AWS (edit from anywhere)  
✅ **Versioned**: AWS tracks template versions  
✅ **No Deployment**: Update templates without code changes  
✅ **Professional**: Use SES template features  

---

## ✅ Summary

**Functions Added:**
- ✅ `create_ses_template()` - Create new template
- ✅ `update_ses_template()` - Update existing template  
- ✅ `delete_ses_template()` - Delete template
- ✅ `fetch_ses_templates()` - List all templates
- ✅ `get_ses_template()` - Get template details

**Templates Created:**
- ✅ professional-welcome
- ✅ document-notification
- ✅ invoice-template

**Ready to Use:**
- ✅ Create unlimited templates via API
- ✅ Update templates programmatically
- ✅ Delete old templates
- ✅ Full CRUD operations on SES templates
- ✅ Secure (using environment credentials)

**Your email system can now create and manage AWS SES templates programmatically!** 🎉

---

## 📧 NEW: Send Emails Using SES Template API

### **send_templated_email_ses()** - Send Email via SES Template API
Send emails directly using AWS SES template API (not SMTP) with credentials from EMAIL_CONFIG.

**Function:**
```python
send_templated_email_ses(to_email, from_email, template_name, template_data=None)
```

**Parameters:**
- `to_email` (str): Recipient email address (must be verified in SES sandbox)
- `from_email` (str): Sender email address (must be verified in SES)
  - Primary: `john@strobo.jp` (strobo.jp domain)
  - Backup: `hunter@qupio.jp` (qupio.jp domain)
- `template_name` (str): Name of the SES template to use
- `template_data` (dict, optional): Template variables as dictionary

**Returns:**
- Message ID (str) if successful
- None if failed

---

### Example 1: Send with Custom Template Data
```python
from main import send_templated_email_ses

template_data = {
    'firstname': 'John',
    'lastname': 'Smith',
    'email': 'john@example.com',
    'id': '12345',
    'randomnumber': '5678'
}

message_id = send_templated_email_ses(
    to_email='recipient@example.com',
    from_email='john@strobo.jp',
    template_name='welcome-email',
    template_data=template_data
)

if message_id:
    print(f"✅ Email sent! Message ID: {message_id}")
```

**Output:**
```
✅ SES template email sent to recipient@example.com | Message ID: 0102018da1234567-89abcdef-0123-4567-89ab-cdefghi01234-000000
```

---

### Example 2: Auto-Generate Random Data
If you don't provide template_data, random data is automatically generated:

```python
from main import send_templated_email_ses

message_id = send_templated_email_ses(
    to_email='recipient@example.com',
    from_email='john@strobo.jp',
    template_name='payment-confirmation'
)
```

**Auto-generated template data includes:**
- firstname (random from 50 names)
- lastname (random from 50 names)
- fullname (firstname + lastname)
- email (recipient's email)
- id (random 5-digit number)
- randomnumber (random 4-digit number)
- phone (random US format)
- date (random future date)

---

### Example 3: Using the Interactive Script
Run the provided example script:
```bash
python3 send_ses_api_example.py
```

This interactive script will:
1. Prompt for recipient email
2. Fetch all available SES templates
3. Let you select specific template or send all
4. Send emails using SES Template API (not SMTP)

---

## ⚠️ Important: AWS SES Sandbox Mode

Your AWS SES account is currently in **SANDBOX mode**, which means:
- ✅ Both sender AND recipient emails must be verified
- ✅ You can only send to verified email addresses
- ⚠️ Limited sending quota

**Verified Sender Emails:**
- ✅ `john@strobo.jp` (strobo.jp domain) - **Primary sender**
- ✅ `hunter@qupio.jp` (qupio.jp domain) - **Backup sender**

---

## 🆚 SES Template API vs SMTP Sending

| Feature | SES Template API | SMTP Method |
|---------|-----------------|-------------|
| **Method** | `send_templated_email()` | `smtplib` |
| **Templates** | Stored in AWS SES | Local HTML files |
| **Credentials** | AWS Access Key + Secret | SMTP user + pass |
| **Variables** | JSON template data | String replacement |
| **Speed** | ⚡ Faster (direct API) | 🐌 Slower (protocol) |
| **Headers** | Managed by AWS | Custom headers supported |
| **Use Case** | Template campaigns | Custom HTML emails |

---

## 🛠️ Error Handling

The function handles common errors gracefully:

### "MessageRejected: Email address is not verified"
**Cause:** Sender or recipient not verified in SES  
**Solution:** Verify both emails in AWS SES Console

### "ClientError: Invalid security token"
**Cause:** AWS credentials incorrect or expired  
**Solution:** Check AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables

### "Template not found"
**Cause:** Template name doesn't exist in SES  
**Solution:** Run `fetch_ses_templates()` to see available templates

---

## 📄 Example Script: send_ses_api_example.py

A complete interactive example is provided in `send_ses_api_example.py`:

```python
#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from main import send_templated_email_ses, fetch_ses_templates

# Fetch templates
templates = fetch_ses_templates()

# Send email
message_id = send_templated_email_ses(
    to_email='recipient@example.com',
    from_email='john@strobo.jp',
    template_name=templates[0],
    template_data={'firstname': 'John', 'lastname': 'Smith'}
)
```

**Run it:**
```bash
python3 send_ses_api_example.py
```

---

## 🚀 Complete Workflow Example

```python
from main import (
    create_ses_template, 
    fetch_ses_templates, 
    send_templated_email_ses
)

# 1. Create a new template
create_ses_template(
    'notification',
    'Alert for {{firstname}}',
    '<h1>Hi {{firstname}}!</h1><p>ID: {{id}}</p>',
    'Hi {{firstname}}! ID: {{id}}'
)

# 2. Verify it was created
templates = fetch_ses_templates()
print(f"Available: {templates}")

# 3. Send email using the template
message_id = send_templated_email_ses(
    to_email='recipient@example.com',
    from_email='john@strobo.jp',
    template_name='notification',
    template_data={'firstname': 'Alice', 'id': '99999'}
)

print(f"Sent! Message ID: {message_id}")
```

---

## 📊 Summary

**New Function Added:**
- ✅ `send_templated_email_ses()` - Send emails via SES Template API

**Features:**
- ✅ Uses AWS Access Key credentials from EMAIL_CONFIG
- ✅ Auto-generates random template data if not provided
- ✅ Returns Message ID on success
- ✅ Graceful error handling with detailed messages
- ✅ Faster than SMTP (direct API call)

**Files:**
- ✅ Function: `main.py` (line 585)
- ✅ Example: `send_ses_api_example.py`
- ✅ Documentation: `SES_TEMPLATE_API_GUIDE.md`

**Your email system can now send emails using AWS SES Template API!** 📧🚀
