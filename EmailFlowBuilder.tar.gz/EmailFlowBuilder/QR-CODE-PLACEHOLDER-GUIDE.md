# QR Code Placeholder Guide

## Overview
The QR code placeholder allows you to dynamically generate and embed QR codes directly into your email templates. QR codes are generated as base64-encoded PNG images and can be customized in size and content.

---

## 🎯 **QR Code Placeholder**

### **`{{qrcode}}`**

**Purpose:** Embed a dynamically generated QR code  
**Format:** Base64-encoded PNG image  
**Configuration:** `EMAIL_CONFIG` in main.py  
**Use Cases:** URLs, tracking links, contact info, payment links, app downloads

---

## 🔧 **How to Use**

### **Method 1: Simple Inline QR Code**

Add the placeholder anywhere in your HTML template:

```html
<div style="text-align: center; padding: 20px;">
    <h3>Scan to View Document</h3>
    {{qrcode}}
</div>
```

### **Method 2: Styled QR Code**

Wrap in a styled container:

```html
<table style="width: 100%; margin: 20px 0;">
    <tr>
        <td style="text-align: center; background: #f5f5f5; padding: 30px;">
            <h2>Quick Access</h2>
            <p>Scan this QR code with your phone</p>
            {{qrcode}}
            <p style="font-size: 12px; color: #666; margin-top: 15px;">
                Or click here: <a href="{{link}}">View Online</a>
            </p>
        </td>
    </tr>
</table>
```

### **Method 3: Side-by-Side with Content**

```html
<table style="width: 100%;">
    <tr>
        <td style="width: 60%; padding: 20px;">
            <h2>Document Ready for Signature</h2>
            <p>{{content}}</p>
            <a href="{{link}}">Review Document</a>
        </td>
        <td style="width: 40%; text-align: center; padding: 20px;">
            <p><strong>Quick Access</strong></p>
            {{qrcode}}
            <p style="font-size: 10px;">Scan to open</p>
        </td>
    </tr>
</table>
```

---

## ⚙️ **Configuration**

### **Enable QR Code**

Edit `main.py` and configure the `EMAIL_CONFIG` section:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    # QR Code Settings
    'enable_qr_code': True,              # Enable QR code generation
    'qr_code_data': 'https://example.com/document',  # URL or text to encode
    'qr_code_size': 300,                 # Size in pixels (default: 300)
    
    # ... other settings ...
}
```

### **Configuration Options**

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `enable_qr_code` | Boolean | `False` | Enable/disable QR code generation |
| `qr_code_data` | String | `''` | URL or text to encode in QR code |
| `qr_code_size` | Integer | `300` | QR code size in pixels (100-1000) |

---

## 📝 **Examples**

### **Example 1: Document Review Link**

**Configuration:**
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'https://yourcompany.com/review/doc-12345',
    'qr_code_size': 300,
}
```

**Template:**
```html
<table style="max-width: 600px; margin: 0 auto;">
    <tr>
        <td style="padding: 20px; text-align: center;">
            <img src="https://logo.clearbit.com/{{COMPANYLOGO}}" width="120">
        </td>
    </tr>
    <tr>
        <td style="padding: 30px; background: #f8f8f8;">
            <h2>Document Ready for Your Review</h2>
            <p>Your document is ready for signature.</p>
        </td>
    </tr>
    <tr>
        <td style="text-align: center; padding: 20px;">
            <h3>Scan to Review</h3>
            {{qrcode}}
            <p style="font-size: 12px; margin-top: 10px;">
                Scan with your mobile device
            </p>
        </td>
    </tr>
    <tr>
        <td style="text-align: center; padding: 20px;">
            <a href="{{link}}" style="background: #4CAF50; color: white; 
                                       padding: 15px 30px; text-decoration: none;">
                Review on Desktop
            </a>
        </td>
    </tr>
</table>
```

### **Example 2: Event Check-In**

**Configuration:**
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'EVENT-TICKET-ABC123',
    'qr_code_size': 400,
}
```

**Template:**
```html
<div style="max-width: 600px; margin: 0 auto; text-align: center;">
    <h1>Event Ticket</h1>
    <p>Your ticket for the Annual Conference</p>
    
    <div style="background: white; border: 2px solid #333; 
                padding: 20px; margin: 20px;">
        {{qrcode}}
    </div>
    
    <p><strong>Ticket ID:</strong> ABC123</p>
    <p style="font-size: 12px;">
        Present this QR code at check-in
    </p>
</div>
```

### **Example 3: Contact Card (vCard)**

**Configuration:**
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': '''BEGIN:VCARD
VERSION:3.0
FN:John Smith
TEL:+1-555-123-4567
EMAIL:john@example.com
END:VCARD''',
    'qr_code_size': 250,
}
```

**Template:**
```html
<table style="width: 100%; max-width: 600px;">
    <tr>
        <td style="padding: 20px; text-align: center;">
            <h2>Save My Contact</h2>
            <p>Scan to add me to your contacts</p>
            {{qrcode}}
        </td>
    </tr>
</table>
```

### **Example 4: App Download**

**Configuration:**
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'https://apps.apple.com/app/your-app',
    'qr_code_size': 350,
}
```

**Template:**
```html
<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            padding: 40px; text-align: center; color: white;">
    <h1>Download Our App</h1>
    <p>Scan the QR code to download</p>
    
    <div style="background: white; display: inline-block; 
                padding: 20px; margin: 20px; border-radius: 10px;">
        {{qrcode}}
    </div>
    
    <p>Available on iOS and Android</p>
</div>
```

---

## 🎨 **Styling QR Codes**

### **Centered with Border**

```html
<div style="text-align: center; padding: 20px;">
    <div style="display: inline-block; border: 3px solid #333; 
                padding: 15px; background: white;">
        {{qrcode}}
    </div>
</div>
```

### **With Background Color**

```html
<div style="background: #f0f0f0; padding: 30px; text-align: center;">
    {{qrcode}}
</div>
```

### **Rounded Corners**

```html
<div style="text-align: center;">
    <div style="display: inline-block; overflow: hidden; 
                border-radius: 15px;">
        {{qrcode}}
    </div>
</div>
```

### **Shadow Effect**

```html
<div style="text-align: center; padding: 20px;">
    <div style="display: inline-block; 
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        {{qrcode}}
    </div>
</div>
```

---

## 🔄 **Dynamic QR Codes (Per Recipient)**

To generate unique QR codes for each recipient, you would need to modify `main.py`:

```python
# In the sending loop (around line 1106)
for i, contact in enumerate(contacts, 1):
    # Generate unique tracking URL for this recipient
    unique_url = f"https://example.com/track/{contact.replace('@', '-')}"
    
    # Generate QR code for this specific recipient
    qr_base64 = generate_qr_code(unique_url, 300)
    
    # Replace placeholder
    html_content = embed_qr_code_in_html(html_content, qr_base64, 300)
```

---

## 📊 **QR Code Specifications**

### **Technical Details**

| Property | Value |
|----------|-------|
| Format | PNG image |
| Encoding | Base64 |
| Error Correction | High (30% damage tolerance) |
| Default Size | 300x300 pixels |
| Min Size | 100x100 pixels |
| Max Size | 1000x1000 pixels |
| Data Capacity | Up to 4,296 alphanumeric characters |

### **Recommended Sizes**

| Use Case | Size | Reasoning |
|----------|------|-----------|
| Email signature | 150px | Small, unobtrusive |
| Event ticket | 400px | Large, easy to scan |
| Document link | 300px | Standard, balanced |
| Contact card | 250px | Medium, mobile-friendly |
| Payment code | 350px | Large for accuracy |

---

## 🎯 **Common Use Cases**

### **1. Document Tracking**
```python
'qr_code_data': 'https://docs.company.com/view/DOC-12345'
```

### **2. Event Registration**
```python
'qr_code_data': 'https://events.company.com/register?code=ABC123'
```

### **3. Payment Link**
```python
'qr_code_data': 'https://pay.company.com/invoice/INV-001'
```

### **4. Survey/Feedback**
```python
'qr_code_data': 'https://survey.company.com/feedback?id=USER123'
```

### **5. Wi-Fi Credentials**
```python
'qr_code_data': 'WIFI:T:WPA;S:NetworkName;P:Password123;;'
```

### **6. Location/Map**
```python
'qr_code_data': 'https://maps.google.com/?q=40.7128,-74.0060'
```

### **7. App Deep Link**
```python
'qr_code_data': 'yourapp://action/view?item=12345'
```

### **8. Plain Text**
```python
'qr_code_data': 'TICKET-CODE: XYZ789 - GATE: A3 - SEAT: 12C'
```

---

## 🔍 **How It Works Behind the Scenes**

### **Generation Process**

1. **QR Code Generation:**
   ```python
   qr_img = qrcode.make(data)
   ```

2. **Convert to Base64:**
   ```python
   img_base64 = base64.b64encode(img_bytes).decode()
   ```

3. **Create HTML Image Tag:**
   ```python
   img_tag = f'<img src="data:image/png;base64,{img_base64}" 
                   width="{size}" 
                   alt="QR Code">'
   ```

4. **Replace Placeholder:**
   ```python
   html = html.replace('{{qrcode}}', img_tag)
   ```

---

## ✅ **Best Practices**

### **DO:**

- ✅ Test QR codes before sending bulk emails
- ✅ Use HTTPS URLs for security
- ✅ Keep QR data under 200 characters for best scanning
- ✅ Size QR codes appropriately (300px recommended)
- ✅ Provide fallback text/link for accessibility
- ✅ Test on multiple QR code readers
- ✅ Use high error correction for important data

### **DON'T:**

- ❌ Make QR codes too small (<150px)
- ❌ Use low contrast backgrounds
- ❌ Encode sensitive data without encryption
- ❌ Forget to test on mobile devices
- ❌ Use QR codes as the only call-to-action
- ❌ Exceed 1000px size (unnecessary)
- ❌ Use special characters that break URLs

---

## 🐛 **Troubleshooting**

### **QR Code Not Showing**

**Problem:** `{{qrcode}}` appears as text

**Solutions:**
1. Enable QR codes in config: `'enable_qr_code': True`
2. Set QR data: `'qr_code_data': 'https://example.com'`
3. Verify `generate_qr_code()` function exists
4. Check template has `{{qrcode}}` placeholder

### **QR Code Too Small/Large**

**Problem:** QR code doesn't display at right size

**Solutions:**
1. Adjust `qr_code_size` in config (100-1000)
2. For email: 300px recommended
3. For printing: 500px or higher

### **QR Code Won't Scan**

**Problem:** QR code reader can't read code

**Solutions:**
1. Increase size (try 400px)
2. Simplify encoded data (shorter URLs)
3. Check URL is valid and accessible
4. Ensure high contrast with background
5. Test with multiple QR readers

---

## 📱 **Mobile Optimization**

### **Responsive QR Code**

```html
<div style="text-align: center; padding: 20px;">
    <div style="max-width: 300px; margin: 0 auto;">
        {{qrcode}}
    </div>
    <p style="font-size: 14px; margin-top: 10px;">
        <a href="{{link}}" style="color: #0066cc;">
            Can't scan? Click here
        </a>
    </p>
</div>
```

### **Desktop vs Mobile**

```html
<!-- Desktop: Show button, Mobile: Show QR -->
<div style="text-align: center;">
    <!-- Desktop button (hidden on mobile) -->
    <a href="{{link}}" 
       style="display: inline-block; padding: 15px 30px; 
              background: #4CAF50; color: white;">
        View Document
    </a>
    
    <!-- Mobile QR code (could be shown on both) -->
    <div style="margin-top: 20px;">
        <p>Or scan with your phone:</p>
        {{qrcode}}
    </div>
</div>
```

---

## 🚀 **Advanced Examples**

### **Multiple QR Codes in One Email**

Currently, the system supports one QR code per email. To add multiple, you'd need to:

1. Generate different QR codes
2. Replace with unique placeholders
3. Or modify the system to support `{{qrcode1}}`, `{{qrcode2}}`, etc.

### **QR Code with Logo Overlay**

Requires custom implementation in `generate_qr_code()` function to overlay company logo in center.

---

## 📋 **Quick Reference**

### **Basic Setup**

```python
# main.py - EMAIL_CONFIG
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'https://your-url.com',
    'qr_code_size': 300,
}
```

### **Template Usage**

```html
<!-- Centered QR code -->
<div style="text-align: center;">
    {{qrcode}}
</div>
```

### **Complete Example**

```html
<table style="width: 600px; margin: 0 auto;">
    <tr>
        <td style="text-align: center; padding: 40px;">
            <h2>Quick Access</h2>
            <p>Scan to view your document</p>
            {{qrcode}}
            <p style="font-size: 12px; margin-top: 15px;">
                Or <a href="{{link}}">click here</a>
            </p>
        </td>
    </tr>
</table>
```

---

## 📚 **Related Documentation**

- **PLACEHOLDER-REFERENCE.md** - All available placeholders
- **DISCLAIMER-ROTATION-GUIDE.md** - Disclaimer system
- **main.py** - QR code generation functions

---

**QR code placeholder is ready to use in your email templates!** 🎉

Simply add `{{qrcode}}` to any template and configure in `EMAIL_CONFIG`.
