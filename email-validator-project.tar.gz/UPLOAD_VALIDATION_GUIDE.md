# Email Upload & Auto-Organization Guide

## ✨ Automatic Email Validation & Organization

When you run the validation script with a CSV file, it automatically:

1. ✅ Validates all emails (format + MX records)
2. 📊 Detects email providers (Microsoft, Google, Office365, GoDaddy, Mimecast, ARSMTP)
3. 📁 **Organizes results into categorized files and folders**
4. 📝 Generates a summary report

---

## 🚀 Quick Start

### Basic Usage

```bash
python validate_upload.py your_emails.csv
```

That's it! Results will be organized in the `validation_output` folder.

### With Custom Session Name

```bash
python validate_upload.py customers.csv --session-id customer_emails
```

### Limit Number of Emails

```bash
python validate_upload.py large_list.csv --max-emails 5000
```

---

## 📁 Output Structure

After validation, you'll get a **timestamped folder** with organized results:

```
validation_output/
└── 20251121_012040/                    # Session folder (timestamp or custom)
    ├── SUMMARY.txt                     # Human-readable summary report
    ├── full_results.csv                # Complete validation data
    ├── by_status/                      # Organized by deliverability
    │   ├── deliverable.txt            # All deliverable emails
    │   ├── undeliverable.txt          # Failed MX lookup
    │   └── invalid_format.txt         # Invalid email format
    ├── by_provider/                    # Organized by email provider
    │   ├── microsoft_emails.txt       # outlook.com, hotmail.com, live.com
    │   ├── google_emails.txt          # gmail.com, googlemail.com
    │   ├── office365_emails.txt       # Office 365 business emails
    │   ├── godaddy_emails.txt         # GoDaddy hosted emails
    │   ├── mimecast_emails.txt        # Mimecast protected emails
    │   ├── arsmtp_emails.txt          # ARSMTP emails
    │   └── unknown_emails.txt         # Other deliverable emails
    └── by_domain/                      # (Future: Domain grouping)
```

---

## 📊 What You Get

### 1. **SUMMARY.txt** - Quick Overview

```
============================================================
EMAIL VALIDATION SUMMARY REPORT
============================================================
Generated: 2025-11-21 01:20:40
Session Folder: test_run

OVERALL STATISTICS
------------------------------------------------------------
Total Emails Processed: 6
Valid Format: 5 (83%)
Deliverable: 4 (66%)
Undeliverable: 2 (33%)

PROVIDER BREAKDOWN (Deliverable Only)
------------------------------------------------------------
Microsoft       :     2 emails ( 50%)
Google          :     1 emails ( 25%)
Unknown         :     1 emails ( 25%)

OUTPUT FILES CREATED
------------------------------------------------------------
...
```

### 2. **full_results.csv** - Complete Data

```csv
email,domain,is_valid,is_deliverable,provider,is_microsoft,is_google,...
john@gmail.com,gmail.com,True,True,Google,False,True,...
jane@outlook.com,outlook.com,True,True,Microsoft,True,False,...
```

### 3. **Status-based Files** - Quick Filtering

- `deliverable.txt` - Ready to use emails (one per line)
- `undeliverable.txt` - Failed delivery test
- `invalid_format.txt` - Malformed emails

### 4. **Provider-based Files** - Targeting

Each provider gets its own file with just their emails:

```
# microsoft_emails.txt
charlie@hotmail.com
jane@outlook.com

# google_emails.txt
john@gmail.com
```

---

## 💡 Use Cases

### 1. **Clean Your Contact List**

```bash
python validate_upload.py customer_contacts.csv --session-id customers_2024
```

Then use:
- `by_status/deliverable.txt` → Import into your CRM
- `by_status/undeliverable.txt` → Remove from database

### 2. **Segment by Provider**

```bash
python validate_upload.py newsletter_list.csv --session-id newsletter
```

Then use:
- `by_provider/microsoft_emails.txt` → Send via Outlook-optimized route
- `by_provider/google_emails.txt` → Send via Gmail-optimized route

### 3. **Bulk Email Verification**

```bash
python validate_upload.py scraped_emails.csv
```

Get instant breakdown of:
- How many are valid
- Provider distribution
- Which ones to keep/discard

---

## 📋 CSV File Format

Your CSV can be **any format** - the script auto-detects emails:

### Simple List
```csv
user1@example.com
user2@gmail.com
admin@company.com
```

### With Headers
```csv
Name,Email,Phone
John Doe,john@example.com,555-1234
Jane Smith,jane@gmail.com,555-5678
```

### Multiple Columns
```csv
First,Last,Email,Company,Title
John,Doe,john@acme.com,Acme Corp,Manager
Jane,Smith,jane@tech.io,Tech Inc,Developer
```

The script finds emails automatically!

---

## 🎯 Sample Output

### Console Output

```
============================================================
📧 EMAIL VALIDATOR - CLI MODE
============================================================

📂 Reading CSV file: sample_emails.csv
✅ Found 6 emails

🔍 Validating emails...

✅ Validation complete!
   Total processed: 6
   New validations: 6
   From cache: 0

📁 Organizing results into folders...

✅ Results organized successfully!

============================================================
📊 VALIDATION SUMMARY
============================================================

Session ID: test_run
Output Folder: validation_output/test_run

Total Emails: 6
Valid Format: 5 (83%)
Deliverable: 4 (66%)
Undeliverable: 2

Provider Breakdown (Deliverable):
------------------------------------------------------------
  Microsoft       :     2 emails
  Google          :     1 emails

Created Files:
------------------------------------------------------------

📄 Full Results:
   validation_output/test_run/full_results.csv

📋 Status-based:
   validation_output/test_run/by_status/deliverable.txt
   validation_output/test_run/by_status/undeliverable.txt

🏢 Provider-based:
   validation_output/test_run/by_provider/microsoft_emails.txt
   validation_output/test_run/by_provider/google_emails.txt

============================================================
✨ Validation Complete!
============================================================
```

---

## 🔧 Command Options

### Required
- `csv_file` - Path to your CSV file

### Optional
- `--session-id <name>` - Custom folder name (default: timestamp)
- `--max-emails <number>` - Limit processing (default: 10,000)

### Examples

```bash
# Basic validation
python validate_upload.py emails.csv

# Custom session name
python validate_upload.py leads.csv --session-id q4_leads

# Limit to 1000 emails
python validate_upload.py huge_list.csv --max-emails 1000

# Combine options
python validate_upload.py data.csv --session-id test --max-emails 500
```

---

## 📦 What's Included in Each File

### Status Files (`by_status/`)

**deliverable.txt**
- Emails that passed MX record check
- Sorted and deduplicated
- One email per line
- Ready to import anywhere

**undeliverable.txt**
- Failed MX record lookup
- Domain doesn't accept email
- Should be removed from lists

**invalid_format.txt**
- Malformed email addresses
- Missing @ symbol
- Invalid characters
- Syntax errors

### Provider Files (`by_provider/`)

**microsoft_emails.txt**
- outlook.com, hotmail.com
- live.com, msn.com
- passport.com

**google_emails.txt**
- gmail.com
- googlemail.com
- Verified by MX records

**office365_emails.txt**
- Business emails on Office 365
- Detected via MX: `*.protection.outlook.com`

**godaddy_emails.txt**
- GoDaddy hosted emails
- secureserver.net MX records

**mimecast_emails.txt**
- Mimecast protected emails

**arsmtp_emails.txt**
- ARSMTP/Hornetsecurity emails

**unknown_emails.txt**
- Deliverable but not categorized
- Could be custom mail servers

---

## 🔍 Performance

### Speed
- ~10-50ms per email
- Parallel DNS lookups
- Caching for duplicates
- **1,000 emails ≈ 10-30 seconds**

### Limits
- Max 10,000 emails per run (adjustable)
- 5-second timeout per DNS lookup
- Automatic deduplication in output files

---

## 💾 File Formats

### Text Files (.txt)
- One email per line
- Sorted alphabetically
- Automatically deduplicated
- UTF-8 encoded

### CSV Files (.csv)
- Full validation data
- All fields included
- Compatible with Excel
- Headers included

---

## 🎁 Bonus Features

✅ **Automatic Caching** - Duplicate emails validated once  
✅ **Progress Tracking** - Real-time validation progress  
✅ **Error Handling** - Graceful failure recovery  
✅ **Duplicate Removal** - Clean output files  
✅ **Sorting** - Alphabetically sorted results  
✅ **Unicode Support** - International emails supported  

---

## 🚨 Troubleshooting

### "File not found"
```bash
# Check file exists
ls -la your_file.csv

# Use full path
python validate_upload.py /path/to/emails.csv
```

### "No emails found"
- Check CSV encoding (should be UTF-8)
- Verify emails have @ symbol
- Try opening in text editor first

### "Permission denied"
```bash
# Make script executable
chmod +x validate_upload.py

# Or run with python explicitly
python3 validate_upload.py emails.csv
```

---

## 📖 Next Steps

1. **Try it**: Run with your CSV file
2. **Check output**: Look in `validation_output/` folder
3. **Use results**: Import deliverable.txt into your system
4. **Automate**: Add to your data pipeline

---

## 🔄 Integration Examples

### Shell Script
```bash
#!/bin/bash
# Daily email validation
python validate_upload.py daily_signups.csv --session-id "daily_$(date +%Y%m%d)"
```

### Cron Job
```cron
# Validate every day at 2 AM
0 2 * * * cd /path/to/validator && python validate_upload.py /data/emails.csv
```

### Python Integration
```python
import subprocess

result = subprocess.run([
    'python', 'validate_upload.py',
    'contacts.csv',
    '--session-id', 'batch_001'
])

if result.returncode == 0:
    print("Validation successful!")
```

---

**Happy Validating!** 📧✨

For more help:
- Run: `python validate_upload.py --help`
- Check: `STANDALONE_README.md` for standalone script
- See: `replit.md` for full web application
