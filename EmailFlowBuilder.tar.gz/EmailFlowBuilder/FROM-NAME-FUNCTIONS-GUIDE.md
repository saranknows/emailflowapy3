# From Name Management Functions Guide

## Overview
Control from name rotation with 5 management functions that allow you to enable/disable rotation, set custom defaults, and monitor from name configuration.

---

## 🔧 **Available Functions (5 Total)**

### **1. Enable From Names**

```python
enable_from_names()
```

**Purpose:** Turn on from name rotation  
**Returns:** `True`  
**Effect:** Rotates through all names in `from_names/from_names.txt`

**Example:**
```python
>>> enable_from_names()
✅ From name rotation enabled
```

---

### **2. Disable From Names**

```python
disable_from_names()
```

**Purpose:** Turn off from name rotation and use default name  
**Returns:** `True`  
**Effect:** All emails use the same default from name

**Example:**
```python
>>> disable_from_names()
✅ From name rotation disabled
   Using default name: Customer Support
```

---

### **3. Get From Name Status**

```python
get_from_name_status()
```

**Purpose:** Check current from name configuration  
**Returns:** Dictionary with status information

**Example:**
```python
>>> status = get_from_name_status()
>>> print(status['mode'])
From Names: ON | Names: 8

>>> print(status)
{
    'from_names_enabled': True,
    'default_from_name': 'Customer Support',
    'available_names': 8,
    'mode': 'From Names: ON | Names: 8'
}
```

**Return Values:**
- `from_names_enabled`: Boolean (True/False)
- `default_from_name`: String (default name when disabled)
- `available_names`: Integer (count of names in file)
- `mode`: String (summary status)

---

### **4. Set Default From Name**

```python
set_default_from_name(name)
```

**Purpose:** Set the default from name to use when rotation is disabled  
**Args:** `name` - String display name  
**Returns:** `True`

**Example:**
```python
>>> set_default_from_name('Sales Team')
✅ Default from name set to: Sales Team

>>> disable_from_names()
✅ From name rotation disabled
   Using default name: Sales Team
```

**Common Defaults:**
- `'Customer Support'`
- `'Sales Team'`
- `'Marketing Team'`
- `'Help Desk'`
- `'Account Manager'`
- `'Service Team'`

---

### **5. Count From Names**

```python
count_from_names()
```

**Purpose:** Get total count of available from names  
**Returns:** Integer count

**Example:**
```python
>>> count = count_from_names()
>>> print(f'Total names: {count}')
Total names: 8
```

---

## ⚙️ **Configuration**

### **EMAIL_CONFIG Settings**

Located in `main.py` around line 77:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    # From Name Configuration
    'enable_from_names': True,  # Enable/disable rotation
    'default_from_name': 'Customer Support',  # Default when disabled
    
    # ... other settings ...
}
```

### **Configuration Options**

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `enable_from_names` | Boolean | `True` | Enable/disable from name rotation |
| `default_from_name` | String | `'Customer Support'` | Name to use when rotation is disabled |

---

## 📋 **Usage Examples**

### **Example 1: Enable From Name Rotation**

```python
# Turn on rotation (uses all names in file)
enable_from_names()

# Check status
status = get_from_name_status()
print(status['mode'])
# Output: From Names: ON | Names: 8
```

**Result:** Each email uses a different from name, rotating through all 8 names.

---

### **Example 2: Disable From Name Rotation**

```python
# Turn off rotation (uses default name only)
disable_from_names()

# Check status
status = get_from_name_status()
print(f"Using: {status['default_from_name']}")
# Output: Using: Customer Support
```

**Result:** All emails use "Customer Support" as the from name.

---

### **Example 3: Use Custom Default Name**

```python
# Set custom default
set_default_from_name('VIP Support Team')

# Disable rotation to use the default
disable_from_names()
# Output: ✅ From name rotation disabled
#         Using default name: VIP Support Team
```

**Result:** All emails display "VIP Support Team" as sender name.

---

### **Example 4: Check Available Names**

```python
# Count names
count = count_from_names()
print(f'Available: {count}')
# Output: Available: 8

# Get detailed status
status = get_from_name_status()
print(f"Enabled: {status['from_names_enabled']}")
print(f"Names available: {status['available_names']}")
print(f"Default: {status['default_from_name']}")
```

---

### **Example 5: Toggle Rotation On/Off**

```python
# Disable for personal campaign
disable_from_names()
set_default_from_name('John Smith')
# All emails from: John Smith <email@domain.com>

# Later, enable for bulk campaign
enable_from_names()
# Emails rotate: Customer Support, Marketing Team, Sales...
```

---

## 🎯 **How It Works**

### **When Rotation is ENABLED:**

```python
enable_from_names()

# Campaign sends to 10 contacts with 8 from names:
# Email #1 → From: Customer Support <info@domain.com>
# Email #2 → From: Marketing Team <support@domain.com>
# Email #3 → From: Sales Department <contact@domain.com>
# Email #4 → From: Information Desk <sales@domain.com>
# Email #5 → From: Help Center <service@domain.com>
# Email #6 → From: Account Manager <help@domain.com>
# Email #7 → From: Service Team <team@domain.com>
# Email #8 → From: Support Staff <noreply@domain.com>
# Email #9 → From: Customer Support <notifications@domain.com> (cycles back)
# Email #10 → From: Marketing Team <updates@domain.com>
```

**Result:** Maximum variation across emails.

---

### **When Rotation is DISABLED:**

```python
disable_from_names()
# Uses: 'Customer Support' (or custom default)

# Campaign sends to 10 contacts:
# Email #1 → From: Customer Support <info@domain.com>
# Email #2 → From: Customer Support <support@domain.com>
# Email #3 → From: Customer Support <contact@domain.com>
# Email #4 → From: Customer Support <sales@domain.com>
# Email #5 → From: Customer Support <service@domain.com>
# ... all use same from name ...
```

**Result:** Consistent sender name, only email address rotates.

---

## 📊 **Status Display**

When running campaigns, you'll see:

### **With Rotation ON:**
```
✍️  Loaded 8 sender names
```

### **With Rotation OFF:**
```
ℹ️  From name rotation is disabled - using default: Customer Support
```

---

## 🔄 **Integration with Other Features**

### **From Name + From Email Rotation:**

```python
enable_from_names()
# Result: Both name AND email rotate
# Example: Marketing Team <support@domain1.com>
#          Sales Department <contact@domain2.com>
```

### **From Name Only (Email Rotation Disabled):**

```python
enable_from_names()
# Use single email in from_emails/fromemails.txt
# Result: Name rotates, email stays same
# Example: Customer Support <info@domain.com>
#          Marketing Team <info@domain.com>
```

### **No Rotation (Single Name + Email):**

```python
disable_from_names()
set_default_from_name('Support Team')
# Use single email in from_emails/fromemails.txt
# Result: All emails identical
# Example: Support Team <info@domain.com>
#          Support Team <info@domain.com>
```

---

## 💡 **Use Cases**

### **Use Case 1: Personal Email Campaign**

```python
# Sending as yourself
disable_from_names()
set_default_from_name('Sarah Johnson')
# All emails: Sarah Johnson <sarah@company.com>
```

### **Use Case 2: Department Campaign**

```python
# Sending from specific department
disable_from_names()
set_default_from_name('Sales Department')
# All emails: Sales Department <sales@company.com>
```

### **Use Case 3: Maximum Variation Campaign**

```python
# Bulk campaign with variety
enable_from_names()
# Rotates: Customer Support, Marketing, Sales, etc.
```

### **Use Case 4: Testing**

```python
# Test with single name first
disable_from_names()
set_default_from_name('Test User')
# Send test batch...

# Then enable for production
enable_from_names()
# Send full campaign
```

---

## 📁 **File Location**

**From Names File:**
```
from_names/from_names.txt
```

**Current Names (8 total):**
```
Customer Support
Marketing Team
Sales Department
Information Desk
Help Center
Account Manager
Service Team
Support Staff
```

**To Add More Names:**
1. Edit `from_names/from_names.txt`
2. Add one name per line
3. Save and run campaign

---

## 🔧 **Quick Reference**

### **Enable Rotation:**
```python
enable_from_names()
```

### **Disable Rotation:**
```python
disable_from_names()
```

### **Set Custom Default:**
```python
set_default_from_name('Your Name Here')
```

### **Check Status:**
```python
status = get_from_name_status()
print(status['mode'])
```

### **Count Names:**
```python
count = count_from_names()
print(f'Total: {count}')
```

---

## ✅ **Summary**

**5 From Name Functions:**
1. `enable_from_names()` - Turn rotation ON
2. `disable_from_names()` - Turn rotation OFF
3. `get_from_name_status()` - Check current status
4. `set_default_from_name(name)` - Set custom default
5. `count_from_names()` - Count available names

**Configuration:**
- `enable_from_names`: True/False
- `default_from_name`: String (default name)

**File:**
- `from_names/from_names.txt` (8 names)

**Use Cases:**
- Personal campaigns (disable, set custom name)
- Department campaigns (disable, set department name)
- Bulk campaigns (enable for maximum variation)
- Testing (disable for consistency, enable for production)

---

**Your from name rotation system is fully controllable with 5 management functions!** 📧
