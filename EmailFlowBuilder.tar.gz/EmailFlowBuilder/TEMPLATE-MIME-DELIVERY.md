# Template MIME Delivery - How It Works

## Overview
All templates are automatically delivered as **MIME-formatted emails with HTML body**. This document explains the complete flow from template file to MIME delivery.

---

## 📋 **Template Processing Flow**

### **Step 1: Template Loading**
```python
# Templates loaded from templates/ folder
template_files = load_templates()
# Returns: ['template01.html', 'template02.html', ..., 'template11.html']
```

### **Step 2: Template Rotation**
```python
# Create rotation cycle
template_cycle = cycle(templates)

# Get next template for each email
template_name, template_content = next(template_cycle)
```

### **Step 3: Placeholder Replacement**
```python
# Replace all placeholders in template
html_content = template_content

# 1. Random data placeholders (automatic)
html_content = replace_template_placeholders(html_content)
# {{firstname}} → "Michael"
# {{randomnumber}} → "45821"
# {{email}} → "john.smith@gmail.com"

# 2. Link placeholders
html_content = html_content.replace('{{link}}', 'https://example.com')
html_content = html_content.replace('{{website}}', 'https://website.com')

# 3. Logo placeholder
html_content = html_content.replace('{{COMPANYLOGO}}', 'example.com')

# 4. Disclaimer placeholder
html_content = html_content.replace('{{disclaimer}}', disclaimer_text)
```

### **Step 4: MIME Conversion & Delivery**
```python
# send_email() creates MIME structure
send_email(smtp_server, from_email, to_email, subject, html_content)

# Inside send_email():
# 1. Create root MIME message
root_msg = MIMEMultipart('alternative')

# 2. Generate plain text fallback
plain_text = strip_html_tags(html_content)

# 3. Create MIME parts
text_part = MIMEText(plain_text, 'plain', 'utf-8')  # Fallback
html_part = MIMEText(html_content, 'html', 'utf-8')  # PRIMARY - DISPLAYED

# 4. Attach parts (order matters!)
root_msg.attach(text_part)   # Lower priority
root_msg.attach(html_part)   # Higher priority ← EMAIL CLIENTS SHOW THIS

# 5. Send as MIME
smtp_server.sendmail(from_email, to_email, root_msg.as_string())
```

---

## 🎯 **Template Example**

### **Original Template File** (template10-docusign-lime.html)
```html
<!DOCTYPE html>
<html>
<head>
    <style>
        .document { background: #84cc16; padding: 20px; }
        .button { background: #10b981; color: white; padding: 10px; }
    </style>
</head>
<body>
    <div class="document">
        <h1>Signature Required</h1>
        <p>Dear {{firstname}} {{lastname}},</p>
        <p>Document ID: {{randomnumber}}</p>
        <p>Due Date: {{date}}</p>
        <a href="{{link}}" class="button">Sign Now</a>
        <p>{{disclaimer}}</p>
    </div>
</body>
</html>
```

### **After Placeholder Replacement**
```html
<!DOCTYPE html>
<html>
<head>
    <style>
        .document { background: #84cc16; padding: 20px; }
        .button { background: #10b981; color: white; padding: 10px; }
    </style>
</head>
<body>
    <div class="document">
        <h1>Signature Required</h1>
        <p>Dear Michael Smith,</p>
        <p>Document ID: 45821</p>
        <p>Due Date: 12/15/2025</p>
        <a href="https://example.com/sign" class="button">Sign Now</a>
        <p>This email may contain confidential information...</p>
    </div>
</body>
</html>
```

### **Delivered as MIME**
```
From: Customer Support <info@example.com>
To: recipient@example.com
Subject: Urgent: Action Required
Date: Thu, 20 Nov 2025 10:30:45 -0800
Message-ID: <unique-id@example.com>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="===============1234=="

--===============1234==
Content-Type: text/plain; charset="utf-8"

Signature Required
Dear Michael Smith,
Document ID: 45821
Due Date: 12/15/2025
Sign Now
This email may contain confidential information...

--===============1234==
Content-Type: text/html; charset="utf-8"

<!DOCTYPE html>
<html>
<head>
    <style>
        .document { background: #84cc16; padding: 20px; }
        .button { background: #10b981; color: white; padding: 10px; }
    </style>
</head>
<body>
    <div class="document">
        <h1>Signature Required</h1>
        <p>Dear Michael Smith,</p>
        <p>Document ID: 45821</p>
        <p>Due Date: 12/15/2025</p>
        <a href="https://example.com/sign" class="button">Sign Now</a>
        <p>This email may contain confidential information...</p>
    </div>
</body>
</html>

--===============1234==--
```

### **What Recipients See** (99%+ of email clients)
A beautifully formatted HTML email with:
- ✅ Lime green background
- ✅ Professional layout
- ✅ Personalized name: "Michael Smith"
- ✅ Unique document ID: "45821"
- ✅ Clickable green button
- ✅ Full CSS styling applied

---

## 🔄 **Complete System Flow**

```
1. LOAD TEMPLATES
   ↓
   templates/ folder → ['template01.html', ..., 'template11.html']

2. CREATE ROTATION CYCLE
   ↓
   cycle(templates) → Infinite rotation

3. FOR EACH EMAIL:
   ↓
   Get next template → template10-docusign-lime.html

4. REPLACE PLACEHOLDERS
   ↓
   {{firstname}} → "Michael"
   {{randomnumber}} → "45821"
   {{link}} → "https://example.com"
   {{disclaimer}} → "Legal disclaimer text..."

5. CREATE MIME STRUCTURE
   ↓
   root_msg = MIMEMultipart('alternative')
   ├── Headers (From, To, Subject, Date, etc.)
   ├── text/plain (fallback)
   └── text/html (PRIMARY - DISPLAYED) ← Your template here

6. SEND VIA SMTP
   ↓
   Amazon SES receives MIME message

7. RECIPIENT SEES
   ↓
   Beautiful HTML email with full formatting
```

---

## ✅ **Confirmed: Templates Delivered as MIME Body**

**Test Results (Just Completed):**
```
✅ Template: template10-docusign-lime.html
✅ Loaded: HTML content with placeholders
✅ Processed: All placeholders replaced
✅ MIME Structure: multipart/alternative created
✅ Plain Text: Auto-generated fallback
✅ HTML Body: Template delivered as primary content
✅ Sent: Successfully via Amazon SES
✅ Status: Delivered to leanne@moretonbayrecycling.com.au
```

**Your templates are 100% MIME-compliant and delivered as HTML body!** 📧
