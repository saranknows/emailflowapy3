# Attachment Rotation Control Guide

## Overview

The email marketing platform now includes **attachment rotation on/off control** in `main.py`. This allows you to choose between rotating through all attachments, using a single specific attachment, or sending emails without any attachments.

## Available Functions

### 1. enable_attachment_rotation()
Enable attachment rotation to use all available attachments

### 2. disable_attachment_rotation(attachment_name=None)
Disable attachment rotation and use a single specific attachment

### 3. set_attachment(attachment_name)
Set a specific attachment to use (automatically enables attachments and disables rotation)

### 4. disable_attachments()
Disable all attachments - don't send any attachments

### 5. get_attachment_rotation_status()
Get current attachment rotation status

## Configuration

```python
EMAIL_CONFIG = {
    'enable_attachments': False,  # Set to True to enable attachments
    'attachment_rotation': True,   # True = all attachments, False = single
    'selected_attachment': '',     # Used when rotation is OFF
}
```

## Supported File Types

- PDF (.pdf)
- SVG (.svg)
- HTML (.html)
- MHTML (.mhtml)
- EML (.eml)

