import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import express from "express";
import crypto from "crypto";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { z } from "zod";
import dns from "dns/promises";
import multer from "multer";
import csvParser from "csv-parser";
import { Readable } from "stream";
import rateLimit from "express-rate-limit";
import { db } from "./db";
import {
  users,
  emailValidations,
  campaigns,
  trackingLinks,
  clickEvents,
  licenseKeys,
  type User,
  singleEmailValidationSchema,
  bulkEmailValidationSchema,
  createCampaignSchema,
  generateTrackingLinksSchema,
} from "@shared/schema";
import { eq, desc, sql, and } from "drizzle-orm";

// JWT Configuration
const JWT_SECRET = process.env.SESSION_SECRET || "your-secret-key-change-in-production";
const JWT_EXPIRES_IN = "7d";

// Rate limiting configuration
const authLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60, // 60 requests per minute
  message: "Too many requests, please try again later",
});

const validationLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 validation requests per minute (allows bulk operations)
  message: "Too many validation requests, please try again later",
});

// Extend Express Request to include cookies
declare global {
  namespace Express {
    interface Request {
      user?: User;
      cookies: {
        access_token?: string;
        [key: string]: string | undefined;
      };
    }
  }
}

// Middleware to verify JWT token
const authenticateToken = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from cookie
    const token = req.cookies.access_token;

    if (!token) {
      return res.status(401).json({ detail: "Not authenticated" });
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };

    // Get user from database
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, decoded.userId))
      .limit(1);

    if (!user) {
      return res.status(401).json({ detail: "User not found" });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ detail: "Invalid or expired token" });
  }
};

// Email validation logic
interface EmailValidationResult {
  email: string;
  domain: string;
  isValid: boolean;
  isDeliverable: boolean;
  provider: string | null;
  isMicrosoft: boolean;
  isGoogle: boolean;
  isOffice365: boolean;
  isMimecast: boolean;
  isArsmtp: boolean;
  isGodaddy: boolean;
  mxRecords: string[];
  validationTime: number;
}

async function validateEmailWithDNS(email: string): Promise<EmailValidationResult> {
  const startTime = Date.now();

  // Basic format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValid = emailRegex.test(email);

  if (!isValid) {
    return {
      email,
      domain: "",
      isValid: false,
      isDeliverable: false,
      provider: null,
      isMicrosoft: false,
      isGoogle: false,
      isOffice365: false,
      isMimecast: false,
      isArsmtp: false,
      isGodaddy: false,
      mxRecords: [],
      validationTime: Date.now() - startTime,
    };
  }

  const domain = email.split("@")[1];
  let mxRecords: string[] = [];
  let isDeliverable = false;

  try {
    // DNS MX lookup with 5 second timeout
    const records = await Promise.race([
      dns.resolveMx(domain),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("DNS timeout")), 5000)
      ),
    ]);

    mxRecords = records
      .sort((a, b) => a.priority - b.priority)
      .map((r) => r.exchange);

    isDeliverable = mxRecords.length > 0;
  } catch (error) {
    // DNS lookup failed
    isDeliverable = false;
  }

  // Provider detection
  const mxString = mxRecords.join(" ").toLowerCase();
  const domainLower = domain.toLowerCase();

  const isMicrosoft =
    mxString.includes("outlook.com") ||
    mxString.includes("microsoft.com") ||
    domainLower.includes("hotmail") ||
    domainLower.includes("live.com") ||
    domainLower.includes("outlook.com");

  const isGoogle =
    mxString.includes("google.com") ||
    mxString.includes("gmail.com") ||
    domainLower.includes("gmail.com");

  const isOffice365 = mxString.includes("protection.outlook.com");
  const isMimecast = mxString.includes("mimecast.com");
  const isArsmtp = mxString.includes("antispamcloud.com");
  const isGodaddy =
    mxString.includes("secureserver.net") || mxString.includes("godaddy.com");

  let provider: string | null = null;
  if (isMicrosoft) provider = "Microsoft";
  else if (isGoogle) provider = "Google";
  else if (isOffice365) provider = "Office365";
  else if (isMimecast) provider = "Mimecast";
  else if (isArsmtp) provider = "ARSMTP";
  else if (isGodaddy) provider = "GoDaddy";

  return {
    email,
    domain,
    isValid,
    isDeliverable,
    provider,
    isMicrosoft,
    isGoogle,
    isOffice365,
    isMimecast,
    isArsmtp,
    isGodaddy,
    mxRecords,
    validationTime: Date.now() - startTime,
  };
}

// Generate tracking token
function generateTrackingToken(): string {
  const randomBytes = crypto.randomBytes(128);
  const token = randomBytes.toString("base64url");
  return token;
}

// Get base URL with proxy support
function getBaseUrl(req: Request): string {
  const forwardedHost = req.headers["x-forwarded-host"] as string;

  if (forwardedHost) {
    const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol;
    return `${proto}://${forwardedHost}`;
  }

  return `${req.protocol}://${req.get("host")}`;
}

// Get client IP address
function getClientIp(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"] as string;
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  return req.ip || req.socket.remoteAddress || "Unknown";
}

// Configure multer for CSV uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Note: JSON and cookie middleware are already applied in server/index.ts

  // ==================== Authentication Routes ====================

  // Register new user (aliased as both /register and /signup for frontend compatibility)
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      const { username, password, licenseKey, email, firstName, lastName } = req.body;

      // Validate input
      if (!username || !password || !licenseKey) {
        return res.status(400).json({ detail: "Username, password, and license key are required" });
      }

      if (username.trim().length < 3) {
        return res.status(400).json({ detail: "Username must be at least 3 characters" });
      }

      if (password.length < 8) {
        return res.status(400).json({ detail: "Password must be at least 8 characters" });
      }

      // Normalize username and license key
      const normalizedUsername = username.trim().toLowerCase();
      const normalizedLicenseKey = licenseKey.trim();

      // Check if license key exists and is available
      const [license] = await db
        .select()
        .from(licenseKeys)
        .where(eq(licenseKeys.key, normalizedLicenseKey))
        .limit(1);

      if (!license) {
        return res.status(400).json({ detail: "Invalid license key" });
      }

      if (license.status !== "active") {
        return res.status(400).json({ detail: "License key has been revoked" });
      }

      if (license.assignedUserId) {
        return res.status(400).json({ detail: "License key is already in use" });
      }

      // Check if username exists
      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.username, normalizedUsername))
        .limit(1);

      if (existingUser) {
        return res.status(400).json({ detail: "Username already exists" });
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, 12);

      // Create user with license key
      const [newUser] = await db
        .insert(users)
        .values({
          username: normalizedUsername,
          passwordHash,
          licenseKey: normalizedLicenseKey,
          email: email || null,
          firstName: firstName || null,
          lastName: lastName || null,
          credits: BigInt(1000000000), // 1 billion credits
        })
        .returning();

      // Assign license key to the new user
      await db
        .update(licenseKeys)
        .set({
          assignedUserId: newUser.id,
          assignedAt: new Date(),
        })
        .where(eq(licenseKeys.key, normalizedLicenseKey));

      // Generate JWT token
      const token = jwt.sign({ userId: newUser.id }, JWT_SECRET, {
        expiresIn: JWT_EXPIRES_IN,
      });

      // Set cookie
      const isHttps = req.headers["x-forwarded-proto"] === "https" || req.protocol === "https";
      res.cookie("access_token", token, {
        httpOnly: true,
        secure: isHttps,
        sameSite: isHttps ? "none" : "lax",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        path: "/",
      });

      return res.json({
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        credits: Number(newUser.credits),
      });
    } catch (error: any) {
      console.error("Register error:", error);
      return res.status(500).json({ detail: "Registration failed" });
    }
  });

  // Login user
  app.post("/api/auth/login", authLimiter, async (req: Request, res: Response) => {
    try {
      const { username, password, licenseKey } = req.body;

      if (!username || !password || !licenseKey) {
        return res.status(400).json({ detail: "Username, password, and license key are required" });
      }

      // Normalize username and license key
      const normalizedUsername = username.trim().toLowerCase();
      const normalizedLicenseKey = licenseKey.trim();

      // Get user
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.username, normalizedUsername))
        .limit(1);

      if (!user || !user.passwordHash) {
        return res.status(401).json({ detail: "Invalid credentials" });
      }

      // Verify license key matches user's assigned key
      if (user.licenseKey !== normalizedLicenseKey) {
        return res.status(401).json({ detail: "Invalid license key" });
      }

      // Verify license key is still active in license_keys table
      const [license] = await db
        .select()
        .from(licenseKeys)
        .where(eq(licenseKeys.key, normalizedLicenseKey))
        .limit(1);

      if (!license) {
        return res.status(401).json({ detail: "License key not found" });
      }

      if (license.status !== "active") {
        return res.status(401).json({ detail: "License key has been revoked" });
      }

      if (license.assignedUserId !== user.id) {
        return res.status(401).json({ detail: "License key mismatch" });
      }

      // Verify password
      const isValid = await bcrypt.compare(password, user.passwordHash);

      if (!isValid) {
        return res.status(401).json({ detail: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, {
        expiresIn: JWT_EXPIRES_IN,
      });

      // Set cookie
      const isHttps = req.headers["x-forwarded-proto"] === "https" || req.protocol === "https";
      res.cookie("access_token", token, {
        httpOnly: true,
        secure: isHttps,
        sameSite: isHttps ? "none" : "lax",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        path: "/",
      });

      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        credits: Number(user.credits),
      });
    } catch (error: any) {
      console.error("Login error:", error);
      return res.status(500).json({ detail: "Login failed" });
    }
  });

  // Logout user
  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    res.clearCookie("access_token");
    return res.json({ message: "Logged out successfully" });
  });

  // Get current user
  app.get("/api/auth/me", authenticateToken, async (req: Request, res: Response) => {
    const user = req.user!;
    return res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      credits: Number(user.credits),
      isAdmin: user.is_admin,
    });
  });

  // ==================== Email Validation Routes ====================

  // Validate single email
  app.post(
    "/api/validate/single",
    validationLimiter,
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        // Validate request
        const { email } = singleEmailValidationSchema.parse(req.body);
        const user = req.user!;

        // Check credits
        if (BigInt(user.credits || 0) < BigInt(1)) {
          return res.status(403).json({ detail: "Insufficient credits" });
        }

        // Perform validation
        const result = await validateEmailWithDNS(email);

        // Save to database
        await db.insert(emailValidations).values({
          userId: user.id,
          email: result.email,
          domain: result.domain,
          isValid: result.isValid,
          isDeliverable: result.isDeliverable,
          provider: result.provider,
          isMicrosoft: result.isMicrosoft,
          isGoogle: result.isGoogle,
          isOffice365: result.isOffice365,
          isMimecast: result.isMimecast,
          isArsmtp: result.isArsmtp,
          isGodaddy: result.isGodaddy,
          mxRecords: result.mxRecords,
          validationTime: result.validationTime,
        });

        // Deduct credit
        await db
          .update(users)
          .set({ credits: sql`${users.credits} - 1` })
          .where(eq(users.id, user.id));

        return res.json(result);
      } catch (error: any) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ detail: error.errors[0].message });
        }
        console.error("Validation error:", error);
        return res.status(500).json({ detail: "Validation failed" });
      }
    }
  );

  // Validate bulk emails from CSV
  app.post(
    "/api/validate/bulk",
    validationLimiter,
    authenticateToken,
    upload.single("file"),
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;

        if (!req.file) {
          return res.status(400).json({ detail: "No file uploaded" });
        }

        // Parse CSV and validate each row with Zod
        const emails: string[] = [];
        const validationErrors: string[] = [];
        const stream = Readable.from(req.file.buffer);
        let rowNumber = 0;

        await new Promise<void>((resolve, reject) => {
          stream
            .pipe(csvParser())
            .on("data", (row) => {
              rowNumber++;
              try {
                // Find email column
                const emailValue =
                  row.email || row.Email || row.EMAIL || Object.values(row)[0];
                
                if (!emailValue || typeof emailValue !== "string") {
                  validationErrors.push(`Row ${rowNumber}: No email found`);
                  return;
                }

                const trimmed = emailValue.trim();
                
                // Validate with Zod schema
                const result = singleEmailValidationSchema.safeParse({ email: trimmed });
                
                if (result.success) {
                  emails.push(result.data.email);
                } else {
                  validationErrors.push(`Row ${rowNumber}: ${result.error.errors[0].message}`);
                }
              } catch (error: any) {
                validationErrors.push(`Row ${rowNumber}: ${error.message}`);
              }
            })
            .on("end", resolve)
            .on("error", reject);
        });

        // Return validation errors if too many invalid rows
        if (emails.length === 0) {
          return res.status(400).json({ 
            detail: "No valid emails found in CSV",
            errors: validationErrors.slice(0, 10) // Show first 10 errors
          });
        }

        if (emails.length > 10000) {
          return res
            .status(400)
            .json({ detail: "Maximum 10,000 emails per batch" });
        }

        // Check credits
        if (BigInt(user.credits || 0) < BigInt(emails.length)) {
          return res.status(403).json({ detail: "Insufficient credits" });
        }

        // Validate all emails
        const results: EmailValidationResult[] = [];

        for (const email of emails) {
          const result = await validateEmailWithDNS(email);
          results.push(result);

          // Save to database
          await db.insert(emailValidations).values({
            userId: user.id,
            email: result.email,
            domain: result.domain,
            isValid: result.isValid,
            isDeliverable: result.isDeliverable,
            provider: result.provider,
            isMicrosoft: result.isMicrosoft,
            isGoogle: result.isGoogle,
            isOffice365: result.isOffice365,
            isMimecast: result.isMimecast,
            isArsmtp: result.isArsmtp,
            isGodaddy: result.isGodaddy,
            mxRecords: result.mxRecords,
            validationTime: result.validationTime,
          });
        }

        // Deduct credits
        await db
          .update(users)
          .set({ credits: sql`${users.credits} - ${emails.length}` })
          .where(eq(users.id, user.id));

        // Sort by provider for easy filtering
        results.sort((a, b) => {
          if (a.provider && !b.provider) return -1;
          if (!a.provider && b.provider) return 1;
          if (a.provider && b.provider) {
            return a.provider.localeCompare(b.provider);
          }
          return 0;
        });

        return res.json({
          total: results.length,
          valid: results.filter((r) => r.isValid).length,
          deliverable: results.filter((r) => r.isDeliverable).length,
          results,
        });
      } catch (error: any) {
        console.error("Bulk validation error:", error);
        return res.status(500).json({ detail: "Bulk validation failed" });
      }
    }
  );

  // Get validation history
  app.get(
    "/api/validate/history",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;
        const limit = parseInt(req.query.limit as string) || 100;

        const history = await db
          .select()
          .from(emailValidations)
          .where(eq(emailValidations.userId, user.id))
          .orderBy(desc(emailValidations.createdAt))
          .limit(limit);

        return res.json(history);
      } catch (error: any) {
        console.error("History error:", error);
        return res.status(500).json({ detail: "Failed to fetch history" });
      }
    }
  );

  // Get validation results (alias for history)
  app.get(
    "/api/validate/results",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;
        const limit = parseInt(req.query.limit as string) || 100;

        const results = await db
          .select()
          .from(emailValidations)
          .where(eq(emailValidations.userId, user.id))
          .orderBy(desc(emailValidations.createdAt))
          .limit(limit);

        return res.json(results);
      } catch (error: any) {
        console.error("Results error:", error);
        return res.status(500).json({ detail: "Failed to fetch results" });
      }
    }
  );

  // Get validation statistics
  app.get(
    "/api/validate/stats",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;

        const allResults = await db
          .select()
          .from(emailValidations)
          .where(eq(emailValidations.userId, user.id));

        const stats = {
          total: allResults.length,
          deliverable: allResults.filter(r => r.isDeliverable).length,
          microsoft: allResults.filter(r => r.isMicrosoft).length,
          google: allResults.filter(r => r.isGoogle).length,
          office365: allResults.filter(r => r.isOffice365).length,
          mimecast: allResults.filter(r => r.isMimecast).length,
          arsmtp: allResults.filter(r => r.isArsmtp).length,
          godaddy: allResults.filter(r => r.isGodaddy).length,
        };

        return res.json(stats);
      } catch (error: any) {
        console.error("Stats error:", error);
        return res.status(500).json({ detail: "Failed to fetch stats" });
      }
    }
  );

  // Clear validation history
  app.delete(
    "/api/validate/clear",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;

        await db
          .delete(emailValidations)
          .where(eq(emailValidations.userId, user.id));

        return res.json({ message: "Validation history cleared" });
      } catch (error: any) {
        console.error("Clear error:", error);
        return res.status(500).json({ detail: "Failed to clear history" });
      }
    }
  );

  // ==================== Click Tracking Routes ====================

  // Create campaign
  app.post(
    "/api/tracking/campaigns",
    authLimiter,
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const data = createCampaignSchema.parse(req.body);
        const user = req.user!;

        const [campaign] = await db
          .insert(campaigns)
          .values({
            userId: user.id,
            name: data.name,
            description: data.description || null,
            targetUrl: data.targetUrl,
          })
          .returning();

        return res.json(campaign);
      } catch (error: any) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ detail: error.errors[0].message });
        }
        console.error("Create campaign error:", error);
        return res.status(500).json({ detail: "Failed to create campaign" });
      }
    }
  );

  // Generate tracking links from CSV
  app.post(
    "/api/tracking/campaigns/:id/links",
    authLimiter,
    authenticateToken,
    upload.single("file"),
    async (req: Request, res: Response) => {
      try {
        const campaignId = req.params.id;
        const user = req.user!;

        // Verify campaign ownership
        const [campaign] = await db
          .select()
          .from(campaigns)
          .where(eq(campaigns.id, campaignId))
          .limit(1);

        if (!campaign) {
          return res.status(404).json({ detail: "Campaign not found" });
        }

        if (campaign.userId !== user.id) {
          return res
            .status(403)
            .json({ detail: "Not authorized to access this campaign" });
        }

        if (!req.file) {
          return res.status(400).json({ detail: "No file uploaded" });
        }

        // Parse CSV and extract emails
        const emails: string[] = [];
        const validationErrors: string[] = [];
        const stream = Readable.from(req.file.buffer);
        let rowNumber = 0;

        await new Promise<void>((resolve, reject) => {
          stream
            .pipe(csvParser())
            .on("data", (row) => {
              rowNumber++;
              try {
                // Find email column
                const emailValue =
                  row.email || row.Email || row.EMAIL || Object.values(row)[0];
                
                if (!emailValue || typeof emailValue !== "string") {
                  validationErrors.push(`Row ${rowNumber}: No email found`);
                  return;
                }

                const trimmed = emailValue.trim();
                
                // Validate with Zod schema
                const result = singleEmailValidationSchema.safeParse({ email: trimmed });
                
                if (result.success) {
                  emails.push(result.data.email);
                } else {
                  validationErrors.push(`Row ${rowNumber}: ${result.error.errors[0].message}`);
                }
              } catch (error: any) {
                validationErrors.push(`Row ${rowNumber}: ${error.message}`);
              }
            })
            .on("end", resolve)
            .on("error", reject);
        });

        if (emails.length === 0) {
          return res.status(400).json({ 
            detail: "No valid emails found in CSV",
            errors: validationErrors.slice(0, 10)
          });
        }

        if (emails.length > 10000) {
          return res.status(400).json({ detail: "Maximum 10,000 recipients per batch" });
        }

        const baseUrl = getBaseUrl(req);

        // Generate tracking links
        const linksToInsert = emails.map((email) => ({
          campaignId: campaign.id,
          recipientEmail: email,
          token: generateTrackingToken(),
          clicks: 0,
        }));

        const links = await db
          .insert(trackingLinks)
          .values(linksToInsert)
          .returning();

        // Format response
        const response = links.map((link: typeof trackingLinks.$inferSelect) => ({
          id: link.id,
          campaignId: link.campaignId,
          recipientEmail: link.recipientEmail,
          trackingUrl: `${baseUrl}/t/${link.token}`,
          clicks: link.clicks,
          firstClickedAt: link.firstClickedAt,
          lastClickedAt: link.lastClickedAt,
          createdAt: link.createdAt,
        }));

        return res.json({ 
          count: response.length,
          links: response 
        });
      } catch (error: any) {
        console.error("Generate links error:", error);
        return res.status(500).json({ detail: "Failed to generate links" });
      }
    }
  );

  // Get all campaigns
  app.get(
    "/api/tracking/campaigns",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = req.user!;

        const userCampaigns = await db
          .select()
          .from(campaigns)
          .where(eq(campaigns.userId, user.id))
          .orderBy(desc(campaigns.createdAt));

        // Get stats for each campaign
        const campaignsWithStats = await Promise.all(
          userCampaigns.map(async (campaign: typeof campaigns.$inferSelect) => {
            const links = await db
              .select()
              .from(trackingLinks)
              .where(eq(trackingLinks.campaignId, campaign.id));

            const totalClicks = links.reduce((sum: number, link: typeof trackingLinks.$inferSelect) => sum + (link.clicks || 0), 0);
            const uniqueClicks = links.filter((link: typeof trackingLinks.$inferSelect) => (link.clicks || 0) > 0).length;

            return {
              ...campaign,
              totalLinks: links.length,
              totalClicks,
              uniqueClicks,
              clickRate: links.length > 0 ? (uniqueClicks / links.length) * 100 : 0,
            };
          })
        );

        return res.json(campaignsWithStats);
      } catch (error: any) {
        console.error("Get campaigns error:", error);
        return res.status(500).json({ detail: "Failed to fetch campaigns" });
      }
    }
  );

  // Get campaign statistics
  app.get(
    "/api/tracking/campaigns/:id/stats",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const campaignId = req.params.id;
        const user = req.user!;

        // Verify campaign ownership
        const [campaign] = await db
          .select()
          .from(campaigns)
          .where(eq(campaigns.id, campaignId))
          .limit(1);

        if (!campaign) {
          return res.status(404).json({ detail: "Campaign not found" });
        }

        if (campaign.userId !== user.id) {
          return res.status(403).json({ detail: "Not authorized" });
        }

        // Get links
        const links = await db
          .select()
          .from(trackingLinks)
          .where(eq(trackingLinks.campaignId, campaignId));

        // Get recent clicks
        const recentClicks = await db
          .select({
            clickedAt: clickEvents.clickedAt,
            recipientEmail: trackingLinks.recipientEmail,
            ipAddress: clickEvents.ipAddress,
            country: clickEvents.country,
            city: clickEvents.city,
          })
          .from(clickEvents)
          .innerJoin(trackingLinks, eq(clickEvents.trackingLinkId, trackingLinks.id))
          .where(eq(trackingLinks.campaignId, campaignId))
          .orderBy(desc(clickEvents.clickedAt))
          .limit(10);

        const totalClicks = links.reduce((sum: number, link: typeof trackingLinks.$inferSelect) => sum + (link.clicks || 0), 0);
        const uniqueClicks = links.filter((link: typeof trackingLinks.$inferSelect) => (link.clicks || 0) > 0).length;

        return res.json({
          campaignId: campaign.id,
          campaignName: campaign.name,
          totalLinks: links.length,
          totalClicks,
          uniqueClicks,
          clickRate: links.length > 0 ? (uniqueClicks / links.length) * 100 : 0,
          recentClicks,
        });
      } catch (error: any) {
        console.error("Get stats error:", error);
        return res.status(500).json({ detail: "Failed to fetch statistics" });
      }
    }
  );

  // Get campaign links
  app.get(
    "/api/tracking/campaigns/:id/links",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const campaignId = req.params.id;
        const user = req.user!;

        // Verify campaign ownership
        const [campaign] = await db
          .select()
          .from(campaigns)
          .where(eq(campaigns.id, campaignId))
          .limit(1);

        if (!campaign) {
          return res.status(404).json({ detail: "Campaign not found" });
        }

        if (campaign.userId !== user.id) {
          return res.status(403).json({ detail: "Not authorized" });
        }

        // Get links
        const links = await db
          .select()
          .from(trackingLinks)
          .where(eq(trackingLinks.campaignId, campaignId))
          .orderBy(desc(trackingLinks.createdAt));

        const baseUrl = getBaseUrl(req);

        const response = links.map((link: typeof trackingLinks.$inferSelect) => ({
          id: link.id,
          campaignId: link.campaignId,
          recipientEmail: link.recipientEmail,
          trackingUrl: `${baseUrl}/t/${link.token}`,
          clicks: link.clicks,
          firstClickedAt: link.firstClickedAt,
          lastClickedAt: link.lastClickedAt,
          createdAt: link.createdAt,
        }));

        return res.json(response);
      } catch (error: any) {
        console.error("Get links error:", error);
        return res.status(500).json({ detail: "Failed to fetch links" });
      }
    }
  );

  // ==================== Public Redirect Handler ====================

  app.get("/t/:token", async (req: Request, res: Response) => {
    try {
      const { token } = req.params;

      // Find tracking link
      const [link] = await db
        .select()
        .from(trackingLinks)
        .where(eq(trackingLinks.token, token))
        .limit(1);

      if (!link) {
        return res.status(404).send("Not found");
      }

      // Get campaign
      const [campaign] = await db
        .select()
        .from(campaigns)
        .where(eq(campaigns.id, link.campaignId))
        .limit(1);

      if (!campaign) {
        return res.status(404).send("Not found");
      }

      // Record click event
      const ipAddress = getClientIp(req);
      const userAgent = req.headers["user-agent"] || "Unknown";
      const referer = req.headers["referer"] || "";

      // Perform atomic click recording in a transaction
      await db.transaction(async (tx) => {
        // Insert click event
        await tx.insert(clickEvents).values({
          trackingLinkId: link.id,
          ipAddress,
          userAgent,
          referer,
          country: null, // Could add IP geolocation service
          city: null,
        });

        // Update tracking link stats atomically
        await tx
          .update(trackingLinks)
          .set({
            clicks: sql`${trackingLinks.clicks} + 1`,
            firstClickedAt: sql`COALESCE(${trackingLinks.firstClickedAt}, NOW())`,
            lastClickedAt: sql`NOW()`,
          })
          .where(eq(trackingLinks.id, link.id));
      });

      // Redirect to target URL
      return res.redirect(302, campaign.targetUrl);
    } catch (error: any) {
      console.error("Redirect error:", error);
      return res.status(500).send("An error occurred");
    }
  });

  // ==================== Admin License Key Management ====================

  // Admin middleware (checks if user has isAdmin flag set to true)
  const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ detail: "Not authenticated" });
    }
    if (!user.is_admin) {
      return res.status(403).json({ detail: "Admin access required" });
    }
    next();
  };

  // Generate new license keys (admin only)
  const generateLicenseKeysSchema = z.object({
    count: z.number().int().min(1).max(100).default(1),
    prefix: z.string().optional().default(""),
  });

  app.post(
    "/api/admin/license-keys",
    authenticateToken,
    requireAdmin,
    async (req: Request, res: Response) => {
      try {
        const validatedData = generateLicenseKeysSchema.parse(req.body);
        const { count, prefix } = validatedData;

        const newKeys = [];
        for (let i = 0; i < count; i++) {
          const key = prefix + crypto.randomBytes(16).toString("hex").toUpperCase();
          newKeys.push({ key });
        }

        const insertedKeys = await db.insert(licenseKeys).values(newKeys).returning();

        return res.json(insertedKeys);
      } catch (error: any) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ detail: "Invalid request data", errors: error.errors });
        }
        console.error("Generate license keys error:", error);
        return res.status(500).json({ detail: "Failed to generate license keys" });
      }
    }
  );

  // List all license keys (admin only)
  app.get(
    "/api/admin/license-keys",
    authenticateToken,
    requireAdmin,
    async (req: Request, res: Response) => {
      try {
        const keys = await db
          .select({
            id: licenseKeys.id,
            key: licenseKeys.key,
            status: licenseKeys.status,
            issuedAt: licenseKeys.issuedAt,
            assignedAt: licenseKeys.assignedAt,
            revokedAt: licenseKeys.revokedAt,
            assignedUserId: licenseKeys.assignedUserId,
            assignedUsername: users.username,
          })
          .from(licenseKeys)
          .leftJoin(users, eq(licenseKeys.assignedUserId, users.id))
          .orderBy(desc(licenseKeys.issuedAt));

        return res.json(keys);
      } catch (error: any) {
        console.error("List license keys error:", error);
        return res.status(500).json({ detail: "Failed to list license keys" });
      }
    }
  );

  // Revoke a license key (admin only)
  app.put(
    "/api/admin/license-keys/:id/revoke",
    authenticateToken,
    requireAdmin,
    async (req: Request, res: Response) => {
      try {
        const { id } = req.params;

        const [updatedKey] = await db
          .update(licenseKeys)
          .set({
            status: "revoked",
            revokedAt: new Date(),
          })
          .where(eq(licenseKeys.id, id))
          .returning();

        if (!updatedKey) {
          return res.status(404).json({ detail: "License key not found" });
        }

        return res.json(updatedKey);
      } catch (error: any) {
        console.error("Revoke license key error:", error);
        return res.status(500).json({ detail: "Failed to revoke license key" });
      }
    }
  );

  // ==================== Analytics Route ====================

  app.get("/api/analytics/health", async (req: Request, res: Response) => {
    return res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      database: "connected",
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
