# AWS SES Email Templates Integration Guide

## Overview
This guide explains how to configure the email sender to fetch and randomly use email templates from Amazon SES Console.

---

## ⚠️ Important: AWS Credentials Difference

### SMTP Credentials vs AWS API Credentials

**SMTP Credentials (for sending emails):**
- **Username**: SMTP username (e.g., AKIARXLUFZJIMRP63FF6)
- **Password**: SMTP password (encrypted string)
- **Purpose**: Used for SMTP email sending via email-smtp.amazonaws.com
- **Location in code**: `ses_username` and `ses_password`

**AWS API Credentials (for fetching SES templates):**
- **Access Key ID**: AWS IAM Access Key ID
- **Secret Access Key**: AWS IAM Secret Access Key  
- **Purpose**: Used by boto3 to call SES API operations (ListTemplates, GetTemplate)
- **Location in code**: `aws_access_key_id` and `aws_secret_access_key`

**⚠️ These are DIFFERENT credentials! SMTP password ≠ AWS Secret Access Key**

---

## 📋 Step 1: Create AWS IAM User with SES Permissions

### 1. Go to AWS IAM Console
```
https://console.aws.amazon.com/iam/
```

### 2. Create New IAM User
1. Click "Users" → "Create user"
2. Enter username: `ses-template-user`
3. Select "Access key - Programmatic access"
4. Click "Next"

### 3. Attach SES Permissions
Attach these policies:
- **AmazonSESReadOnlyAccess** (to list and get templates)
- **AmazonSESFullAccess** (if you want to create/update templates via API)

Or create custom policy:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ses:ListTemplates",
                "ses:GetTemplate"
            ],
            "Resource": "*"
        }
    ]
}
```

### 4. Get Access Keys
1. After user creation, click "Create access key"
2. Select "Application running outside AWS"
3. Download or copy:
   - **Access Key ID** (e.g., AKIAIOSFODNN7EXAMPLE)
   - **Secret Access Key** (e.g., wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY)

⚠️ **Save these credentials securely! You won't be able to see the secret key again.**

---

## 📧 Step 2: Create Email Templates in SES Console

### 1. Go to AWS SES Console
```
https://console.aws.amazon.com/ses/
Region: eu-central-1 (Frankfurt)
```

### 2. Navigate to Email Templates
1. Click "Configuration" → "Email templates"
2. Click "Create template"

### 3. Create Template Examples

**Template 1: Welcome Email**
```
Template Name: welcome-template
Subject: Welcome to {{company}}!
HTML Body:
<html>
<body>
    <h1>Welcome {{firstname}}!</h1>
    <p>Thank you for joining {{company}}.</p>
    <p>Your account ID is: {{id}}</p>
</body>
</html>

Text Body:
Welcome {{firstname}}!
Thank you for joining {{company}}.
Your account ID is: {{id}}
```

**Template 2: Notification**
```
Template Name: notification-template
Subject: Important Update - {{date}}
HTML Body:
<html>
<body>
    <h2>Dear {{firstname}} {{lastname}},</h2>
    <p>We have an important update for you.</p>
    <p>Reference Number: {{randomnumber}}</p>
    <p>Contact us at: {{phone}}</p>
</body>
</html>
```

**Template 3: Invoice**
```
Template Name: invoice-template
Subject: Invoice #{{id}} - {{date}}
HTML Body:
<html>
<body>
    <h1>Invoice</h1>
    <p>Customer: {{fullname}}</p>
    <p>Email: {{email}}</p>
    <p>Invoice #: {{id}}</p>
    <p>Date: {{date}}</p>
    <p>Amount: ${{randomnumber}}</p>
</body>
</html>
```

### 4. Save Templates
Click "Create template" to save each template in SES.

---

## ⚙️ Step 3: Configure main.py

### Update EMAIL_CONFIG in main.py:

```python
EMAIL_CONFIG = {
    # Enable SES template fetching
    'use_ses_templates': True,  # ✅ Set to True
    
    # AWS IAM Credentials (from Step 1)
    'aws_access_key_id': 'AKIAIOSFODNN7EXAMPLE',  # ✅ Your IAM Access Key ID
    'aws_secret_access_key': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',  # ✅ Your IAM Secret Key
    'aws_region': 'eu-central-1',  # ✅ Your SES region
    
    # SMTP credentials remain unchanged
    'ses_username': 'AKIARXLUFZJIMRP63FF6',  # SMTP username
    'ses_password': 'BJHRGnC2WfzOkksYMmlKUTzTE/x/jgJ0B1299DsSe57U',  # SMTP password
}
```

---

## 🚀 Step 4: How It Works

### When `use_ses_templates` is True:

1. **Startup**: System fetches all templates from SES console
   ```
   ✅ Found 3 SES templates:
      - welcome-template
      - notification-template
      - invoice-template
   ```

2. **Random Selection**: Each email randomly uses one SES template
   ```
   Email 1: Uses welcome-template
   Email 2: Uses invoice-template
   Email 3: Uses notification-template
   Email 4: Uses welcome-template (random cycle)
   ```

3. **Placeholder Replacement**: Auto-replaces placeholders
   - `{{firstname}}` → Random first name
   - `{{lastname}}` → Random last name
   - `{{email}}` → Random email
   - `{{id}}` → Random number
   - `{{date}}` → Random date
   - `{{phone}}` → Random phone
   - `{{randomnumber}}` → Random number
   - `{{company}}` → Your value

4. **Sending**: Uses SES template HTML and subject
   ```
   From: Customer Support <hunter@qupio.jp>
   Subject: Welcome to ACME Corp! (from SES template)
   Body: <HTML from SES template with placeholders replaced>
   ```

---

## 📊 Testing SES Templates

### Run test script:
```bash
python3 test_ses_templates.py
```

**Expected output with valid credentials:**
```
============================================================
   AMAZON SES EMAIL TEMPLATES
============================================================

🔌 Connecting to Amazon SES (eu-central-1)...
✅ Connected successfully!

📋 Fetching email templates from SES console...
✅ Found 3 template(s):

   1. Template: welcome-template
      Created: 2025-11-21 10:30:00+00:00
      Subject: Welcome to {{company}}!
      HTML Length: 234 characters
      Text Length: 89 characters
      HTML Preview: <html><body><h1>Welcome {{firstname}}!</h1>...

   2. Template: notification-template
      Created: 2025-11-21 10:35:00+00:00
      Subject: Important Update - {{date}}
      HTML Length: 312 characters
      
   3. Template: invoice-template
      Created: 2025-11-21 10:40:00+00:00
      Subject: Invoice #{{id}} - {{date}}
      HTML Length: 289 characters
============================================================
```

---

## ✅ Advantages of SES Templates

### Benefits:
1. **Centralized Management**: Edit templates in AWS console (no code changes)
2. **Version Control**: SES tracks template versions
3. **Dynamic Content**: Use {{placeholders}} for personalization
4. **Professional**: Pre-designed HTML templates
5. **Scalable**: Add/remove templates without code deployment
6. **Random Rotation**: System automatically rotates through all available templates
7. **Easy Updates**: Update template in SES console → instantly used by sender

### Use Cases:
- **Email Campaigns**: Different templates for different audiences
- **A/B Testing**: Test multiple template designs
- **Seasonal Updates**: Swap templates without code changes
- **Multi-Language**: Different templates for different languages
- **Brand Updates**: Update branding across all emails at once

---

## 🔄 Fallback Behavior

### If SES template fetching fails:
- System automatically falls back to local templates in `templates/` folder
- No interruption to sending
- Error logged but sending continues

### Current Setup:
```
use_ses_templates: False
→ Using local templates (templates/empty.html)
```

To enable SES templates:
1. Get AWS IAM credentials (Step 1)
2. Create templates in SES console (Step 2)
3. Update main.py with credentials (Step 3)
4. Set `use_ses_templates: True`

---

## 📝 Summary

**To enable SES template fetching:**
1. ✅ Create AWS IAM user with SES permissions
2. ✅ Get AWS Access Key ID and Secret Access Key
3. ✅ Create email templates in SES console
4. ✅ Update `aws_access_key_id` and `aws_secret_access_key` in main.py
5. ✅ Set `use_ses_templates: True`
6. ✅ Run python3 main.py

**Current status:**
- ❌ SES templates: Disabled (use_ses_templates: False)
- ✅ Local templates: Active (templates/empty.html)
- ✅ SMTP sending: Working (hunter@qupio.jp)

---

## 🎯 Next Steps

**Ready to enable SES templates?**
1. Get AWS IAM credentials from AWS Console
2. Create at least 1 template in SES console
3. Update main.py with credentials
4. Test with `python3 test_ses_templates.py`
5. Enable by setting `use_ses_templates: True`
6. Send test emails!

**Questions?**
- AWS IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/
- SES Templates: https://docs.aws.amazon.com/ses/latest/dg/send-personalized-email-api.html
- Boto3 SES: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ses.html
