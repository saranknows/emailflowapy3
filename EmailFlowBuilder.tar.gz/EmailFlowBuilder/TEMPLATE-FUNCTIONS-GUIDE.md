# Template Functions Guide for main.py

## Overview

`main.py` now includes **comprehensive template management functions** for working with email templates programmatically. These functions allow you to list, inspect, create, validate, and preview email templates.

## Available Template Functions

### 1. list_templates()

**Lists all available email templates**

```python
templates = list_templates()

# Returns:
# [
#     {
#         'name': 'template1-professional.html',
#         'size': 2048,
#         'size_kb': 2.0,
#         'preview': '<html><head>...',
#         'content_length': 2048
#     },
#     ...
# ]
```

**Use Case:** Get an overview of all available templates before sending

---

### 2. get_template_info(template_name)

**Get detailed information about a specific template**

```python
info = get_template_info('template1-professional.html')

# Returns:
# {
#     'name': 'template1-professional.html',
#     'size': 2048,
#     'size_kb': 2.0,
#     'content': '<html>...</html>',
#     'placeholders': ['content', 'name', 'company'],
#     'line_count': 45
# }
```

**Use Case:** Inspect a template to see what placeholders it uses

---

### 3. create_template(template_name, content)

**Create a new email template**

```python
html_content = """
<html>
<head><title>New Template</title></head>
<body>
    <h1>Hello {{name}}!</h1>
    <p>{{content}}</p>
</body>
</html>
"""

success = create_template('my-custom-template.html', html_content)
# Returns: True if successful, False otherwise
```

**Use Case:** Programmatically create new email templates

---

### 4. replace_template_placeholders(template_content, placeholders)

**Replace placeholders in template with actual values**

```python
template = load_template('template1-professional.html')

placeholders = {
    'name': 'John Doe',
    'content': 'Your exclusive offer awaits!',
    'company': 'ACME Corp',
    'email': 'john@example.com'
}

final_html = replace_template_placeholders(template, placeholders)
```

**Use Case:** Personalize emails with recipient-specific data

---

### 5. get_template_placeholders(template_content)

**Extract all placeholders from a template**

```python
template = load_template('template1-professional.html')
placeholders = get_template_placeholders(template)

# Returns: ['content', 'name', 'company', 'email']
```

**Use Case:** Find out which placeholders a template uses

---

### 6. validate_template(template_content)

**Validate HTML template structure**

```python
template = load_template('template1-professional.html')
is_valid, errors = validate_template(template)

if is_valid:
    print("✅ Template is valid")
else:
    print(f"❌ Errors: {errors}")
```

**Use Case:** Check template for common HTML issues before sending

---

### 7. preview_template(template_name, sample_data=None)

**Preview template with sample data**

```python
# With default sample data
preview = preview_template('template1-professional.html')

# With custom sample data
sample_data = {
    'name': 'Jane Smith',
    'content': 'Check out our special offer!',
    'company': 'TechCorp'
}
preview = preview_template('template1-professional.html', sample_data)
```

**Use Case:** See how the template will look with actual data

---

## Complete Example Usage

### Example 1: List and Inspect Templates

```python
# List all templates
templates = list_templates()

print(f"Found {len(templates)} templates:")
for template in templates:
    print(f"  - {template['name']} ({template['size_kb']} KB)")

# Get details about a specific template
info = get_template_info('template1-professional.html')
print(f"\nTemplate: {info['name']}")
print(f"Placeholders: {', '.join(info['placeholders'])}")
print(f"Lines: {info['line_count']}")
```

**Output:**
```
Found 11 templates:
  - default.html (1.5 KB)
  - template1-professional.html (2.0 KB)
  - template2-modern.html (2.2 KB)
  ...

Template: template1-professional.html
Placeholders: content, name, company
Lines: 45
```

---

### Example 2: Create a Custom Template

```python
# Define custom HTML template
custom_html = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{title}}</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Hello {{name}}!</h1>
        <p style="color: #666;">{{message}}</p>
        
        <div style="background: #f5f5f5; padding: 15px; margin: 20px 0;">
            <strong>Special Offer:</strong> {{offer}}
        </div>
        
        <p>Best regards,<br><strong>{{company}}</strong></p>
    </div>
</body>
</html>
"""

# Create the template
if create_template('special-offer-template', custom_html):
    print("✅ Custom template created successfully!")
    
    # Verify it was created
    info = get_template_info('special-offer-template.html')
    print(f"Placeholders: {info['placeholders']}")
```

---

### Example 3: Validate and Preview Before Sending

```python
# Load template
template_name = 'my-template.html'
template = load_template(template_name)

# Validate structure
is_valid, errors = validate_template(template)

if not is_valid:
    print(f"❌ Template has errors:")
    for error in errors:
        print(f"   - {error}")
else:
    print("✅ Template is valid")
    
    # Get placeholders
    placeholders = get_template_placeholders(template)
    print(f"📝 Required placeholders: {placeholders}")
    
    # Preview with sample data
    sample_data = {
        'name': 'Test User',
        'content': 'This is a test email',
        'company': 'Test Company'
    }
    
    preview = preview_template(template_name, sample_data)
    print("\n📧 Template Preview:")
    print(preview[:200] + "...")
```

---

### Example 4: Personalized Mass Email with Placeholders

```python
# Load contacts with additional data
contacts_data = [
    {'email': 'john@example.com', 'name': 'John Doe', 'city': 'New York'},
    {'email': 'jane@example.com', 'name': 'Jane Smith', 'city': 'Los Angeles'},
    {'email': 'bob@example.com', 'name': 'Bob Johnson', 'city': 'Chicago'},
]

# Load template
template = load_template('personalized-template.html')

# Send personalized emails
for contact in contacts_data:
    # Create personalized content
    placeholders = {
        'name': contact['name'],
        'content': f"We have special offers in {contact['city']}!",
        'city': contact['city'],
        'company': 'ACME Corp'
    }
    
    # Replace placeholders
    personalized_html = replace_template_placeholders(template, placeholders)
    
    # Send email
    # send_email(smtp_server, from_email, contact['email'], subject, personalized_html)
    print(f"✅ Sent personalized email to {contact['name']} in {contact['city']}")
```

---

### Example 5: Batch Create Templates

```python
# Define multiple template styles
templates_to_create = {
    'welcome-email': """
        <html><body>
            <h1>Welcome {{name}}!</h1>
            <p>{{message}}</p>
        </body></html>
    """,
    'thank-you-email': """
        <html><body>
            <h1>Thank You {{name}}!</h1>
            <p>{{message}}</p>
        </body></html>
    """,
    'reminder-email': """
        <html><body>
            <h1>Reminder for {{name}}</h1>
            <p>{{message}}</p>
        </body></html>
    """
}

# Create all templates
for name, content in templates_to_create.items():
    if create_template(name, content):
        print(f"✅ Created: {name}.html")

# Verify creation
all_templates = list_templates()
print(f"\nTotal templates: {len(all_templates)}")
```

---

## Common Placeholder Patterns

### Basic Placeholders
```
{{name}}         - Recipient name
{{email}}        - Recipient email
{{content}}      - Main message content
{{company}}      - Company name
{{title}}        - Email title
{{message}}      - Custom message
```

### Advanced Placeholders
```
{{first_name}}   - First name only
{{last_name}}    - Last name only
{{city}}         - City name
{{country}}      - Country
{{phone}}        - Phone number
{{date}}         - Date
{{offer}}        - Special offer text
{{discount}}     - Discount amount
{{link}}         - Custom link
{{code}}         - Promo code
```

---

## Template Best Practices

### ✅ DO:

1. **Always use placeholders** for dynamic content
   ```html
   <h1>Hello {{name}}!</h1>
   ```

2. **Validate templates** before mass sending
   ```python
   is_valid, errors = validate_template(template)
   ```

3. **Preview templates** with sample data
   ```python
   preview = preview_template('my-template.html', sample_data)
   ```

4. **Check placeholders** match your data
   ```python
   placeholders = get_template_placeholders(template)
   ```

5. **Use responsive design** for mobile compatibility
   ```html
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   ```

### ❌ DON'T:

1. **Don't hardcode recipient names** in templates
   ```html
   <!-- Bad -->
   <h1>Hello John!</h1>
   
   <!-- Good -->
   <h1>Hello {{name}}!</h1>
   ```

2. **Don't forget to handle missing placeholders**
   ```python
   # Always provide default values
   placeholders = {
       'name': contact.get('name', 'Valued Customer'),
       'content': contact.get('content', 'Default message')
   }
   ```

3. **Don't use complex JavaScript** (many email clients block it)

4. **Don't forget DOCTYPE** for better compatibility
   ```html
   <!DOCTYPE html>
   ```

---

## Integration with main.py Sending Logic

The template functions integrate seamlessly with the main sending logic:

```python
# In main.py main() function
template_name, template_content = next(template_cycle)

# Add personalized placeholders
placeholders = {
    'content': 'Your special offer',
    'name': contact_name,  # if you have contact names
    'company': 'Your Company Name'
}

# Replace placeholders
html_content = replace_template_placeholders(template_content, placeholders)

# Embed QR code if enabled
if EMAIL_CONFIG.get('enable_qr_code', False):
    qr_data = EMAIL_CONFIG.get('qr_code_data', '')
    if qr_data:
        qr_base64 = generate_qr_code(qr_data)
        if qr_base64:
            html_content = embed_qr_code_in_html(html_content, qr_base64)

# Send the email
send_email(smtp_server, from_email, contact, subject, html_content)
```

---

## Troubleshooting

### Template Not Found
```python
info = get_template_info('missing-template.html')
if info is None:
    print("❌ Template not found!")
```

### Invalid Placeholders
```python
placeholders_needed = get_template_placeholders(template)
placeholders_provided = {'name': 'John', 'email': 'john@example.com'}

missing = set(placeholders_needed) - set(placeholders_provided.keys())
if missing:
    print(f"⚠️  Missing placeholders: {missing}")
```

### Validation Errors
```python
is_valid, errors = validate_template(template)
if not is_valid:
    for error in errors:
        if 'Warning' in error:
            print(f"⚠️  {error}")
        else:
            print(f"❌ {error}")
```

---

## Advanced: Dynamic Template Selection

```python
# Select template based on recipient type
def select_template_for_recipient(recipient_type):
    templates_map = {
        'new_customer': 'welcome-email.html',
        'existing': 'thank-you-email.html',
        'inactive': 'reminder-email.html'
    }
    return templates_map.get(recipient_type, 'default.html')

# Use in sending loop
for contact in contacts:
    recipient_type = contact.get('type', 'existing')
    template_name = select_template_for_recipient(recipient_type)
    
    template = load_template(template_name)
    # ... continue with placeholder replacement and sending
```

---

## Performance Tips

1. **Load templates once** at the start
   ```python
   # Good - load once
   templates = {name: load_template(name) for name in template_files}
   
   # Bad - load repeatedly in loop
   for contact in contacts:
       template = load_template('template.html')  # Don't do this
   ```

2. **Reuse compiled placeholders**
   ```python
   # Extract placeholders once
   required_placeholders = get_template_placeholders(template)
   
   # Use in loop
   for contact in contacts:
       data = {key: contact.get(key, '') for key in required_placeholders}
       html = replace_template_placeholders(template, data)
   ```

3. **Validate once before sending**
   ```python
   # Validate template before loop, not inside it
   is_valid, errors = validate_template(template)
   if not is_valid:
       print(f"Fix template errors: {errors}")
       exit(1)
   
   # Now send to all contacts
   for contact in contacts:
       # ... send emails
   ```

---

## Summary

The template functions in `main.py` provide:

✅ **7 powerful functions** for template management  
✅ **Complete template lifecycle** (list, create, validate, preview)  
✅ **Placeholder management** (extract, replace, validate)  
✅ **Error handling** and validation  
✅ **Integration** with existing sending logic  

Use these functions to create sophisticated, personalized email campaigns with ease!

---

**Related Documentation:**
- [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md) - Complete main.py guide
- [QR-CODE-FEATURE-GUIDE.md](QR-CODE-FEATURE-GUIDE.md) - QR code functionality
- [README.md](README.md) - Project overview
