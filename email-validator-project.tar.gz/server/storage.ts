// Storage layer for database operations
// References: javascript_database and javascript_log_in_with_replit blueprints

import {
  users,
  emailValidations,
  type User,
  type UpsertUser,
  type EmailValidation,
  type InsertEmailValidation,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserCredits(userId: string): Promise<bigint>;
  
  // Email validation operations
  createEmailValidation(validation: InsertEmailValidation): Promise<EmailValidation>;
  getUserValidations(userId: string, limit?: number): Promise<EmailValidation[]>;
  getValidationsByProvider(userId: string, provider: string): Promise<EmailValidation[]>;
  clearUserValidations(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserCredits(userId: string): Promise<bigint> {
    const user = await this.getUser(userId);
    return user?.credits ?? BigInt(0);
  }

  // Email validation operations
  async createEmailValidation(validation: InsertEmailValidation): Promise<EmailValidation> {
    const [created] = await db
      .insert(emailValidations)
      .values(validation)
      .returning();
    return created;
  }

  async getUserValidations(userId: string, limit: number = 100): Promise<EmailValidation[]> {
    return await db
      .select()
      .from(emailValidations)
      .where(eq(emailValidations.userId, userId))
      .orderBy(desc(emailValidations.createdAt))
      .limit(limit);
  }

  async getValidationsByProvider(userId: string, provider: string): Promise<EmailValidation[]> {
    // Map provider names to boolean fields
    const providerFieldMap: Record<string, any> = {
      'microsoft': emailValidations.isMicrosoft,
      'google': emailValidations.isGoogle,
      'office365': emailValidations.isOffice365,
      'mimecast': emailValidations.isMimecast,
      'arsmtp': emailValidations.isArsmtp,
      'godaddy': emailValidations.isGodaddy,
    };

    const providerField = providerFieldMap[provider.toLowerCase()];
    if (!providerField) {
      return [];
    }

    return await db
      .select()
      .from(emailValidations)
      .where(
        and(
          eq(emailValidations.userId, userId),
          eq(providerField, true),
          eq(emailValidations.isDeliverable, true)
        )
      )
      .orderBy(desc(emailValidations.createdAt));
  }

  async clearUserValidations(userId: string): Promise<void> {
    await db
      .delete(emailValidations)
      .where(eq(emailValidations.userId, userId));
  }
}

export const storage = new DatabaseStorage();
