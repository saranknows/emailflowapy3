# {{COMPANYLOGO}} Placeholder Guide

## Overview
The `{{COMPANYLOGO}}` placeholder automatically fetches and displays the company logo based on the **recipient's email domain**. This feature works seamlessly with HTML-to-image conversion and all email providers.

---

## How It Works

### Automatic Domain Extraction
When you use `{{COMPANYLOGO}}` in your template:

1. **System extracts the domain** from the recipient's email address
2. **Fetches the company logo** using Clearbit Logo API
3. **Replaces the placeholder** with the logo image URL
4. **Works in both HTML and image formats**

### Example Flow

```
Recipient email: john@microsoft.com
        ↓
Domain extracted: microsoft.com
        ↓
Logo URL: https://logo.clearbit.com/microsoft.com
        ↓
Placeholder replaced in template
        ↓
Email sent with Microsoft logo
```

---

## Usage in Templates

### Basic Usage

Simply add the placeholder in your HTML template where you want the logo to appear:

```html
<img src="{{COMPANYLOGO}}" alt="Company Logo" style="height: 50px; width: auto;" />
```

### Professional Layout (DocuSign Style)

```html
<table border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td style="padding-right: 15px; vertical-align: middle;">
      <img src="{{COMPANYLOGO}}" alt="Company Logo" 
           style="height: 50px; width: auto; display: block; 
                  border: 1px solid #e0e0e0; border-radius: 4px; 
                  padding: 5px; background-color: #ffffff;">
    </td>
    <td style="vertical-align: middle;">
      <span style="font-weight: bold;">{{firstname}} {{lastname}}</span><br>
      <span style="color: #666;">via eSignature</span>
    </td>
  </tr>
</table>
```

---

## Real-World Examples

### Example 1: john@google.com
```
Logo fetched: https://logo.clearbit.com/google.com
Result: Google logo displays
```

### Example 2: sarah@apple.com
```
Logo fetched: https://logo.clearbit.com/apple.com
Result: Apple logo displays
```

### Example 3: mike@stripe.com
```
Logo fetched: https://logo.clearbit.com/stripe.com
Result: Stripe logo displays
```

---

## Integration with HTML-to-Image

### Before Conversion (HTML)
```html
<img src="{{COMPANYLOGO}}" alt="Logo" />
     ↓ (System processes)
<img src="https://logo.clearbit.com/microsoft.com" alt="Logo" />
```

### After Conversion (PNG Image)
- Logo is embedded in the PNG image
- Entire image (including logo) is clickable
- Works in all email clients

---

## Features & Benefits

✅ **Automatic Fetching** - No manual logo upload required  
✅ **Recipient-Specific** - Each email gets the logo from recipient's domain  
✅ **Professional Appearance** - Real company logos increase trust  
✅ **Email-Safe** - Works with all email clients  
✅ **Image-Ready** - Fully compatible with HTML-to-image conversion  
✅ **Clickable** - When converted to image, logo becomes part of clickable area  

---

## Supported Domains

The Clearbit Logo API supports **millions of company domains**, including:

- **Tech Companies**: google.com, microsoft.com, apple.com, amazon.com
- **Social Media**: facebook.com, twitter.com, instagram.com, linkedin.com
- **Financial**: stripe.com, paypal.com, square.com, coinbase.com
- **E-commerce**: shopify.com, woocommerce.com, magento.com
- **SaaS**: salesforce.com, hubspot.com, zendesk.com, slack.com
- **And millions more...**

---

## Error Handling

### If Domain Cannot Be Extracted
- Placeholder is replaced with empty string
- Email still sends successfully
- No error shown to recipient

### If Logo Not Available
- Clearbit returns a generic fallback
- Email displays normally
- No broken image icons

---

## Styling Recommendations

### Recommended Styles
```html
<img src="{{COMPANYLOGO}}" alt="Company Logo" 
     style="height: 50px;           /* Fixed height */
            width: auto;             /* Maintain aspect ratio */
            display: block;          /* Remove inline spacing */
            border: 1px solid #ddd;  /* Optional border */
            border-radius: 4px;      /* Rounded corners */
            padding: 5px;            /* Internal spacing */
            background: #fff;">      /* White background */
```

### Size Guidelines
- **Height**: 40-60px (recommended: 50px)
- **Width**: Auto (maintains aspect ratio)
- **Max width**: 150px (to prevent oversized logos)

---

## Use Cases

### 1. DocuSign-Style Notifications
```html
You have received a document from:

[Company Logo]  John Smith
                via eSignature
```

### 2. Business Communications
```html
[Company Logo]  Sarah Johnson
                Chief Marketing Officer
                Google Inc.
```

### 3. Invoices & Receipts
```html
[Company Logo]  Invoice from John Smith
                Due Date: 12/31/2025
```

### 4. Meeting Invitations
```html
[Company Logo]  Mike Williams invites you to:
                Product Demo - Friday 3PM
```

---

## Template Example: DocuSign Notification

```html
<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif;">
<table width="600" cellpadding="0" cellspacing="0" border="0" style="margin: 0 auto;">
  <tr>
    <td style="padding: 40px 30px;">
      <h1>Document Awaiting Your Signature</h1>
      <p>You have received a document from:</p>
      
      <!-- Company Logo with Sender Info -->
      <table border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding-right: 15px; vertical-align: middle;">
            <img src="{{COMPANYLOGO}}" alt="Company Logo" 
                 style="height: 50px; width: auto; display: block;">
          </td>
          <td style="vertical-align: middle;">
            <strong>{{firstname}} {{lastname}}</strong><br>
            <span style="color: #666;">via eSignature</span>
          </td>
        </tr>
      </table>
      
      <p><strong>Document:</strong> Contract Agreement 2025</p>
      <p><strong>Expires:</strong> {{date}}</p>
      
      <a href="https://docusign.com/sign-document" 
         style="display: inline-block; padding: 15px 40px; 
                background: #FFB81C; color: #000; 
                text-decoration: none; font-weight: bold;">
        REVIEW DOCUMENT
      </a>
    </td>
  </tr>
</table>
</body>
</html>
```

---

## Technical Details

### Implementation
- **Backend Function**: `process_company_logo_placeholder()` in `backend/app.py`
- **Domain Extraction**: `extract_domain_from_email()` helper function
- **Processing Order**: Placeholder → QR Code → HTML-to-Image
- **API Used**: Clearbit Logo API (https://logo.clearbit.com/)

### Processing Flow
```
1. Load template with {{COMPANYLOGO}}
2. Extract domain from recipient email
3. Replace placeholder with logo URL
4. Process QR code (if enabled)
5. Convert to image (if enabled)
6. Send email
```

### Logo URL Format
```
https://logo.clearbit.com/{domain}

Examples:
https://logo.clearbit.com/google.com
https://logo.clearbit.com/microsoft.com
https://logo.clearbit.com/apple.com
```

---

## Frequently Asked Questions

### Q: Is the logo fetched from sender or recipient?
**A:** Recipient! The logo is fetched from the **recipient's email domain**, not the sender's.

### Q: Does it work with HTML-to-image conversion?
**A:** Yes! The placeholder is processed BEFORE HTML-to-image conversion, so the logo appears in the final PNG image.

### Q: What if the recipient uses a personal email (gmail.com, yahoo.com)?
**A:** It will fetch Gmail's or Yahoo's logo. For personal emails, the logo may not be relevant.

### Q: Can I use both {{COMPANYLOGO}} and manual logo?
**A:** Yes, but the placeholder will be replaced. If you want a static logo, use a direct URL instead.

### Q: Is it case-sensitive?
**A:** No! You can use `{{COMPANYLOGO}}`, `{{companylogo}}`, or any case variation.

### Q: Does it cost anything?
**A:** The Clearbit Logo API is free (with attribution). No API key required.

### Q: What happens if Clearbit is down?
**A:** The placeholder is replaced with the URL, so the email client will attempt to fetch it. If Clearbit is down, the logo won't display, but the email still sends.

---

## Best Practices

### ✅ DO
- Use for B2B communications where recipient has a company email
- Style with fixed height and auto width
- Add border and padding for professional look
- Test with different email domains
- Use alongside {{firstname}} and {{lastname}}

### ❌ DON'T
- Don't use for B2C emails (personal email addresses)
- Don't make logo too large (max 60px height)
- Don't forget alt text for accessibility
- Don't rely solely on logo (include sender name too)

---

## Migration Note

**Clearbit Logo API is shutting down December 1, 2025.**

After this date, consider migrating to:
- **Logo.dev** (https://logo.dev/) - Similar service with API key
- **Brandfetch API** - Comprehensive brand asset API
- **Custom logo hosting** - Upload and host logos yourself

Current implementation will continue working until the shutdown date.

---

**Last Updated:** November 22, 2025  
**Feature:** Company Logo Placeholder with Automatic Domain Extraction  
**Status:** Active ✅
