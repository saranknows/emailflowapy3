# Antibot Security Functions Guide

## Overview
The antibot security system is designed to maximize inbox delivery rates by simulating human-like email sending behavior and adding authentication headers that email providers trust. These features help avoid spam filters and ensure your emails reach the inbox instead of the spam folder.

---

## 🛡️ **What is Antibot Security?**

Antibot security refers to techniques that make automated email sending appear more natural and trustworthy to email service providers (Gmail, Outlook, Yahoo, etc.). By randomizing patterns and adding proper authentication headers, your emails are less likely to be flagged as spam or blocked by automated filters.

---

## 📊 **Antibot Features (7 Total)**

### **1. Randomize Delays**
**What it does:** Varies the delay between emails instead of using a fixed interval  
**Why it matters:** Fixed delays create detectable patterns; random delays appear human  
**Configuration:** `randomize_delays: True`  
**Range:** 2-8 seconds (configurable)

### **2. Randomize Headers**
**What it does:** Adds varied email headers for each message  
**Why it matters:** Authentic headers improve email credibility  
**Configuration:** `randomize_headers: True`  
**Headers:** Date, MIME-Version, X-MSMail-Priority

### **3. Custom Message-ID**
**What it does:** Generates unique Message-ID for each email  
**Why it matters:** Required for proper email threading and authentication  
**Configuration:** `custom_message_id: True`  
**Format:** `<timestamp.randomhash@yourdomain.com>`

### **4. Vary User Agent**
**What it does:** Rotates X-Mailer header across 15 email clients  
**Why it matters:** Prevents all emails from appearing to come from same client  
**Configuration:** `vary_user_agent: True`  
**Clients:** Outlook, Thunderbird, Apple Mail, Gmail Client, etc.

### **5. Add Reply-To**
**What it does:** Includes Reply-To header matching From address  
**Why it matters:** Improves deliverability and sender reputation  
**Configuration:** `add_reply_to: True`  
**Effect:** Better inbox placement rates

### **6. Humanize Sending**
**What it does:** Adds natural pauses every 5-15 emails  
**Why it matters:** Humans don't send emails at constant speed  
**Configuration:** `humanize_sending: True`  
**Pauses:** 15-30 seconds every 10-15 emails

### **7. Rotate Priority**
**What it does:** Varies email priority headers (normal/high/low)  
**Why it matters:** Not all emails have same priority; natural variation  
**Configuration:** `rotate_priority: True`  
**Distribution:** 80% normal, 15% high, 5% low

---

## ⚙️ **Configuration**

### **EMAIL_CONFIG Settings**

Located in `main.py` around line 81:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    # Antibot Security Configuration (Inbox Delivery Optimization)
    'enable_antibot': True,           # Master switch for all antibot features
    'randomize_delays': True,         # Randomize delays between emails
    'delay_min': 2,                   # Minimum delay in seconds
    'delay_max': 8,                   # Maximum delay in seconds
    'randomize_headers': True,        # Add randomized email headers
    'custom_message_id': True,        # Generate custom Message-ID headers
    'vary_user_agent': True,          # Rotate X-Mailer headers
    'add_reply_to': True,             # Add Reply-To header
    'humanize_sending': True,         # Add human-like sending patterns
    'rotate_priority': True,          # Rotate email priority headers
    
    # ... other settings ...
}
```

### **Configuration Options**

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `enable_antibot` | Boolean | `True` | Master switch - enables/disables all features |
| `randomize_delays` | Boolean | `True` | Randomize delays between emails |
| `delay_min` | Integer | `2` | Minimum delay in seconds |
| `delay_max` | Integer | `8` | Maximum delay in seconds |
| `randomize_headers` | Boolean | `True` | Add randomized email headers |
| `custom_message_id` | Boolean | `True` | Generate custom Message-ID |
| `vary_user_agent` | Boolean | `True` | Rotate X-Mailer headers |
| `add_reply_to` | Boolean | `True` | Add Reply-To header |
| `humanize_sending` | Boolean | `True` | Add human-like pauses |
| `rotate_priority` | Boolean | `True` | Rotate priority headers |

---

## 🔧 **Functions**

### **1. Enable Antibot Security**

```python
enable_antibot()
```

**Purpose:** Turn on all 7 antibot features  
**Returns:** `True`  
**Example:**
```python
>>> enable_antibot()
✅ Antibot security features enabled
```

### **2. Disable Antibot Security**

```python
disable_antibot()
```

**Purpose:** Turn off all antibot features  
**Returns:** `True`  
**Example:**
```python
>>> disable_antibot()
✅ Antibot security features disabled
```

### **3. Get Antibot Status**

```python
get_antibot_status()
```

**Purpose:** Check current antibot configuration  
**Returns:** Dictionary with status information  
**Example:**
```python
>>> status = get_antibot_status()
>>> print(status['mode'])
Antibot: ON | Features: 7/7
>>> print(status['delay_range'])
2-8s
```

**Full Status Output:**
```python
{
    'antibot_enabled': True,
    'randomize_delays': True,
    'delay_range': '2-8s',
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': True,
    'add_reply_to': True,
    'humanize_sending': True,
    'rotate_priority': True,
    'features_enabled': '7/7',
    'mode': 'Antibot: ON | Features: 7/7'
}
```

### **4. Get Random Delay**

```python
get_random_delay()
```

**Purpose:** Generate randomized delay between emails  
**Returns:** Float delay in seconds (with micro-variations)  
**Example:**
```python
>>> delay = get_random_delay()
>>> print(delay)
4.73  # Random value between 2-8 seconds
```

### **5. Generate Message-ID**

```python
generate_message_id(from_email)
```

**Purpose:** Create custom Message-ID header  
**Args:** Sender email address  
**Returns:** Message-ID string  
**Example:**
```python
>>> msg_id = generate_message_id('sender@example.com')
>>> print(msg_id)
<20241117142315.a3f7c9e2b1d4@example.com>
```

### **6. Get Random User Agent**

```python
get_random_user_agent()
```

**Purpose:** Select random email client identifier  
**Returns:** String user agent name  
**Example:**
```python
>>> agent = get_random_user_agent()
>>> print(agent)
Microsoft Outlook 16.0
```

**Available User Agents (15):**
- Microsoft Outlook 16.0
- Mozilla Thunderbird 102.0
- Apple Mail (macOS)
- Gmail SMTP Client
- Mailspring 1.10.3
- eM Client 9.0
- Windows Mail 10.0
- Spark Email Client
- Postbox 7.0
- Mailbird 2.9
- BlueMail Client
- Outlook 365
- Yahoo Mail Client
- ProtonMail Bridge
- Zimbra Desktop

### **7. Get Random Priority**

```python
get_random_priority()
```

**Purpose:** Generate weighted random priority  
**Returns:** 'normal', 'high', or 'low'  
**Example:**
```python
>>> priority = get_random_priority()
>>> print(priority)
normal
```

**Distribution:**
- Normal: 80% (16/20 chance)
- High: 15% (3/20 chance)
- Low: 5% (1/20 chance)

### **8. Get Random Headers**

```python
get_random_headers(from_email)
```

**Purpose:** Generate complete set of randomized headers  
**Args:** Sender email address  
**Returns:** Dictionary of headers  
**Example:**
```python
>>> headers = get_random_headers('sender@example.com')
>>> print(headers)
{
    'Message-ID': '<20241117142315.a3f7c9e2b1d4@example.com>',
    'Date': 'Sun, 17 Nov 2024 14:23:15 -0500',
    'X-Mailer': 'Microsoft Outlook 16.0',
    'X-Priority': '3',
    'Importance': 'normal',
    'MIME-Version': '1.0',
    'X-MSMail-Priority': 'Normal'
}
```

### **9. Add Humanization Delay**

```python
add_humanization_delay(email_count, total_emails)
```

**Purpose:** Add human-like pauses in sending pattern  
**Args:** Current email number, total emails  
**Returns:** Additional delay in seconds  
**Example:**
```python
>>> delay = add_humanization_delay(10, 100)
>>> print(delay)
22.5  # Long pause every 10-15 emails
```

**Behavior:**
- Every 10-15 emails: 15-30 second pause
- Every 5 emails: 3-6 second pause
- Otherwise: 0 seconds

---

## 💡 **Usage Examples**

### **Example 1: Enable All Antibot Features (Recommended)**

```python
# In main.py EMAIL_CONFIG
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 2,
    'delay_max': 8,
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': True,
    'add_reply_to': True,
    'humanize_sending': True,
    'rotate_priority': True,
}

# Or using function
enable_antibot()
```

**Result:** Maximum inbox delivery optimization with all 7 features active.

---

### **Example 2: Fast Sending (Minimal Delays)**

```python
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 1,        # Shorter minimum
    'delay_max': 3,        # Shorter maximum
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': True,
    'add_reply_to': True,
    'humanize_sending': False,  # Disable pauses
    'rotate_priority': True,
}
```

**Result:** Faster sending while maintaining header randomization.

---

### **Example 3: Maximum Deliverability (Slower, More Natural)**

```python
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 5,        # Longer minimum
    'delay_max': 15,       # Longer maximum
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': True,
    'add_reply_to': True,
    'humanize_sending': True,
    'rotate_priority': True,
}
```

**Result:** Slowest but most human-like sending pattern.

---

### **Example 4: Disable Antibot (Fixed Delays)**

```python
EMAIL_CONFIG = {
    'enable_antibot': False,
}

# Or using function
disable_antibot()
```

**Result:** Classic fixed-delay sending without randomization.

---

### **Example 5: Custom Configuration**

```python
# Enable only specific features
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 3,
    'delay_max': 6,
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': False,      # Disabled
    'add_reply_to': True,
    'humanize_sending': False,     # Disabled
    'rotate_priority': False,      # Disabled
}
```

**Result:** Partial antibot features (4/7 enabled).

---

## 🎯 **How It Works**

### **During Email Sending:**

```python
# For each email:

# 1. Generate custom headers
headers = get_random_headers(from_email)
# Creates: Message-ID, Date, X-Mailer, Priority headers

# 2. Add to email message
msg['Message-ID'] = headers['Message-ID']
msg['X-Mailer'] = headers['X-Mailer']
msg['Reply-To'] = from_email
# ... and other headers

# 3. Send email
send_email(...)

# 4. Calculate randomized delay
base_delay = get_random_delay()        # 2-8 seconds (random)
humanization = add_humanization_delay(i, total)  # 0, 3-6, or 15-30 seconds
total_delay = base_delay + humanization

# 5. Wait before next email
time.sleep(total_delay)
```

### **Randomization Example:**

**Email #1:**
```
Delay: 3.2s
Headers: X-Mailer: Microsoft Outlook 16.0, Priority: normal
Message-ID: <20241117142315.a3f7c9@example.com>
```

**Email #2:**
```
Delay: 6.8s
Headers: X-Mailer: Thunderbird 102.0, Priority: normal
Message-ID: <20241117142322.b4d8e1@example.com>
```

**Email #5:** (micro-pause)
```
Delay: 4.1s + 4.5s = 8.6s
Headers: X-Mailer: Apple Mail, Priority: normal
Message-ID: <20241117142331.f7c2a9@example.com>
```

**Email #10:** (humanization pause)
```
Delay: 5.3s + 22.7s = 28.0s
Headers: X-Mailer: Gmail SMTP Client, Priority: high
Message-ID: <20241117142400.d9e3f1@example.com>
```

---

## 📊 **Performance Impact**

### **Sending Speed Comparison:**

| Configuration | Emails/Hour | 100 Emails | 1000 Emails |
|---------------|-------------|------------|-------------|
| **No Antibot** (2s fixed) | 1,800 | 3.3 min | 33 min |
| **Antibot (2-8s)** | ~800 | 7.5 min | 75 min |
| **Antibot + Humanize** | ~600 | 10 min | 100 min |
| **Fast (1-3s)** | 1,200 | 5 min | 50 min |
| **Slow (5-15s)** | 360 | 16.7 min | 167 min |

**Trade-off:** Slower sending = Better deliverability

---

## ✅ **Best Practices**

### **DO:**

- ✅ **Enable antibot features** for bulk campaigns
- ✅ **Use randomized delays** (2-8 seconds recommended)
- ✅ **Enable humanization** for large campaigns (>100 emails)
- ✅ **Keep all 7 features enabled** for maximum deliverability
- ✅ **Test with small batches** before large campaigns
- ✅ **Monitor delivery rates** and adjust settings
- ✅ **Use proper sender authentication** (SPF/DKIM/DMARC)

### **DON'T:**

- ❌ **Disable antibot** for bulk sending
- ❌ **Use very short delays** (<1 second)
- ❌ **Send too fast** (>1000/hour from single IP)
- ❌ **Forget to warm up** new sender addresses
- ❌ **Ignore bounce rates** and spam complaints
- ❌ **Skip testing** before large campaigns

---

## 🔍 **Troubleshooting**

### **Problem: Emails Going to Spam**

**Solutions:**
1. Enable all antibot features: `enable_antibot()`
2. Increase delay range: `delay_min: 5, delay_max: 15`
3. Enable humanization: `humanize_sending: True`
4. Check SPF/DKIM/DMARC records
5. Warm up sender reputation gradually

### **Problem: Sending Too Slow**

**Solutions:**
1. Reduce delay range: `delay_min: 1, delay_max: 3`
2. Disable humanization: `humanize_sending: False`
3. Keep other antibot features enabled
4. Consider using multiple sender addresses

### **Problem: Some Features Not Working**

**Solutions:**
1. Check master switch: `enable_antibot: True`
2. Verify each feature: `get_antibot_status()`
3. Enable specific feature: `EMAIL_CONFIG['randomize_headers'] = True`
4. Restart sending script

---

## 📚 **Quick Reference**

### **Enable/Disable:**

```python
enable_antibot()      # Turn ON all features
disable_antibot()     # Turn OFF all features
```

### **Check Status:**

```python
status = get_antibot_status()
print(status['mode'])
# Output: Antibot: ON | Features: 7/7
```

### **Configuration Shortcuts:**

```python
# Maximum deliverability
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 5,
    'delay_max': 15,
    'randomize_headers': True,
    'custom_message_id': True,
    'vary_user_agent': True,
    'add_reply_to': True,
    'humanize_sending': True,
    'rotate_priority': True,
}

# Fast with antibot
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 1,
    'delay_max': 3,
    'humanize_sending': False,
}

# Disable all
EMAIL_CONFIG = {
    'enable_antibot': False,
}
```

---

## 📋 **Summary**

**Antibot Security System:**

✅ **7 Advanced Features** for inbox delivery optimization  
✅ **Randomized delays** (2-8 seconds default)  
✅ **Custom headers** (Message-ID, X-Mailer, Priority)  
✅ **Human-like pauses** every 5-15 emails  
✅ **15 email client variations** (user agents)  
✅ **Weighted priority distribution** (80% normal)  
✅ **Reply-To headers** for better deliverability  
✅ **Production-ready** and fully tested  

**Default Behavior:**
- All features: **ON**
- Delay range: **2-8 seconds**
- Humanization: **ON**
- Features enabled: **7/7**

**Functions Available:**
- `enable_antibot()`
- `disable_antibot()`
- `get_antibot_status()`
- `get_random_delay()`
- `generate_message_id(from_email)`
- `get_random_user_agent()`
- `get_random_priority()`
- `get_random_headers(from_email)`
- `add_humanization_delay(count, total)`

---

**Your antibot security system is ready for maximum inbox delivery!** 🛡️

Combine with proper sender authentication (SPF/DKIM/DMARC) for best results.
