# 🚀 Quick Start - 30 Second Setup

## The Fastest Way to Validate Emails

### 1. Download (One File)

```bash
curl -O https://raw.githubusercontent.com/yourrepo/main/email_validator_standalone.py
```

Or just copy the `email_validator_standalone.py` file to your computer.

### 2. Run (Zero Install)

```bash
python3 email_validator_standalone.py validate test@gmail.com
```

**That's it!** 🎉

---

## Common Tasks

### Validate One Email
```bash
python3 email_validator_standalone.py validate admin@company.com
```

### Validate CSV File
```bash
python3 email_validator_standalone.py bulk emails.csv
```

### Interactive Mode
```bash
python3 email_validator_standalone.py interactive
```

---

## Sample Output

```
============================================================
Email: test@gmail.com
Domain: gmail.com
Valid Format: ✅ Yes
Deliverable: ✅ Yes
Provider: Google
MX Records: gmail-smtp-in.l.google.com, alt1.gmail-smtp-in...
Validation Time: 18.53ms
============================================================
```

---

## Optional Enhancement

For better DNS lookups:
```bash
pip install dnspython
```

---

## CSV Format

Your CSV can be any format - the script auto-detects emails:

```csv
Name,Email,Phone
John,john@example.com,555-1234
Jane,jane@gmail.com,555-5678
```

---

## Export Results

**Automatic:**
- `validation_results_TIMESTAMP.csv` (full details)
- `deliverable_emails_TIMESTAMP.txt` (valid emails only)

**Custom:**
```bash
python3 email_validator_standalone.py bulk emails.csv \
  --export my_results.csv \
  --deliverable valid_only.txt
```

---

## Features

✅ Email format validation  
✅ MX record DNS lookup  
✅ Provider detection (Microsoft, Google, Office365, GoDaddy, Mimecast, ARSMTP)  
✅ Bulk CSV processing (up to 10,000 emails)  
✅ Results export (CSV + TXT)  
✅ Performance timing  
✅ **Works offline** (uses Python standard library)  

---

## Help

```bash
python3 email_validator_standalone.py
```

Shows full usage guide.

---

## Requirements

- Python 3.7+ (already on most systems)
- That's all!

---

## No Installation Needed ✨

This is a **standalone script** - no git clone, no npm install, no database setup.

**Just download and run!**

---

For more details, see:
- [STANDALONE_README.md](STANDALONE_README.md) - Full usage guide
- [STANDALONE_INSTALL.md](STANDALONE_INSTALL.md) - Installation options
- [STANDALONE_COMPARISON.md](STANDALONE_COMPARISON.md) - vs Full Web App
