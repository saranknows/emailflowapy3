// Analytics page with API health and rate limit info
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { fetchAPI } from '@/lib/api';
import { Activity, Zap, TrendingUp } from 'lucide-react';

type APIStatus = {
  status: string;
  version: string;
  environment: string;
  rate_limit: string;
};

type RateLimitInfo = {
  limit: string;
  description: string;
};

export default function Analytics() {
  const { data: status, isLoading: statusLoading } = useQuery<APIStatus>({
    queryKey: ['/api/analytics/status'],
    queryFn: () => fetchAPI('/api/analytics/status')
  });

  const { data: rateLimit, isLoading: rateLimitLoading } = useQuery<RateLimitInfo>({
    queryKey: ['/api/analytics/rate-limits'],
    queryFn: () => fetchAPI('/api/analytics/rate-limits')
  });

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Analytics</h1>
        <p className="text-muted-foreground">
          API health status and performance metrics
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* API Status */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Status</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="flex items-center gap-2">
                <Badge 
                  className={status?.status === 'online' ? 'bg-emerald-500' : 'bg-red-500'}
                  data-testid="badge-api-status"
                >
                  {status?.status === 'online' ? 'Online' : 'Offline'}
                </Badge>
                {status?.status === 'online' && (
                  <div className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></div>
                )}
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-2">
              {status?.environment || 'development'} mode
            </p>
            <p className="text-xs text-muted-foreground">
              v{status?.version || '1.0.0'}
            </p>
          </CardContent>
        </Card>

        {/* Rate Limit */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rate Limit</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {rateLimitLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div>
                <div className="text-2xl font-bold" data-testid="text-rate-limit">
                  {rateLimit?.limit || '60/minute'}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {rateLimit?.description || 'Requests per minute'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Response Time */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-response-time">~200ms</div>
            <p className="text-xs text-muted-foreground mt-1">
              Email validation latency
            </p>
          </CardContent>
        </Card>
      </div>

      {/* API Information */}
      <Card>
        <CardHeader>
          <CardTitle>API Information</CardTitle>
          <CardDescription>
            Details about the Email Validator API service
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Endpoints</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li><code className="bg-muted px-2 py-1 rounded">POST /api/validate/single</code> - Validate single email</li>
              <li><code className="bg-muted px-2 py-1 rounded">POST /api/validate/bulk</code> - Bulk CSV validation (max 10,000)</li>
              <li><code className="bg-muted px-2 py-1 rounded">GET /api/validate/results</code> - Get validation history</li>
              <li><code className="bg-muted px-2 py-1 rounded">GET /api/validate/export/:provider</code> - Export by provider</li>
              <li><code className="bg-muted px-2 py-1 rounded">GET /api/analytics/status</code> - API health check</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Supported Providers</h3>
            <div className="flex flex-wrap gap-2">
              <Badge className="bg-blue-500">Microsoft</Badge>
              <Badge className="bg-red-500">Google</Badge>
              <Badge className="bg-orange-500">Office365</Badge>
              <Badge className="bg-purple-500">Mimecast</Badge>
              <Badge className="bg-emerald-500">ARSMTP</Badge>
              <Badge className="bg-yellow-500 text-black">GoDaddy</Badge>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Features</h3>
            <ul className="space-y-1 text-sm text-muted-foreground list-disc list-inside">
              <li>Email format validation</li>
              <li>MX record lookup and verification</li>
              <li>Multi-provider detection</li>
              <li>Bulk CSV processing (up to 10,000 emails)</li>
              <li>Service-specific exports</li>
              <li>Rate limiting (60 requests/minute)</li>
              <li>1 billion credits per user</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
