// Header component with navigation and user menu
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { fetchAPI } from '@/lib/api';
import { Mail, BarChart3, LogOut, User, Moon, Sun } from 'lucide-react';
import { useTheme } from '@/components/theme-provider';

export function Header() {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  const { data: credits } = useQuery<{ credits: number }>({
    queryKey: ['/api/auth/credits'],
    queryFn: () => fetchAPI('/api/auth/credits'),
    enabled: !!user
  });

  const formatCredits = (credits: number) => {
    if (credits >= 1_000_000_000) {
      return `${(credits / 1_000_000_000).toFixed(1)}B`;
    }
    if (credits >= 1_000_000) {
      return `${(credits / 1_000_000).toFixed(1)}M`;
    }
    if (credits >= 1_000) {
      return `${(credits / 1_000).toFixed(1)}K`;
    }
    return credits.toString();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2">
            <Mail className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Email Validator</span>
          </Link>

          {user && (
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/">
                <Button 
                  variant={location === '/' ? 'secondary' : 'ghost'}
                  size="sm"
                  data-testid="link-dashboard"
                >
                  Dashboard
                </Button>
              </Link>
              <Link href="/analytics">
                <Button 
                  variant={location === '/analytics' ? 'secondary' : 'ghost'}
                  size="sm"
                  data-testid="link-analytics"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics
                </Button>
              </Link>
            </nav>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            data-testid="button-theme-toggle"
          >
            {theme === 'dark' ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>

          {user && (
            <>
              {/* Credits Display */}
              <Badge variant="outline" className="px-3" data-testid="badge-credits">
                {formatCredits(credits?.credits || user.credits)} credits
              </Badge>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" data-testid="button-user-menu">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {user.first_name || user.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} data-testid="menu-item-logout">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
