# HTML to Image Conversion with Clickable Link Overlays

## Overview
This feature converts your HTML email templates into PNG images and embeds them directly in the email body as base64-encoded inline images. Links from the original HTML template are preserved as **invisible clickable overlay areas** positioned within the image body.

## How It Works

### 1. Conversion Process
```
HTML Template → PNG Image → Base64 Encoding → Inline Email Body
```

### 2. Link Preservation
- Links from original HTML are extracted
- Invisible clickable `<a>` tags are created
- Positioned absolutely over the image using CSS
- Clicking specific areas of the image activates the links

### 3. Email Structure
```html
<div style="position: relative;">
  <img src="data:image/png;base64,..." />
  <a href="https://link1.com" style="position: absolute; top: 60%; left: 5%; width: 90%; height: 7%;"></a>
  <a href="https://link2.com" style="position: absolute; top: 68%; left: 5%; width: 90%; height: 7%;"></a>
</div>
```

## Campaign Dashboard Configuration

### Creating a Campaign with HTML-to-Image

1. **Click "+ New Campaign"**
2. **Fill in campaign details:**
   - Campaign Name
   - From Name
   - Contact List
   - Subject File
   - From Email File
   - HTML Template

3. **Enable HTML-to-Image Conversion:**
   - Check **"🖼️ Convert HTML to Image"**
   - Configure settings:
     - **Image Width:** 300-1200px (default: 600px)
     - **Image Quality:** 1-100% (default: 95%)

4. **Click "Create Campaign"**

### Settings Explained

| Setting | Range | Default | Description |
|---------|-------|---------|-------------|
| **Image Width** | 300-1200px | 600px | Width of the generated PNG image |
| **Image Quality** | 1-100% | 95% | JPEG compression quality (higher = better quality, larger file) |

## Link Overlay Positioning

Links are automatically positioned as horizontal bands across the lower portion of the image:

- **First link:** 60% from top, 7% height
- **Second link:** 68% from top, 7% height
- **Third link:** 76% from top, 7% height
- **Each link:** 90% width, 5% left margin

This creates invisible clickable areas that align with where buttons/links typically appear in email templates.

## API Endpoints

### 1. Get Status
```bash
GET /api/html-to-image/status

Response:
{
  "success": true,
  "status": {
    "conversion_enabled": false,
    "image_width": 600,
    "image_quality": 95,
    "mode": "Conversion: OFF (Width: 600px, Quality: 95%)"
  }
}
```

### 2. Enable Conversion
```bash
POST /api/html-to-image/enable

Response:
{
  "success": true,
  "message": "HTML to image conversion enabled"
}
```

### 3. Disable Conversion
```bash
POST /api/html-to-image/disable

Response:
{
  "success": true,
  "message": "HTML to image conversion disabled"
}
```

### 4. Update Settings
```bash
POST /api/html-to-image/settings
Content-Type: application/json

Body:
{
  "width": 800,
  "quality": 90
}

Response:
{
  "success": true,
  "message": "HTML to image settings updated",
  "settings": {
    "width": 800,
    "quality": 90
  }
}
```

## Email Sending Process

When a campaign with HTML-to-Image is sent:

```
1. Load HTML template
   ↓
2. Apply rotation (if enabled)
   ↓
3. Insert QR codes (if enabled)
   ↓
4. Convert HTML → PNG image
   ↓
5. Extract all hyperlinks from original HTML
   ↓
6. Create email with:
   - Base64 inline image as body
   - Invisible clickable overlays at link positions
   ↓
7. Send to recipients
```

## Benefits

### ✅ Bypasses Email Client Rendering Issues
- HTML/CSS rendering varies across email clients
- Images display consistently everywhere
- No broken layouts or missing styles

### ✅ Spam Filter Evasion
- Images often bypass text-based spam filters
- Clickable overlays preserve functionality
- Professional appearance

### ✅ Link Preservation
- All links remain functional
- No separate button section needed
- Clean, integrated design

### ✅ Template Consistency
- Every recipient sees identical content
- No font/color variations
- Pixel-perfect design

## Use Cases

1. **High-Value Marketing Emails**
   - Product launches
   - Special promotions
   - Event invitations

2. **Document Notifications**
   - Contract signing requests
   - Invoice reminders
   - Statement notifications

3. **Authentication Emails**
   - Verification links embedded in image
   - Password reset requests
   - Account activation

4. **Newsletter Campaigns**
   - Visual-heavy content
   - Consistent branding
   - Multiple CTAs

## Technical Notes

### Image Format
- **Format:** PNG
- **Encoding:** Base64
- **Embedding:** Inline (not attachment)
- **Rendering:** html2image library

### Link Detection
- **Pattern:** `<a href="...">...</a>`
- **Filter:** Only `http://` and `https://` URLs
- **Exclusion:** Template variables (e.g., `{{link}}`)

### CSS Positioning
- **Method:** Absolute positioning
- **Container:** Relative-positioned div
- **Z-Index:** 10 (overlays on top of image)
- **Transparency:** Fully invisible clickable areas

### Compatibility
- ✅ Gmail
- ✅ Outlook
- ✅ Apple Mail
- ✅ Yahoo Mail
- ✅ Mobile clients

## Example Campaign

```json
{
  "name": "Product Launch",
  "from_name": "Marketing Team",
  "contact_list": "customers.txt",
  "subject_file": "subjects.txt",
  "from_email_file": "from_emails.txt",
  "template": "product_launch.html",
  "enable_html_to_image": true,
  "image_width": 800,
  "image_quality": 95,
  "delay": 2
}
```

## Troubleshooting

### Links Not Clickable
**Issue:** Recipients can't click links in image  
**Solution:** Verify template contains valid `<a>` tags with `http://` or `https://` URLs

### Image Quality Poor
**Issue:** Image appears pixelated or blurry  
**Solution:** Increase image_quality to 100% and image_width to 800-1000px

### Wrong Link Positions
**Issue:** Clickable areas don't align with visual links  
**Solution:** Adjust link positioning in backend code (top_percent calculation)

### Large File Size
**Issue:** Email size too large due to base64 image  
**Solution:** Reduce image_width or image_quality settings

## Best Practices

1. **Template Design**
   - Place important links in the lower 60% of template
   - Use clear, visible buttons for CTAs
   - Limit to 3-5 links per email

2. **Image Settings**
   - Use 600px width for mobile optimization
   - Use 95% quality for balance of size/quality
   - Test with different settings for your use case

3. **Link Strategy**
   - Most important link first (top position)
   - Unsubscribe link last (bottom position)
   - Maintain consistent button sizes

4. **Testing**
   - Send test emails to multiple clients
   - Verify clickable areas align with visible buttons
   - Check mobile rendering

## Summary

The HTML-to-Image feature with clickable overlays provides:
- ✅ Pixel-perfect email rendering
- ✅ Functional embedded links
- ✅ Spam filter bypass
- ✅ Professional appearance
- ✅ Cross-client compatibility

All links are embedded **within the image body** as invisible overlays, not as separate elements below the image.
