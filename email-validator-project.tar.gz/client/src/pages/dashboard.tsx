// Dashboard page with email validation and click tracking interface
import { useState, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { queryClient } from '@/lib/queryClient';
import { apiRequest, fetchAPI } from '@/lib/api';
import { 
  Upload, 
  CheckCircle2, 
  XCircle, 
  Download, 
  Trash2,
  TrendingUp,
  Database,
  Clock,
  Link2,
  MousePointerClick,
  Users,
  BarChart3,
  Shield,
  Key,
  Copy
} from 'lucide-react';

type ValidationResult = {
  id: string;
  email: string;
  domain: string;
  is_valid: boolean;
  is_deliverable: boolean;
  provider: string | null;
  is_microsoft: boolean;
  is_google: boolean;
  is_office365: boolean;
  is_mimecast: boolean;
  is_arsmtp: boolean;
  is_godaddy: boolean;
  mx_records: string[] | null;
  validation_time: number | null;
};

type ValidationStats = {
  total: number;
  deliverable: number;
  microsoft: number;
  google: number;
  office365: number;
  mimecast: number;
  arsmtp: number;
  godaddy: number;
};

type Campaign = {
  id: string;
  name: string;
  description: string | null;
  targetUrl: string;
  createdAt: string;
  totalLinks?: number;
  totalClicks?: number;
  uniqueClicks?: number;
};

type TrackingLink = {
  id: string;
  campaignId: string;
  token: string;
  recipient: string;
  trackingUrl: string;
  clickCount: number;
  firstClickAt: string | null;
  lastClickAt: string | null;
};

type LicenseKey = {
  id: string;
  key: string;
  assignedUserId: string | null;
  status: 'active' | 'revoked';
  issuedAt: string;
  assignedAt: string | null;
  revokedAt: string | null;
};

export default function Dashboard() {
  // Email validation state
  const [singleEmail, setSingleEmail] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Click tracking state
  const [campaignName, setCampaignName] = useState('');
  const [campaignDesc, setCampaignDesc] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [selectedCampaign, setSelectedCampaign] = useState<string | null>(null);
  const linkFileInputRef = useRef<HTMLInputElement>(null);
  
  // Admin state
  const [licenseKeyCount, setLicenseKeyCount] = useState(1);
  
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch validation results
  const { data: results = [], isLoading: resultsLoading, refetch: refetchResults } = useQuery<ValidationResult[]>({
    queryKey: ['/api/validate/results'],
    queryFn: () => fetchAPI('/api/validate/results?limit=100')
  });

  // Fetch stats
  const { data: stats, isLoading: statsLoading } = useQuery<ValidationStats>({
    queryKey: ['/api/validate/stats'],
    queryFn: () => fetchAPI('/api/validate/stats')
  });

  // Single email validation mutation
  const validateSingleMutation = useMutation({
    mutationFn: async (email: string) => {
      const res = await apiRequest('POST', '/api/validate/single', { email });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Email validated',
        description: 'Validation complete!'
      });
      setSingleEmail('');
      queryClient.invalidateQueries({ queryKey: ['/api/validate/results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/validate/stats'] });
    },
    onError: (error) => {
      toast({
        title: 'Validation failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  // Bulk validation mutation
  const validateBulkMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const res = await apiRequest('POST', '/api/validate/bulk', formData);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Bulk validation complete',
        description: `Validated ${data.total} emails. ${data.deliverable} deliverable.`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/validate/results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/validate/stats'] });
    },
    onError: (error) => {
      toast({
        title: 'Bulk validation failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  // Clear results mutation
  const clearMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', '/api/validate/clear');
    },
    onSuccess: () => {
      toast({
        title: 'Results cleared',
        description: 'All validation results have been removed'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/validate/results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/validate/stats'] });
    }
  });

  // Fetch campaigns
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/tracking/campaigns'],
    queryFn: () => fetchAPI('/api/tracking/campaigns')
  });

  // Create campaign mutation
  const createCampaignMutation = useMutation({
    mutationFn: async (data: { name: string; description: string; targetUrl: string }) => {
      const res = await apiRequest('POST', '/api/tracking/campaigns', data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Campaign created',
        description: `Created campaign: ${data.name}`
      });
      setCampaignName('');
      setCampaignDesc('');
      setTargetUrl('');
      setSelectedCampaign(data.id);
      queryClient.invalidateQueries({ queryKey: ['/api/tracking/campaigns'] });
    },
    onError: (error) => {
      toast({
        title: 'Failed to create campaign',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  // Generate tracking links mutation
  const generateLinksMutation = useMutation({
    mutationFn: async ({ campaignId, file }: { campaignId: string; file: File }) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const res = await apiRequest('POST', `/api/tracking/campaigns/${campaignId}/links`, formData);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Tracking links generated',
        description: `Created ${data.count} tracking links`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tracking/campaigns'] });
    },
    onError: (error) => {
      toast({
        title: 'Failed to generate links',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  // Fetch license keys (admin only)
  const { data: licenseKeys = [], isLoading: licenseKeysLoading } = useQuery<LicenseKey[]>({
    queryKey: ['/api/admin/license-keys'],
    queryFn: () => fetchAPI('/api/admin/license-keys'),
    enabled: !!user?.isAdmin
  });

  // Generate license keys mutation (admin only)
  const generateLicenseKeysMutation = useMutation({
    mutationFn: async (count: number) => {
      const res = await apiRequest('POST', '/api/admin/license-keys', { count });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'License keys generated',
        description: `Generated ${data.keys.length} new license keys`
      });
      setLicenseKeyCount(1);
      queryClient.invalidateQueries({ queryKey: ['/api/admin/license-keys'] });
    },
    onError: (error) => {
      toast({
        title: 'Failed to generate keys',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  // Revoke license key mutation (admin only)
  const revokeLicenseKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      const res = await apiRequest('PUT', `/api/admin/license-keys/${keyId}/revoke`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'License key revoked',
        description: 'The license key has been revoked and the user can no longer login'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/license-keys'] });
    },
    onError: (error) => {
      toast({
        title: 'Failed to revoke key',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  });

  const handleSingleValidation = (e: React.FormEvent) => {
    e.preventDefault();
    if (singleEmail.trim()) {
      validateSingleMutation.mutate(singleEmail);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      validateBulkMutation.mutate(file);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleCreateCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (campaignName.trim() && targetUrl.trim()) {
      createCampaignMutation.mutate({
        name: campaignName,
        description: campaignDesc,
        targetUrl: targetUrl
      });
    }
  };

  const handleLinkFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedCampaign) {
      generateLinksMutation.mutate({ campaignId: selectedCampaign, file });
      if (linkFileInputRef.current) {
        linkFileInputRef.current.value = '';
      }
    } else if (!selectedCampaign) {
      toast({
        title: 'No campaign selected',
        description: 'Please select a campaign first',
        variant: 'destructive'
      });
    }
  };

  const handleExport = async (provider: string) => {
    try {
      const res = await fetch(`/api/validate/export/${provider}`, {
        credentials: 'include'
      });
      if (!res.ok) throw new Error('Export failed');
      
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${provider}-emails.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: 'Export successful',
        description: `Downloaded ${provider} emails`
      });
    } catch (error) {
      toast({
        title: 'Export failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    }
  };

  const getProviderBadge = (result: ValidationResult) => {
    if (!result.is_deliverable) return null;
    
    if (result.is_microsoft) return <Badge className="bg-blue-500">Microsoft</Badge>;
    if (result.is_google) return <Badge className="bg-red-500">Google</Badge>;
    if (result.is_office365) return <Badge className="bg-orange-500">Office365</Badge>;
    if (result.is_mimecast) return <Badge className="bg-purple-500">Mimecast</Badge>;
    if (result.is_arsmtp) return <Badge className="bg-emerald-500">ARSMTP</Badge>;
    if (result.is_godaddy) return <Badge className="bg-yellow-500 text-black">GoDaddy</Badge>;
    
    return result.provider ? <Badge variant="secondary">{result.provider}</Badge> : null;
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-8 w-8 mb-2" />
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))
        ) : (
          <>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Validated</CardTitle>
                <Database className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="stat-total">{stats?.total || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Deliverable</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="stat-deliverable">{stats?.deliverable || 0}</div>
                <p className="text-xs text-muted-foreground">
                  {stats?.total ? Math.round((stats.deliverable / stats.total) * 100) : 0}% success rate
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Microsoft</CardTitle>
                <Badge className="bg-blue-500 h-6 w-6 p-0 flex items-center justify-center">M</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="stat-microsoft">{stats?.microsoft || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Google</CardTitle>
                <Badge className="bg-red-500 h-6 w-6 p-0 flex items-center justify-center">G</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="stat-google">{stats?.google || 0}</div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Validation Interface */}
      <Card className="max-w-3xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl">Email Validation</CardTitle>
          <CardDescription>
            Validate single emails or upload CSV files (max 10,000 emails)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="single">
            <TabsList className={`grid w-full ${user?.isAdmin ? 'grid-cols-4' : 'grid-cols-3'}`}>
              <TabsTrigger value="single" data-testid="tab-single">Single Email</TabsTrigger>
              <TabsTrigger value="bulk" data-testid="tab-bulk">Bulk Upload</TabsTrigger>
              <TabsTrigger value="tracking" data-testid="tab-tracking">
                <Link2 className="h-4 w-4 mr-2" />
                Link Tracking
              </TabsTrigger>
              {user?.isAdmin === true && (
                <TabsTrigger value="admin" data-testid="tab-admin">
                  <Shield className="h-4 w-4 mr-2" />
                  Admin
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="single" className="space-y-4">
              <form onSubmit={handleSingleValidation} className="space-y-4">
                <Input
                  type="email"
                  placeholder="email@example.com"
                  value={singleEmail}
                  onChange={(e) => setSingleEmail(e.target.value)}
                  className="h-14 text-lg"
                  required
                  data-testid="input-single-email"
                />
                <Button 
                  type="submit" 
                  className="w-full h-12"
                  disabled={validateSingleMutation.isPending}
                  data-testid="button-validate-single"
                >
                  {validateSingleMutation.isPending ? 'Validating...' : 'Validate Email'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="bulk" className="space-y-4">
              <div
                className="border-2 border-dashed border-primary/30 rounded-lg p-12 text-center hover-elevate cursor-pointer transition-colors"
                onClick={() => fileInputRef.current?.click()}
                data-testid="dropzone-bulk"
              >
                <Upload className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-semibold mb-2">Drop CSV file here</h3>
                <p className="text-sm text-muted-foreground">
                  Or click to browse files (max 10,000 emails)
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                  data-testid="input-file-upload"
                />
              </div>
              {validateBulkMutation.isPending && (
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4 animate-spin" />
                  <span>Processing bulk validation...</span>
                </div>
              )}
            </TabsContent>

            <TabsContent value="tracking" className="space-y-6">
              {/* Create Campaign Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Create Campaign</h3>
                <form onSubmit={handleCreateCampaign} className="space-y-4">
                  <Input
                    placeholder="Campaign name (e.g., Spring Newsletter 2025)"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    required
                    data-testid="input-campaign-name"
                  />
                  <Textarea
                    placeholder="Description (optional)"
                    value={campaignDesc}
                    onChange={(e) => setCampaignDesc(e.target.value)}
                    rows={2}
                    data-testid="input-campaign-description"
                  />
                  <Input
                    type="url"
                    placeholder="Target URL (e.g., https://example.com/landing)"
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    required
                    data-testid="input-target-url"
                  />
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={createCampaignMutation.isPending}
                    data-testid="button-create-campaign"
                  >
                    {createCampaignMutation.isPending ? 'Creating...' : 'Create Campaign'}
                  </Button>
                </form>
              </div>

              {/* Generate Tracking Links Section */}
              {campaigns.length > 0 && (
                <div className="space-y-4 pt-6 border-t">
                  <h3 className="text-lg font-semibold">Generate Tracking Links</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Select Campaign</label>
                      <select
                        className="w-full h-10 rounded-md border border-input bg-background px-3 py-2"
                        value={selectedCampaign || ''}
                        onChange={(e) => setSelectedCampaign(e.target.value || null)}
                        data-testid="select-campaign"
                      >
                        <option value="">-- Select a campaign --</option>
                        {campaigns.map((campaign) => (
                          <option key={campaign.id} value={campaign.id}>
                            {campaign.name} ({campaign.totalLinks || 0} links)
                          </option>
                        ))}
                      </select>
                    </div>

                    {selectedCampaign && (
                      <div
                        className="border-2 border-dashed border-primary/30 rounded-lg p-8 text-center hover-elevate cursor-pointer transition-colors"
                        onClick={() => linkFileInputRef.current?.click()}
                        data-testid="dropzone-tracking-links"
                      >
                        <Upload className="h-10 w-10 mx-auto mb-3 text-primary" />
                        <h3 className="font-semibold mb-2">Upload Recipients CSV</h3>
                        <p className="text-sm text-muted-foreground">
                          CSV with email column (max 10,000 recipients)
                        </p>
                        <input
                          ref={linkFileInputRef}
                          type="file"
                          accept=".csv"
                          onChange={handleLinkFileUpload}
                          className="hidden"
                          data-testid="input-link-file-upload"
                        />
                      </div>
                    )}

                    {generateLinksMutation.isPending && (
                      <div className="flex items-center justify-center gap-2 text-muted-foreground">
                        <Clock className="h-4 w-4 animate-spin" />
                        <span>Generating tracking links...</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Campaign List */}
              {campaigns.length > 0 && (
                <div className="space-y-4 pt-6 border-t">
                  <h3 className="text-lg font-semibold">Your Campaigns</h3>
                  <div className="grid gap-4">
                    {campaigns.map((campaign) => (
                      <Card key={campaign.id} className="hover-elevate">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className="text-lg">{campaign.name}</CardTitle>
                              {campaign.description && (
                                <CardDescription className="mt-1">{campaign.description}</CardDescription>
                              )}
                            </div>
                            <Badge variant="secondary" className="ml-2">
                              {new Date(campaign.createdAt).toLocaleDateString()}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Link2 className="h-4 w-4" />
                              <span className="font-mono text-xs truncate">{campaign.targetUrl}</span>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-4 pt-3 border-t">
                              <div className="text-center">
                                <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                                  <Users className="h-4 w-4" />
                                </div>
                                <div className="text-2xl font-bold">{campaign.totalLinks || 0}</div>
                                <div className="text-xs text-muted-foreground">Links</div>
                              </div>
                              <div className="text-center">
                                <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                                  <MousePointerClick className="h-4 w-4" />
                                </div>
                                <div className="text-2xl font-bold">{campaign.totalClicks || 0}</div>
                                <div className="text-xs text-muted-foreground">Clicks</div>
                              </div>
                              <div className="text-center">
                                <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                                  <BarChart3 className="h-4 w-4" />
                                </div>
                                <div className="text-2xl font-bold">{campaign.uniqueClicks || 0}</div>
                                <div className="text-xs text-muted-foreground">Unique</div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {campaigns.length === 0 && !campaignsLoading && (
                <div className="text-center py-8 text-muted-foreground">
                  <Link2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No campaigns yet. Create your first campaign above!</p>
                </div>
              )}
            </TabsContent>

            {user?.isAdmin === true && (
              <TabsContent value="admin" className="space-y-6">
                {/* Generate License Keys Section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Generate License Keys
                  </h3>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (licenseKeyCount > 0 && licenseKeyCount <= 100) {
                        generateLicenseKeysMutation.mutate(licenseKeyCount);
                      }
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Input
                        type="number"
                        min={1}
                        max={100}
                        placeholder="Number of keys to generate (1-100)"
                        value={licenseKeyCount}
                        onChange={(e) => setLicenseKeyCount(parseInt(e.target.value) || 1)}
                        data-testid="input-license-key-count"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Generate up to 100 license keys at once
                      </p>
                    </div>
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={generateLicenseKeysMutation.isPending || licenseKeyCount < 1 || licenseKeyCount > 100}
                      data-testid="button-generate-keys"
                    >
                      {generateLicenseKeysMutation.isPending ? 'Generating...' : `Generate ${licenseKeyCount} Key${licenseKeyCount === 1 ? '' : 's'}`}
                    </Button>
                  </form>
                </div>

                {/* License Keys List */}
                <div className="space-y-4 pt-6 border-t">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Key className="h-5 w-5" />
                    License Keys ({licenseKeys.length})
                  </h3>

                  {licenseKeysLoading ? (
                    <div className="space-y-2">
                      {[1, 2, 3].map((i) => (
                        <Skeleton key={i} className="h-20 w-full" />
                      ))}
                    </div>
                  ) : licenseKeys.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Key className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No license keys yet. Generate your first key above!</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {licenseKeys.map((licenseKey) => (
                        <Card key={licenseKey.id} className="p-4">
                          <div className="space-y-3">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <code className="text-sm font-mono bg-muted px-2 py-1 rounded break-all">
                                    {licenseKey.key}
                                  </code>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      navigator.clipboard.writeText(licenseKey.key);
                                      toast({
                                        title: 'Copied to clipboard',
                                        description: 'License key copied successfully'
                                      });
                                    }}
                                    data-testid={`button-copy-${licenseKey.id}`}
                                  >
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                </div>
                                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                                  <span>Issued: {new Date(licenseKey.issuedAt).toLocaleDateString()}</span>
                                  {licenseKey.assignedAt && (
                                    <span>• Assigned: {new Date(licenseKey.assignedAt).toLocaleDateString()}</span>
                                  )}
                                  {licenseKey.revokedAt && (
                                    <span>• Revoked: {new Date(licenseKey.revokedAt).toLocaleDateString()}</span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge 
                                  variant={licenseKey.status === 'active' ? 'default' : 'destructive'}
                                  data-testid={`badge-status-${licenseKey.id}`}
                                >
                                  {licenseKey.status}
                                </Badge>
                                <Badge 
                                  variant={licenseKey.assignedUserId ? 'secondary' : 'outline'}
                                  data-testid={`badge-assigned-${licenseKey.id}`}
                                >
                                  {licenseKey.assignedUserId ? 'Assigned' : 'Available'}
                                </Badge>
                              </div>
                            </div>
                            {licenseKey.status === 'active' && licenseKey.assignedUserId && (
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => revokeLicenseKeyMutation.mutate(licenseKey.id)}
                                disabled={revokeLicenseKeyMutation.isPending}
                                data-testid={`button-revoke-${licenseKey.id}`}
                              >
                                {revokeLicenseKeyMutation.isPending ? 'Revoking...' : 'Revoke Key'}
                              </Button>
                            )}
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>
            )}
          </Tabs>
        </CardContent>
      </Card>

      {/* Results Table */}
      {results.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Validation Results</CardTitle>
              <CardDescription>Recent email validations</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExport('all')}
                data-testid="button-export-all"
              >
                <Download className="h-4 w-4 mr-2" />
                Export All
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => clearMutation.mutate()}
                data-testid="button-clear-results"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {results.map((result) => (
                <div
                  key={result.id}
                  className="flex items-center justify-between p-3 rounded-lg border hover-elevate"
                  data-testid={`result-${result.id}`}
                >
                  <div className="flex-1">
                    <div className="font-mono text-sm">{result.email}</div>
                    <div className="text-xs text-muted-foreground">{result.domain}</div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {getProviderBadge(result)}
                    
                    {result.is_deliverable ? (
                      <div className="flex items-center gap-1 text-emerald-500">
                        <CheckCircle2 className="h-4 w-4" />
                        <span className="text-xs font-medium">Deliverable</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 text-red-500">
                        <XCircle className="h-4 w-4" />
                        <span className="text-xs font-medium">Invalid</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Export Buttons */}
      {stats && stats.deliverable > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Export by Provider</CardTitle>
            <CardDescription>Download deliverable emails for each provider</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {stats.microsoft > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('microsoft')}
                  className="bg-blue-500/10"
                  data-testid="button-export-microsoft"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Microsoft ({stats.microsoft})
                </Button>
              )}
              {stats.google > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('google')}
                  className="bg-red-500/10"
                  data-testid="button-export-google"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Google ({stats.google})
                </Button>
              )}
              {stats.office365 > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('office365')}
                  className="bg-orange-500/10"
                  data-testid="button-export-office365"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Office365 ({stats.office365})
                </Button>
              )}
              {stats.mimecast > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('mimecast')}
                  className="bg-purple-500/10"
                  data-testid="button-export-mimecast"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Mimecast ({stats.mimecast})
                </Button>
              )}
              {stats.arsmtp > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('arsmtp')}
                  className="bg-emerald-500/10"
                  data-testid="button-export-arsmtp"
                >
                  <Download className="h-4 w-4 mr-2" />
                  ARSMTP ({stats.arsmtp})
                </Button>
              )}
              {stats.godaddy > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('godaddy')}
                  className="bg-yellow-500/10"
                  data-testid="button-export-godaddy"
                >
                  <Download className="h-4 w-4 mr-2" />
                  GoDaddy ({stats.godaddy})
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
