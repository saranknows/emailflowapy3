# From Name Rotation Feature Guide

## Overview
The **From Name Rotation** feature allows you to rotate sender display names along with email addresses. This provides better personalization and helps make your emails appear more professional and varied.

---

## How It Works

When sending emails, the system will:
1. **Load sender names** from `from_names/from_names.txt`
2. **Rotate through names** using the same rotation logic as other features
3. **Format emails** as: `Name <email@example.com>`

### Example Output:
```
From: Customer Support <info@besthomeimprovement.biz>
From: Marketing Team <admin@autoblog247.net>
From: Sales Department <info@besthomeimprovement.biz>
From: Information Desk <admin@autoblog247.net>
```

---

## Setup Instructions

### Step 1: Create From Names File

**File:** `from_names/from_names.txt`

**Format:** One sender name per line

**Example:**
```
Customer Support
Marketing Team
Sales Department
Information Desk
Help Center
Account Manager
Service Team
Support Staff
```

### Step 2: File Location

Place your file here:
```
your-project/
├── from_names/
│   └── from_names.txt     ← Your sender names here
├── from_emails/
│   └── fromemails.txt     ← Your sender email addresses
├── main.py
└── ...
```

---

## Usage

### Enable in main.py

The from name rotation is **automatically enabled** when you run `main.py`.

### Default Behavior

If `from_names/from_names.txt` doesn't exist or is empty, the system will use these default names:
- Customer Support
- Marketing Team
- Sales Department
- Information Desk

### Rotation Logic

From names rotate **independently** from email addresses:
- Email #1: Name #1 + Email #1
- Email #2: Name #2 + Email #2
- Email #3: Name #3 + Email #3
- And so on...

When you have more emails than names (or vice versa), the rotation cycles back to the beginning.

---

## Best Practices

### ✅ DO:
- Use professional, trustworthy names
- Keep names consistent with your brand
- Use department names (e.g., "Customer Support")
- Use role names (e.g., "Account Manager")
- Match the name to your email content

### ❌ DON'T:
- Use personal names unless they're verified identities
- Use misleading or deceptive names
- Use names that don't match your domain
- Use special characters or emojis

---

## Examples

### Professional Names (B2B):
```
Account Executive
Business Development
Partnership Team
Solutions Architect
Customer Success
Sales Team
Marketing Department
```

### Support Names (Customer Service):
```
Customer Support
Help Desk
Technical Support
Support Team
Service Center
Care Team
```

### Marketing Names:
```
Marketing Team
Newsletter
Promotions Team
Updates Team
Communications
Community Manager
```

---

## How It Appears in Email Clients

### Gmail:
```
Customer Support <info@besthomeimprovement.biz>
```

### Outlook:
```
Customer Support
info@besthomeimprovement.biz
```

### Apple Mail:
```
Customer Support
```

**Note:** Most email clients display the name prominently and show the email address when hovering or viewing details.

---

## Testing

### Test the Feature:

1. Create `from_names/from_names.txt` with sample names
2. Run `python main.py`
3. Check the console output to see name rotation
4. Send a test email and verify the "From" field

### Console Output Example:
```
✍️  Loaded 8 sender names
...
1/8 | To: test@example.com... | From: Customer Support <info@...>
2/8 | To: test2@example.com... | From: Marketing Team <admin@...>
3/8 | To: test3@example.com... | From: Sales Department <info@...>
```

---

## Advanced Configuration

### Multiple Name Files

Currently, the system supports one file: `from_names.txt`

### Custom Names Per Campaign

To use different names for different campaigns:
1. Edit `from_names/from_names.txt` before each run
2. Or hardcode names in `main.py` (line ~850)

### Pairing Names with Specific Emails

If you want specific names to always match specific emails:
1. Order your names to match your email addresses
2. Use the same number of names and emails
3. The rotation will naturally pair them

Example:
```
from_names.txt:          fromemails.txt:
------------------       -------------------
Support Team       →     support@example.com
Sales Team         →     sales@example.com
Info Desk          →     info@example.com
```

---

## Troubleshooting

### Issue: Names not appearing
**Solution:** Check that `from_names/from_names.txt` exists and contains valid names

### Issue: Using default names
**Solution:** Verify your file path is `from_names/from_names.txt` (not `from_name/`)

### Issue: Special characters broken
**Solution:** Save file as UTF-8 encoding, avoid special characters

### Issue: Emails showing only email address
**Solution:** Check that `send_email()` function is receiving the `from_name` parameter

---

## Summary

The **From Name Rotation** feature provides:
- ✅ Professional sender name display
- ✅ Automatic rotation like other features
- ✅ Better email personalization
- ✅ Improved deliverability perception
- ✅ Simple text file configuration

**File:** `from_names/from_names.txt`  
**Format:** One name per line  
**Rotation:** Automatic, cycles through all names  
**Display:** `Name <email@address.com>`

---

## Next Steps

1. Create your `from_names/from_names.txt` file
2. Add professional sender names
3. Run `python main.py` to test
4. Verify names appear correctly in sent emails
5. Adjust names based on campaign goals

**Your from name rotation is now ready to use!** 🎉
