# Subject Line Management Guide

## Overview
This guide explains how to manage the 10,000 subject lines in your email marketing platform. The system includes functions to enable/disable subject line rotation and control which subject files are used.

---

## 📊 **Subject Line Statistics**

- **Total Subject Lines:** 10,000
- **Total Files:** 10
- **Lines Per File:** 1,000
- **File Format:** `.txt` files in `subjects/` folder
- **File Names:** `subjects_01.txt` through `subjects_10.txt`

---

## 📁 **Subject File Organization**

### **File Structure**

```
subjects/
├── subjects_01.txt    (1,000 subject lines)
├── subjects_02.txt    (1,000 subject lines)
├── subjects_03.txt    (1,000 subject lines)
├── subjects_04.txt    (1,000 subject lines)
├── subjects_05.txt    (1,000 subject lines)
├── subjects_06.txt    (1,000 subject lines)
├── subjects_07.txt    (1,000 subject lines)
├── subjects_08.txt    (1,000 subject lines)
├── subjects_09.txt    (1,000 subject lines)
└── subjects_10.txt    (1,000 subject lines)
```

### **Subject Categories**

The 10,000 subjects are based on 10 professional categories:

1. **Urgent** - Time-sensitive, action-required subjects
2. **Document** - Document signing, review, approval
3. **Notification** - General notifications and updates
4. **Invitation** - Event invitations, RSVP requests
5. **Confirmation** - Verification and confirmation requests
6. **Reminder** - Friendly reminders and follow-ups
7. **Alert** - Security and account alerts
8. **Update** - System and policy updates
9. **Offer** - Promotions and special offers
10. **Request** - Information and feedback requests

---

## ⚙️ **Configuration**

### **EMAIL_CONFIG Settings**

Located in `main.py` around line 67:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    # Subject Line Configuration
    'enable_subjects': True,    # True = rotation ON, False = rotation OFF
    'subject_files': [],        # Empty = use all files, or specify files
    
    # ... other settings ...
}
```

### **Configuration Options**

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `enable_subjects` | Boolean | `True` | Enable/disable subject line rotation |
| `subject_files` | List | `[]` | Empty = use all files, or specify files to use |

---

## 🔧 **Functions**

### **1. Enable Subject Line Rotation**

```python
enable_subjects()
```

**Purpose:** Turn on subject line rotation  
**Returns:** `True`  
**Example:**
```python
>>> enable_subjects()
✅ Subject line rotation enabled
```

### **2. Disable Subject Line Rotation**

```python
disable_subjects()
```

**Purpose:** Turn off subject line rotation (uses default subject)  
**Returns:** `True`  
**Example:**
```python
>>> disable_subjects()
✅ Subject line rotation disabled
```

### **3. Get Subject Status**

```python
get_subject_status()
```

**Purpose:** Check current subject line configuration  
**Returns:** Dictionary with status information  
**Example:**
```python
>>> status = get_subject_status()
>>> print(status)
{
    'subjects_enabled': True,
    'subject_files': 'All files',
    'total_files': 10,
    'mode': 'Subjects: ON | Files: 10'
}
```

### **4. Set Specific Subject Files**

```python
set_subject_files(file_list)
```

**Purpose:** Use only specific subject files  
**Args:** List of file names or empty list for all  
**Returns:** `True` if successful, `False` if files not found  
**Examples:**

**Use specific files:**
```python
>>> set_subject_files(['subjects_01.txt', 'subjects_02.txt'])
✅ Using 2 specific subject file(s): subjects_01.txt, subjects_02.txt
```

**Use all files:**
```python
>>> set_subject_files([])
✅ Using all subject files
```

### **5. List Subject Files**

```python
list_subject_files()
```

**Purpose:** List all available subject files with details  
**Returns:** List of dictionaries with file information  
**Example:**
```python
>>> files = list_subject_files()
>>> for f in files:
...     print(f"{f['filename']}: {f['line_count']} lines")
subjects_01.txt: 1000 lines
subjects_02.txt: 1000 lines
...
```

### **6. Count Total Subjects**

```python
count_total_subjects()
```

**Purpose:** Get total number of subject lines available  
**Returns:** Integer count  
**Example:**
```python
>>> total = count_total_subjects()
>>> print(f"Total subjects: {total}")
Total subjects: 10000
```

---

## 💡 **Usage Examples**

### **Example 1: Use All Subject Lines (Default)**

```python
# In main.py EMAIL_CONFIG
EMAIL_CONFIG = {
    'enable_subjects': True,
    'subject_files': [],  # Empty = use all files
}

# Or using function
enable_subjects()
set_subject_files([])
```

**Result:** All 10,000 subject lines will be used in rotation.

---

### **Example 2: Disable Subject Rotation**

```python
# In main.py EMAIL_CONFIG
EMAIL_CONFIG = {
    'enable_subjects': False,
}

# Or using function
disable_subjects()
```

**Result:** System uses default subject "Important Document" for all emails.

---

### **Example 3: Use Only First 2 Files (2,000 Subjects)**

```python
# In main.py EMAIL_CONFIG
EMAIL_CONFIG = {
    'enable_subjects': True,
    'subject_files': ['subjects_01.txt', 'subjects_02.txt'],
}

# Or using function
set_subject_files(['subjects_01.txt', 'subjects_02.txt'])
```

**Result:** Only 2,000 subject lines from first 2 files will be used.

---

### **Example 4: Use Only Urgent & Document Subjects**

```python
# Use first file (urgent subjects) and part of second file
set_subject_files(['subjects_01.txt'])
```

**Result:** Approximately 1,000 urgent-focused subject lines.

---

### **Example 5: Rotate Through All Subjects Then Check Status**

```python
# Enable all subjects
enable_subjects()
set_subject_files([])

# Check status
status = get_subject_status()
print(status['mode'])
# Output: Subjects: ON | Files: 10

# Count total
total = count_total_subjects()
print(f"Using {total} subject lines")
# Output: Using 10000 subject lines
```

---

## 🔄 **How Subject Rotation Works**

### **Loading Process**

1. **Check if enabled:**
   ```python
   if EMAIL_CONFIG['enable_subjects']:
       # Load subjects
   else:
       # Use default subject
   ```

2. **Determine which files to load:**
   ```python
   configured_files = EMAIL_CONFIG['subject_files']
   if configured_files:
       # Use specific files
   else:
       # Use all files
   ```

3. **Load subjects from files:**
   ```python
   for file in subject_files:
       subjects = load_file_lines(file)
       all_subjects.extend(subjects)
   ```

4. **Create rotation cycle:**
   ```python
   subject_cycle = cycle(all_subjects)
   ```

5. **Rotate with each email:**
   ```python
   for email in emails:
       subject = next(subject_cycle)
   ```

### **Rotation Behavior**

- **Infinite rotation:** After last subject, cycles back to first
- **Sequential:** Subjects used in order from files
- **Per-email:** Each email gets next subject in cycle

**Example with 3 subjects:**
```
Email #1: Subject A
Email #2: Subject B
Email #3: Subject C
Email #4: Subject A (cycles back)
Email #5: Subject B
...
```

---

## 📝 **Subject Line Examples**

### **Sample Subjects from Files:**

```
Urgent: Action Required
Document Ready for Signature
Important Notification
You're Invited
Confirmation Required
Friendly Reminder
Security Alert
Important Update
Exclusive Offer Inside
Request for Information
Urgent: Action Required - Reference #1000
Document Ready for Signature [DOCUMENT]
Re: Important Notification
FW: You're Invited
Confirmation Required | Case #5000
...
```

---

## 🎯 **Best Practices**

### **✅ DO:**

- ✅ Use all 10,000 subjects for maximum variation
- ✅ Enable subject rotation for better deliverability
- ✅ Test subjects before large campaigns
- ✅ Monitor which subjects get better open rates
- ✅ Keep subjects professional and relevant

### **❌ DON'T:**

- ❌ Disable subjects unless specifically needed
- ❌ Use only 1-2 files (limits variation)
- ❌ Forget to check subject status before sending
- ❌ Mix inappropriate subjects with content
- ❌ Use all caps or excessive punctuation

---

## 📊 **Performance Tips**

### **For Maximum Deliverability:**

```python
# Use all 10,000 subjects
enable_subjects()
set_subject_files([])
```

**Why:** Maximum variation prevents spam filters from detecting patterns.

### **For Targeted Campaigns:**

```python
# Use specific category (e.g., urgent subjects)
set_subject_files(['subjects_01.txt'])
```

**Why:** Focused subject lines match campaign tone.

### **For Testing:**

```python
# Disable rotation for A/B testing
disable_subjects()
```

**Why:** Control subject line for comparison.

---

## 🔍 **Troubleshooting**

### **Problem: No Subjects Loading**

**Solutions:**
1. Check `subjects/` folder exists
2. Verify files contain subjects: `wc -l subjects/*.txt`
3. Enable subjects: `enable_subjects()`
4. Check status: `get_subject_status()`

### **Problem: Using Wrong Subjects**

**Solutions:**
1. Check configured files: `EMAIL_CONFIG['subject_files']`
2. Reset to all files: `set_subject_files([])`
3. Verify file names are correct

### **Problem: System Says "Using Default Subject"**

**Solutions:**
1. Enable subjects: `enable_subjects()`
2. Check `enable_subjects` is `True` in config
3. Verify subject files exist

---

## 📚 **Quick Reference**

### **Enable/Disable**

```python
enable_subjects()      # Turn ON rotation
disable_subjects()     # Turn OFF rotation
```

### **Configure Files**

```python
set_subject_files([])                           # Use ALL files (10,000 subjects)
set_subject_files(['subjects_01.txt'])          # Use 1 file (1,000 subjects)
set_subject_files(['subjects_01.txt', 
                   'subjects_02.txt'])          # Use 2 files (2,000 subjects)
```

### **Check Status**

```python
get_subject_status()       # Get configuration info
list_subject_files()       # List all files
count_total_subjects()     # Count total subjects
```

### **Configuration Shortcuts**

```python
# In main.py EMAIL_CONFIG:

# Use all subjects (recommended)
'enable_subjects': True,
'subject_files': [],

# Use specific files
'enable_subjects': True,
'subject_files': ['subjects_01.txt', 'subjects_02.txt'],

# Disable rotation
'enable_subjects': False,
```

---

## 🚀 **Complete Examples**

### **Example 1: Full Campaign with All Subjects**

```python
# Configure in main.py
EMAIL_CONFIG = {
    'enable_subjects': True,
    'subject_files': [],
}

# Run campaign
python main.py
# Output: 📝 Loaded 10000 subject lines from 10 files
```

### **Example 2: Testing with Limited Subjects**

```python
# Use only 1,000 subjects for testing
set_subject_files(['subjects_01.txt'])

# Run test campaign
python main.py
# Output: 📝 Loaded 1000 subject lines from 1 files
```

### **Example 3: Check Configuration**

```python
# Check what's configured
status = get_subject_status()
print(f"Enabled: {status['subjects_enabled']}")
print(f"Files: {status['subject_files']}")
print(f"Total: {status['total_files']}")

# List all files
files = list_subject_files()
for f in files:
    print(f"{f['filename']}: {f['line_count']} lines")

# Count total
total = count_total_subjects()
print(f"Total subjects available: {total}")
```

---

## 📋 **Summary**

**Subject Management System:**

✅ **10,000 unique subject lines** across 10 files  
✅ **Enable/disable rotation** with simple functions  
✅ **Select specific files** or use all  
✅ **Infinite rotation** cycles through subjects  
✅ **Status checking** functions included  
✅ **Production-ready** and fully tested  

**Default Behavior:**
- Rotation: **ON**
- Files: **All 10 files**
- Subjects: **10,000 total**

**Functions Available:**
- `enable_subjects()`
- `disable_subjects()`
- `get_subject_status()`
- `set_subject_files(file_list)`
- `list_subject_files()`
- `count_total_subjects()`

---

**Your 10,000-subject management system is ready!** 🎉
