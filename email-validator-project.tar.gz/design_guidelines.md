# Email Validator API - Design Guidelines

## Design Approach

**System**: shadcn/ui (Radix UI primitives with Tailwind CSS)
**Rationale**: Utility-focused validation tool requiring efficient data display, clear status indicators, and professional presentation. Purple/violet color scheme establishes tech-focused credibility while maintaining corporate appeal.

**Core Principles**:
1. **Data Clarity**: Validation results and statistics dominate visual hierarchy
2. **Dual-Mode Excellence**: Equally polished light and dark themes
3. **Instant Recognition**: Provider badges and status indicators immediately scannable
4. **Zero Friction**: Streamlined validation workflows with minimal clicks

## Color System

**Light Mode**:
- Primary: Violet-600 (#7C3AED)
- Primary Hover: Violet-700 (#6D28D9)
- Background: Slate-50 (#F8FAFC)
- Card Background: White
- Text: Slate-900 (headings), Slate-700 (body)
- Borders: Slate-200
- Muted Text: Slate-500

**Dark Mode**:
- Primary: Violet-500 (#8B5CF6)
- Primary Hover: Violet-400 (#A78BFA)
- Background: Slate-950 (#020617)
- Card Background: Slate-900 (#0F172A)
- Text: Slate-50 (headings), Slate-200 (body)
- Borders: Slate-800
- Muted Text: Slate-400

**Provider Badge Colors** (consistent across modes):
- Microsoft: Blue-500/400
- Google: Red-500/400
- Office365: Orange-500/400
- Mimecast: Purple-500/400
- ARSMTP: Emerald-500/400
- GoDaddy: Yellow-500/400

**Status Indicators**:
- Deliverable: Emerald-500 with check icon
- Undeliverable: Red-500 with X icon
- Processing: Amber-500 with clock icon

## Typography

**Fonts**:
- Primary: Inter via Google Fonts
- Monospace: JetBrains Mono for email addresses

**Scale**:
- Hero Headers: text-4xl font-bold tracking-tight
- Page Headers: text-3xl font-bold
- Section Headers: text-xl font-semibold
- Body: text-base
- Email Addresses: text-sm font-mono
- Metadata: text-xs text-muted-foreground

## Layout System

**Spacing**: Tailwind units of 4, 6, 8, 12, 16, 24
- Container max-width: max-w-7xl mx-auto px-4
- Section spacing: space-y-8 or space-y-12
- Card padding: p-6 lg:p-8
- Component gaps: gap-4 or gap-6

**Responsive Grid**:
- Stats Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Dashboard: Single column mobile, 2-column desktop (sidebar optional)

## Component Specifications

### Navigation
**Header**: Fixed top bar with logo (left), navigation links (center), credit balance + user menu + theme toggle (right). Background: violet-600 (light) / violet-950 (dark). Height: h-16. Use backdrop-blur-lg for glassmorphic effect.

### Dashboard Hero Section
**Validation Interface**: Centered card (max-w-3xl) with tabbed interface. Tabs: "Single Email" | "Bulk Upload". Card has shadow-xl and border. Purple gradient background behind card section (violet-50 to violet-100 in light, subtle violet-950 gradient in dark).

**Single Email Tab**: Large input (h-14) with "Validate" button (violet primary). Show format validation inline with small check/x icons.

**Bulk Upload Tab**: Drag-and-drop zone with dashed border-2 border-violet-300 (light) / border-violet-700 (dark). Upload cloud icon (size-12), heading "Drop CSV here", subtext "Max 10,000 emails". Hover state: background violet-50/50 (light) or violet-900/20 (dark).

### Statistics Cards
**Layout**: 4-column grid on desktop, stacked mobile. Each card: white/slate-900 background, p-6, rounded-lg, shadow-md.

**Content Structure**:
- Icon (top-left, violet-500, size-8)
- Value (text-3xl font-bold)
- Label (text-sm text-muted-foreground)
- Trend indicator (optional: small arrow + percentage)

**Card Types**: Total Validated, Deliverable Rate, Microsoft Count, Google Count, Processing Queue

### Results Table
**Container**: Full-width card with shadow-lg, max height with scroll.

**Columns**: Email (text-sm font-mono) | Provider (badge) | Status (icon + text) | MX Records (text-xs) | Actions (export icon button)

**Row States**: Hover background (violet-50 in light, violet-900/20 in dark), alternating row background for readability.

**Header**: Sticky top-0, background matches card, font-semibold, sortable columns with arrow icons.

### Provider Badges
**Style**: Inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium. Color-coded backgrounds with white/slate-50 text.

### Export Action Bar
**Position**: Sticky bottom-4 when results present, centered, shadow-2xl.

**Layout**: Flex-wrap row with gap-2. Buttons: "Export All" (primary violet), individual provider buttons (secondary with provider colors), "Clear Results" (ghost).

### Analytics Page
**KPI Section**: 3-column grid - API Health (uptime badge), Rate Limit (progress bar showing X/60), Avg Response Time (ms with chart icon).

**Charts Section**: Line chart for validation trends (purple gradient fill), bar chart for provider distribution. Use recharts library. Charts have violet-500 accent colors.

**API Status**: Large badge at top-right of page. Green pulse animation for "Operational".

### Theme Toggle
**Component**: Sun/Moon icon button in header. Smooth transition (transition-colors duration-200) between modes. Active state shows which theme is current.

## Accessibility
- All inputs have visible labels with for attributes
- Provider badges include text labels, not color-only
- Focus-visible rings use violet-500 with offset
- Keyboard navigation for all tables and forms
- ARIA labels on icon-only buttons
- Color contrast ratios meet WCAG AA (4.5:1 minimum)

## Animations
**Purposeful Only**:
- Table rows: fade-in when new validation completes (duration-300)
- Upload zone: scale-105 on dragover
- Stats cards: count-up animation on mount
- Toast notifications: slide-in-right (duration-200)
- Theme toggle: smooth color transitions (duration-200)

## Images
**No hero images required** - utility application prioritizes function. Use Lucide React icons exclusively: Upload Cloud, CheckCircle2, XCircle, Clock, TrendingUp, Database, Zap, Globe.

## Login Page
Centered card (max-w-md), violet gradient background (full viewport), glassmorphic card with backdrop-blur. Email/password inputs, "Sign In" button (violet primary), "Create Account" link below.

This design creates a modern, trustworthy email validation platform with exceptional clarity in both light and dark modes, purple accent establishing tech credibility while maintaining professional utility focus.