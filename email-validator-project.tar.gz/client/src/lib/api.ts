// API utilities for Express backend
// Always use same origin since Vite and Express run on the same port
const getApiBaseUrl = () => {
  // Allow override via environment variable if needed
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }
  
  // Use same origin (Vite and Express both on port 5000)
  return '';
};

const API_BASE_URL = getApiBaseUrl();

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown,
  options?: RequestInit
): Promise<Response> {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  
  const headers: HeadersInit = {
    ...(data && !(data instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
    ...(options?.headers || {})
  };
  
  const res = await fetch(fullUrl, {
    method,
    headers,
    credentials: 'include',
    body: data instanceof FormData ? data : (data ? JSON.stringify(data) : undefined),
    ...options
  });
  
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }
  
  return res;
}

export async function fetchAPI<T>(url: string): Promise<T> {
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const res = await fetch(fullUrl, {
    credentials: 'include'
  });
  
  if (!res.ok) {
    throw new Error(`${res.status}: ${res.statusText}`);
  }
  
  return await res.json();
}
