# Template Rotation Feature Guide

## Overview
The Email Marketing Platform now includes a **Template Rotation Control** that allows you to choose whether to rotate through different email templates or use a single template for all recipients.

## How It Works

### Template Rotation ON (1)
When template rotation is **enabled**:
- The system loads **ALL 11 available templates** from the templates directory
- Each email sent uses a **different template** in rotation
- Templates cycle automatically: Email 1 → Template 1, Email 2 → Template 2, ..., Email 12 → Template 1 (starts over)
- This helps **reduce spam detection** by varying email appearance

**Available Templates (11 total):**
1. default.html - Basic default template
2. template1-professional.html - Clean business communication
3. template2-modern.html - Contemporary gradient design
4. template3-minimal.html - Simple, focused layout
5. template4-corporate.html - Formal executive style
6. template5-newsletter.html - Friendly newsletter format
7. template6-promotional.html - Eye-catching promotional design
8. template7-elegant.html - Sophisticated gold-accent style
9. template8-tech.html - Technical/developer themed
10. template9-friendly.html - Casual, approachable tone
11. template10-announcement.html - Official announcement format

### Template Rotation OFF (0)
When template rotation is **disabled**:
- The system loads **only the template you selected** in the campaign
- **All emails** use the same template design
- Provides consistency across your entire campaign

## Using the Feature

### In the Web Interface

1. Go to the **Campaigns** page
2. Click **"New Campaign"** button
3. Fill in campaign details (name, from name, contact list, subjects, etc.)
4. Select your preferred template from the dropdown
5. **Choose Template Rotation setting:**
   - Select **"On (Rotate templates)"** to use all 11 templates in rotation
   - Select **"Off (Use first template only)"** to use only your selected template
6. Configure other settings (delay, SMTP settings if needed)
7. Click **"Create Campaign"**
8. Send your campaign!

### In the Code (backend/app.py)

The template rotation logic works as follows:

```python
# Check template rotation setting (1 = on, 0 = off)
template_rotation = campaign.get('template_rotation', 1)

# Load templates based on rotation setting
if template_rotation == 1:
    # When rotation is ON: Load ALL available templates
    for template_file in os.listdir(TEMPLATES_DIR):
        if template_file.endswith('.html'):
            templates.append(template_file)
else:
    # When rotation is OFF: Load only the selected template
    template_file = campaign.get('template')
    templates = [template_file]

# During sending loop
for recipient in recipients:
    if template_rotation == 1:
        template_content = get_next_rotated(templates, 'template')  # Rotate
    else:
        template_content = templates[0]  # Use first template only
```

## Backend Logs

When sending, you'll see logs indicating which mode is active:

```
Template rotation ON: Loaded 11 templates
```
or
```
Template rotation OFF: Using 1 template(s)
```

## Testing the Feature

### Test 1: Rotation ON
1. Create a campaign with template rotation set to **ON (1)**
2. Use a contact list with at least 12 contacts
3. Send the campaign
4. Check your email inbox - you should see 11 different template designs cycling through

### Test 2: Rotation OFF
1. Create a campaign with template rotation set to **OFF (0)**
2. Select your favorite template
3. Send the campaign
4. All emails should use the same template design

## Benefits

### Rotation ON:
- ✅ Reduces spam detection by varying email appearance
- ✅ Better deliverability through content diversity
- ✅ Professional variety in campaign emails
- ✅ Automatic cycling through 11 professionally-designed templates

### Rotation OFF:
- ✅ Consistent branding across all emails
- ✅ Better for campaigns requiring uniform appearance
- ✅ Complete control over which template is used
- ✅ Ideal for corporate communications

## Campaign Configuration Fields

When creating a campaign, the following fields are available:

```json
{
  "name": "My Campaign",
  "from_name": "Marketing Team",
  "contact_list": "emails.txt",
  "subject_file": "subjects.txt",
  "from_email_file": "fromemails.txt",
  "template": "template1-professional.html",
  "template_rotation": 1,  // 1 = ON, 0 = OFF
  "delay": 1,
  "smtp_settings": {...}
}
```

## Technical Details

- **Default Setting**: Template rotation defaults to **ON (1)** for new campaigns
- **Storage**: Campaign configuration is saved in `campaigns/` directory as JSON files
- **Rotation Method**: Uses Python's `itertools.cycle()` for seamless rotation
- **Iterator Reset**: Template iterator resets for each new campaign

## Troubleshooting

**Q: I set rotation to ON but all emails look the same**
A: Make sure you have multiple templates in the `templates/` directory and they have different designs.

**Q: How do I know which template was sent to which recipient?**
A: Check the backend logs which show the rotation sequence during sending.

**Q: Can I add my own templates?**
A: Yes! Add any `.html` file to the `templates/` directory and it will be included in rotation when ON.

**Q: Does the selected template matter when rotation is ON?**
A: When rotation is ON, the system loads ALL templates, so your selection in the dropdown is only used when rotation is OFF.

## Version Info

- Feature added: November 17, 2025
- Backend implementation: `backend/app.py`
- Frontend UI: `frontend/src/pages/Campaigns.jsx`
- Templates directory: `templates/`
- Available templates: 11
