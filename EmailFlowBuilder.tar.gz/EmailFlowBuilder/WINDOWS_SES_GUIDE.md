# 📧 AWS SES Template Email Sender - Windows Guide

Complete instructions for sending AWS SES templated emails using Python on Windows.

---

## ✅ **Prerequisites**

1. **Python 3.9+** installed on Windows
2. **AWS SES credentials** (SMTP username and password)
3. **Verified sender domain** in AWS SES (e.g., qupio.jp)

---

## 🔧 **Step 1: Install Python Dependencies**

Open **Command Prompt** or **PowerShell** and run:

```cmd
pip install boto3 python-dotenv
```

---

## 📝 **Step 2: Create Standalone Script**

Create a file called `send_ses_emails_windows.py`:

```python
#!/usr/bin/env python3
"""
AWS SES Templated Email Sender - Windows Standalone
Sends emails using AWS SES templates with random data generation
"""

import boto3
import random
from datetime import datetime, timedelta
from botocore.exceptions import ClientError

# ============================================================
# AWS CREDENTIALS - HARDCODED (WINDOWS STANDALONE)
# ============================================================
# ⚠️ SECURITY WARNING: Only use hardcoded credentials for 
# standalone local scripts. NEVER commit to Git/GitHub!
# ============================================================

AWS_REGION = 'eu-central-1'
AWS_ACCESS_KEY_ID = 'AKIARXLUFZJIBSGKIHVW'
AWS_SECRET_ACCESS_KEY = 'BJofG6gs++zXcpDRLCjxn3XqpYz5sBWVuBqM/bo1Y75L'

# SMTP Settings for SES
SES_SMTP_HOST = 'email-smtp.eu-central-1.amazonaws.com'
SES_SMTP_PORT = 587
SES_SMTP_USERNAME = 'AKIARXLUFZJIBSGKIHVW'
SES_SMTP_PASSWORD = 'BJofG6gs++zXcpDRLCjxn3XqpYz5sBWVuBqM/bo1Y75L'

# Verified sender email
FROM_EMAIL = 'hunter@qupio.jp'
FROM_NAME = 'Customer Support'

# ============================================================
# RANDOM DATA GENERATORS
# ============================================================

FIRST_NAMES = ['James', 'John', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Joseph']
LAST_NAMES = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis']

def generate_random_data():
    """Generate random data for email personalization"""
    firstname = random.choice(FIRST_NAMES)
    lastname = random.choice(LAST_NAMES)
    return {
        'firstname': firstname,
        'lastname': lastname,
        'fullname': f"{firstname} {lastname}",
        'email': f"{firstname.lower()}.{lastname.lower()}@gmail.com",
        'id': str(random.randint(10000, 99999)),
        'randomnumber': str(random.randint(1000, 99999)),
        'phone': f"({random.randint(200, 999)}) {random.randint(100, 999)}-{random.randint(1000, 9999)}",
        'date': (datetime.now() + timedelta(days=random.randint(1, 30))).strftime('%m/%d/%Y')
    }

# ============================================================
# AWS SES FUNCTIONS
# ============================================================

def fetch_ses_templates():
    """Fetch all AWS SES templates"""
    try:
        ses_client = boto3.client(
            'ses',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )
        
        response = ses_client.list_templates()
        template_names = [t['Name'] for t in response.get('TemplatesMetadata', [])]
        return template_names
    except ClientError as e:
        print(f"❌ Error fetching templates: {e}")
        return []

def get_ses_template(template_name):
    """Get specific AWS SES template"""
    try:
        ses_client = boto3.client(
            'ses',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )
        
        response = ses_client.get_template(TemplateName=template_name)
        template = response.get('Template', {})
        
        return {
            'name': template.get('TemplateName'),
            'subject': template.get('SubjectPart', ''),
            'html': template.get('HtmlPart', ''),
            'text': template.get('TextPart', '')
        }
    except ClientError as e:
        print(f"❌ Error getting template: {e}")
        return None

def send_templated_email_ses(to_email, template_name):
    """Send email using AWS SES template"""
    try:
        ses_client = boto3.client(
            'ses',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )
        
        # Generate random data
        template_data = generate_random_data()
        
        # Send templated email
        response = ses_client.send_templated_email(
            Source=f'{FROM_NAME} <{FROM_EMAIL}>',
            Destination={'ToAddresses': [to_email]},
            Template=template_name,
            TemplateData=str(template_data).replace("'", '"')  # Convert dict to JSON string
        )
        
        return True
    except ClientError as e:
        print(f"❌ Error sending email: {e}")
        return False

# ============================================================
# MAIN FUNCTION
# ============================================================

def main():
    """Main execution function"""
    print("=" * 70)
    print("   AWS SES TEMPLATED EMAIL SENDER - WINDOWS")
    print("=" * 70)
    print()
    
    # Get recipient email
    recipient = input("📧 Enter recipient email: ").strip()
    if not recipient:
        print("❌ No recipient provided!")
        return
    
    print()
    
    # Fetch templates
    print("🎨 Fetching AWS SES templates...")
    templates = fetch_ses_templates()
    
    if not templates:
        print("❌ No templates found!")
        return
    
    print(f"✅ Found {len(templates)} template(s):")
    for i, t in enumerate(templates, 1):
        print(f"   {i}. {t}")
    print()
    
    # Ask which templates to send
    choice = input("Send ALL templates or specific one? (all/number): ").strip().lower()
    
    if choice == 'all':
        # Send all templates
        print(f"\n📤 Sending ALL {len(templates)} templates to {recipient}...")
        print("-" * 70)
        
        success_count = 0
        for idx, template_name in enumerate(templates, 1):
            print(f"{idx}/{len(templates)} | {template_name}")
            
            if send_templated_email_ses(recipient, template_name):
                print(f"        ✅ Sent successfully")
                success_count += 1
            else:
                print(f"        ❌ Failed")
            print()
        
        print("-" * 70)
        print(f"✅ Successfully sent: {success_count}/{len(templates)} templates")
    
    else:
        # Send specific template
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(templates):
                template_name = templates[idx]
                print(f"\n📤 Sending '{template_name}' to {recipient}...")
                
                if send_templated_email_ses(recipient, template_name):
                    print("✅ Email sent successfully!")
                else:
                    print("❌ Failed to send email")
            else:
                print("❌ Invalid template number")
        except ValueError:
            print("❌ Invalid input")

if __name__ == "__main__":
    main()
```

---

## 🚀 **Step 3: Run the Script**

Open **Command Prompt** in the folder where you saved the script:

```cmd
python send_ses_emails_windows.py
```

---

## 📋 **Step 4: Usage Examples**

### **Example 1: Send All Templates**

```
$ python send_ses_emails_windows.py

======================================================================
   AWS SES TEMPLATED EMAIL SENDER - WINDOWS
======================================================================

📧 Enter recipient email: tom@fslico.com

🎨 Fetching AWS SES templates...
✅ Found 10 template(s):
   1. appointment-reminder
   2. download-ready
   3. survey-feedback
   4. event-invitation
   5. subscription-renewal
   6. password-reset-request
   7. shipping-notification
   8. special-offer-limited
   9. payment-confirmation
   10. urgent-account-alert

Send ALL templates or specific one? (all/number): all

📤 Sending ALL 10 templates to tom@fslico.com...
----------------------------------------------------------------------
1/10 | appointment-reminder
        ✅ Sent successfully

2/10 | download-ready
        ✅ Sent successfully

... (continues for all 10)
----------------------------------------------------------------------
✅ Successfully sent: 10/10 templates
```

### **Example 2: Send Specific Template**

```
Send ALL templates or specific one? (all/number): 3

📤 Sending 'survey-feedback' to tom@fslico.com...
✅ Email sent successfully!
```

---

## 🔐 **Security Options**

### **Option A: Hardcoded (Standalone Only)**

The script above has credentials **hardcoded** for standalone Windows use.

⚠️ **WARNING:**
- Use ONLY on your local computer
- NEVER commit to Git/GitHub
- NEVER share the script file

### **Option B: Environment Variables (Recommended)**

For better security, use environment variables:

**Set in Windows Command Prompt:**
```cmd
set AWS_ACCESS_KEY_ID=AKIARXLUFZJIBSGKIHVW
set AWS_SECRET_ACCESS_KEY=BJofG6gs++zXcpDRLCjxn3XqpYz5sBWVuBqM/bo1Y75L
```

**Then modify script to use:**
```python
import os

AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
```

---

## ✅ **What You Get**

Each sent email will have:
- ✅ Random personalized data (names, IDs, dates, phone numbers)
- ✅ Professional HTML formatting from AWS SES templates
- ✅ Clickable links and buttons
- ✅ Plain text fallback
- ✅ High-priority headers

---

## 🎯 **Quick Command Reference**

```cmd
# Install dependencies
pip install boto3 python-dotenv

# Run script
python send_ses_emails_windows.py

# Send to specific email
# (script will prompt for recipient)
```

---

## ⚠️ **Important Notes**

1. **AWS SES Sandbox:** If your account is in sandbox mode, you can only send to verified email addresses
2. **Verified Domain:** Make sure `qupio.jp` is verified in AWS SES Console
3. **Templates:** Templates must exist in AWS SES Console (eu-central-1 region)
4. **Rate Limits:** AWS SES has sending rate limits based on your account

---

**Script ready to use on Windows!** 🎉
