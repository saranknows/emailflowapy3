# HTML to Image Conversion Guide

## Overview

The email marketing platform now includes **HTML to image conversion** functionality. This feature converts your email templates into high-quality PNG images while preserving all clickable links through an innovative link overlay system.

## Why Use HTML to Image?

### Benefits

1. **Consistent Rendering** - Emails look identical across all email clients
2. **Design Protection** - Your beautiful templates can't be broken by email clients
3. **Bypass Text Blocking** - Text-heavy content rendered as images
4. **Professional Appearance** - Pixel-perfect emails every time
5. **Link Preservation** - All links remain clickable below the image

### Use Cases

- Marketing campaigns requiring exact visual consistency
- Emails with complex CSS that might break in some clients
- Image-based newsletters and announcements
- Promotional emails with precise branding requirements

## Available Functions

### 1. enable_html_to_image()
Enable HTML to image conversion for all emails

```python
enable_html_to_image()
```

**Output:**
```
✅ HTML to image conversion enabled
```

---

### 2. disable_html_to_image()
Disable HTML to image conversion

```python
disable_html_to_image()
```

**Output:**
```
✅ HTML to image conversion disabled
```

---

### 3. get_html_to_image_status()
Get current conversion status and settings

```python
status = get_html_to_image_status()
print(status)
# {
#     'conversion_enabled': True/False,
#     'image_width': 600,
#     'image_quality': 95,
#     'mode': 'Conversion: ON (Width: 600px, Quality: 95%)'
# }
```

---

### 4. convert_html_to_image(html_content, output_filename, width, quality)
Convert HTML string to PNG image

```python
image_path = convert_html_to_image(
    html_content='<html>...</html>',
    output_filename='email.png',
    width=600,
    quality=95
)
```

**Returns:** Path to generated image or None if failed

---

### 5. extract_links_from_html(html_content)
Extract all links from HTML template

```python
links = extract_links_from_html(html_content)
# Returns: [{'url': 'https://...', 'text': 'Link Text'}, ...]
```

---

### 6. create_clickable_image_email(image_path, links, image_width)
Create HTML email with image and clickable links

```python
final_html = create_clickable_image_email(
    image_path='html_images/email.png',
    links=[{'url': 'https://...', 'text': 'Click Here'}],
    image_width=600
)
```

**Returns:** Complete HTML email with embedded image and clickable links

---

## Configuration

### In EMAIL_CONFIG

```python
EMAIL_CONFIG = {
    ...
    # HTML to Image Conversion (Optional)
    'convert_to_image': False,  # Set to True to enable conversion
    'image_width': 600,         # Width in pixels (default: 600)
    'image_quality': 95,        # Quality 1-100 (default: 95)
    ...
}
```

### Configuration Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `convert_to_image` | Boolean | False | Enable/disable conversion |
| `image_width` | Integer | 600 | Image width in pixels |
| `image_quality` | Integer | 95 | Image quality (1-100, higher = better) |

---

## How It Works

### Process Flow

1. **Template Loading** - HTML template is loaded normally
2. **Content Insertion** - Placeholders replaced with actual content
3. **QR Code Embedding** - QR codes added if enabled (before conversion)
4. **HTML → Image** - Template converted to PNG image
5. **Link Extraction** - All `<a>` tags extracted from original HTML
6. **Email Assembly** - New HTML created with:
   - Base64-encoded image (embedded inline)
   - Clickable links section below image
   - Mobile-responsive layout
7. **Sending** - Final HTML email sent to recipients

### Visual Result

```
┌─────────────────────────────────────┐
│                                     │
│        [EMAIL AS PNG IMAGE]         │
│                                     │
│   (All visual content rendered      │
│    as a single high-quality         │
│    image - buttons, text,           │
│    colors, layout preserved)        │
│                                     │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│  Quick Links:                       │
│  • [Link 1] Learn More              │
│  • [Link 2] Visit Website           │
│  • [Link 3] Unsubscribe             │
│  • [Link 4] Privacy Policy          │
└─────────────────────────────────────┘
```

---

## Usage Examples

### Example 1: Enable Conversion

```python
# Enable HTML to image conversion
enable_html_to_image()

# Run main.py
# Output will show:
# 🖼️  HTML to image: ON (Width: 600px, Quality: 95%)
```

**Result:** All emails sent as images with clickable links

---

### Example 2: Configure Custom Settings

```python
# Set custom width and quality
EMAIL_CONFIG['convert_to_image'] = True
EMAIL_CONFIG['image_width'] = 800  # Wider images
EMAIL_CONFIG['image_quality'] = 100  # Maximum quality

# Check status
status = get_html_to_image_status()
print(status['mode'])
# Output: Conversion: ON (Width: 800px, Quality: 100%)
```

---

### Example 3: Manual Conversion

```python
from main import convert_html_to_image, extract_links_from_html, create_clickable_image_email

# Your HTML template
html = '''
<!DOCTYPE html>
<html>
<body>
    <h1>Special Offer!</h1>
    <a href="https://example.com/offer">Claim Now</a>
</body>
</html>
'''

# Convert to image
image_path = convert_html_to_image(html, 'my_email.png', 600, 95)

# Extract links
links = extract_links_from_html(html)

# Create final email
final_email = create_clickable_image_email(image_path, links, 600)

# Send it
send_email(smtp_server, from_email, to_email, subject, final_email)
```

---

## Integration with Other Features

### Works with QR Codes

```python
EMAIL_CONFIG = {
    'convert_to_image': True,     # Convert to image
    'enable_qr_code': True,        # Embed QR code
    'qr_code_data': 'https://example.com/mobile'
}

# QR code will be embedded in HTML BEFORE conversion
# Result: Image includes the QR code!
```

---

### Works with Template Rotation

```python
EMAIL_CONFIG = {
    'template_rotation': True,     # Rotate templates
    'convert_to_image': True       # Convert all to images
}

# Each email gets:
# - Different template (rotated)
# - Converted to image
# - Clickable links below
```

---

### Works with Link Placeholders

```python
# Links in templates are preserved
template_html = '''
<a href="{{link}}">Main CTA</a>
<a href="{{unsubscribe}}">Unsubscribe</a>
'''

# After replacement:
html = template_html.replace('{{link}}', 'https://example.com/offer')
html = html.replace('{{unsubscribe}}', 'https://example.com/unsub')

# Convert to image
# Links will be extracted and displayed below image
```

---

## Console Output

### When Enabled

```
============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 1 files
👤 Loaded 2 sender emails
🎨 Template rotation: ON - Using all 11 templates
🖼️  HTML to image: ON (Width: 600px, Quality: 95%)

Press ENTER to start sending to 8 contacts...
```

### During Sending

```
📤 Starting to send emails...
------------------------------------------------------------
1/8 | To: user@example.com... | From: info@company.com...
         Subject: Special Summer Sale...
         Template: template1-professional.html
         🖼️  Converted to image: email_1_template1-professional.png
         ✅ Sent successfully
```

---

## Output Files

Generated images are stored in:

```
html_images/
├── email_1_template1-professional.png
├── email_2_template2-modern.png
├── email_3_template3-minimal.png
└── ...
```

**File naming:** `email_{number}_{template_name}.png`

---

## Best Practices

### 1. Choose Appropriate Width

```python
# Mobile-friendly
EMAIL_CONFIG['image_width'] = 600  # Default, works well

# Desktop-optimized
EMAIL_CONFIG['image_width'] = 800

# Small/compact
EMAIL_CONFIG['image_width'] = 500
```

### 2. Balance Quality vs File Size

```python
# High quality (larger file)
EMAIL_CONFIG['image_quality'] = 100

# Balanced (recommended)
EMAIL_CONFIG['image_quality'] = 95

# Smaller file size
EMAIL_CONFIG['image_quality'] = 85
```

### 3. Test Link Accessibility

```python
# Make sure ALL important links are in the template
# They will be extracted and displayed below the image
# Users can't click on the image itself, only the links below
```

### 4. Consider Email Client Compatibility

```python
# Images work in ALL email clients
# No CSS rendering issues
# But note: image blocking in some clients means user sees nothing
# Consider: Add alt text and fallback
```

### 5. Keep Templates Link-Rich

```python
# Good: Multiple clear links
<a href="{{link}}">Main CTA</a>
<a href="{{website}}">Visit Website</a>
<a href="{{unsubscribe}}">Unsubscribe</a>

# Less ideal: All content in image with few links
# Users need clickable links below the image!
```

---

## Troubleshooting

### Image Not Generated

**Problem:** Images not created in html_images/ folder

**Solutions:**
1. Check html2image is installed: `pip install html2image`
2. Ensure output directory permissions
3. Check console for error messages
4. Verify HTML is valid

---

### Links Not Appearing

**Problem:** No clickable links below image

**Solutions:**
1. Make sure template has `<a href="...">` tags
2. Ensure links don't use placeholder syntax ({{...}})
3. Replace placeholders with actual URLs before conversion
4. Check extract_links_from_html() output

---

### Poor Image Quality

**Problem:** Blurry or pixelated images

**Solutions:**
```python
# Increase width
EMAIL_CONFIG['image_width'] = 800

# Increase quality
EMAIL_CONFIG['image_quality'] = 100
```

---

### Large File Sizes

**Problem:** Email attachments too large

**Solutions:**
```python
# Reduce width
EMAIL_CONFIG['image_width'] = 500

# Lower quality (carefully)
EMAIL_CONFIG['image_quality'] = 85

# Note: Images are embedded as base64, not attachments
# But file size still matters for email sending
```

---

## Advanced Usage

### Selective Conversion

```python
# Convert only specific templates
def should_convert_template(template_name):
    convert_these = ['template1-professional.html', 'template6-promotional.html']
    return template_name in convert_these

# In your sending loop:
if should_convert_template(template_name):
    enable_html_to_image()
else:
    disable_html_to_image()
```

---

### Custom Link Styling

Edit the `create_clickable_image_email()` function in main.py to customize how links appear:

```python
# Default: Blue buttons with rounded corners
# Customize: Change colors, sizes, layout
```

---

## Technical Details

### Image Format
- **Format:** PNG
- **Encoding:** Base64 (embedded inline)
- **Transparency:** Supported
- **Compression:** Lossless

### Link Extraction
- **Method:** Regex pattern matching
- **Filters:** Skips {{placeholder}} links
- **Preserves:** Link text and URLs
- **Cleans:** Removes HTML tags from link text

### Email Structure
- **Image:** Base64 data URI
- **Links Section:** Styled HTML below image
- **Layout:** Centered, max-width container
- **Mobile:** Responsive design

---

## Summary

**3 Control Functions:**
- ✅ `enable_html_to_image()` - Turn ON conversion
- ✅ `disable_html_to_image()` - Turn OFF conversion
- ✅ `get_html_to_image_status()` - Check current status

**3 Core Functions:**
- ✅ `convert_html_to_image()` - HTML → PNG
- ✅ `extract_links_from_html()` - Get all links
- ✅ `create_clickable_image_email()` - Assemble final email

**Configuration Options:**
- ✅ `convert_to_image`: True/False
- ✅ `image_width`: Pixels (default: 600)
- ✅ `image_quality`: 1-100 (default: 95)

**Integration:**
- ✅ Works with QR codes
- ✅ Works with template rotation
- ✅ Works with all link placeholders
- ✅ Works with attachments
- ✅ Preserves all clickable links

---

**Related Documentation:**
- [TEMPLATE-LINKS-GUIDE.md](TEMPLATE-LINKS-GUIDE.md) - Link placeholders and usage
- [QR-CODE-FEATURE-GUIDE.md](QR-CODE-FEATURE-GUIDE.md) - QR code functionality
- [TEMPLATE-ROTATION-CONTROL-GUIDE.md](TEMPLATE-ROTATION-CONTROL-GUIDE.md) - Template rotation
- [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md) - Complete usage guide
