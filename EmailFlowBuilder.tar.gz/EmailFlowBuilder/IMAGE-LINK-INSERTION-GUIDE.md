# Image Link Insertion Configuration Guide

## Overview
When converting HTML email templates to images, clickable links are lost because images cannot contain interactive elements. This feature automatically extracts all hyperlinks from your original HTML template and inserts them as clickable buttons below the image, preserving full functionality.

---

## 🔧 **Configuration Options**

Located in `EMAIL_CONFIG` in `main.py`:

```python
EMAIL_CONFIG = {
    # ... other settings ...
    
    # HTML to Image Conversion (Optional)
    'convert_to_image': False,  # Set to True to convert HTML template to image
    'image_width': 600,  # Width of generated image in pixels
    'image_quality': 95,  # Image quality (1-100, higher is better)
    'insert_links_below_image': True,  # Insert clickable links below the image
    'link_section_title': 'Important Links:',  # Title for the links section
    'extract_all_links': True,  # Extract all links from template
    
    # ... other settings ...
}
```

---

## ⚙️ **Configuration Settings**

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `convert_to_image` | Boolean | `False` | Enable HTML-to-image conversion |
| `image_width` | Integer | `600` | Width of generated image (pixels) |
| `image_quality` | Integer | `95` | Image quality (1-100) |
| `insert_links_below_image` | Boolean | `True` | Insert clickable links below image |
| `link_section_title` | String | `'Important Links:'` | Title for links section |
| `extract_all_links` | Boolean | `True` | Extract all links from HTML |

---

## 🔄 **Management Functions (4 Total)**

### **1. Enable Links Below Image**

```python
enable_links_below_image()
```

**Purpose:** Turn on link insertion below converted images  
**Returns:** `True`

**Example:**
```python
>>> enable_links_below_image()
✅ Links below image enabled
```

---

### **2. Disable Links Below Image**

```python
disable_links_below_image()
```

**Purpose:** Turn off link insertion (image only, no links)  
**Returns:** `True`

**Example:**
```python
>>> disable_links_below_image()
✅ Links below image disabled
```

---

### **3. Set Link Section Title**

```python
set_link_section_title(title)
```

**Purpose:** Customize the title for the links section  
**Args:** `title` - String title  
**Returns:** `True`

**Example:**
```python
>>> set_link_section_title('Quick Access Links')
✅ Link section title set to: Quick Access Links
```

---

### **4. Get Image Links Status**

```python
get_image_links_status()
```

**Purpose:** Check current link insertion configuration  
**Returns:** Dictionary with status information

**Example:**
```python
>>> status = get_image_links_status()
>>> print(status['mode'])
Convert: OFF | Links: ON

>>> print(status)
{
    'convert_to_image': False,
    'insert_links': True,
    'link_title': 'Important Links:',
    'extract_all_links': True,
    'mode': 'Convert: OFF | Links: ON'
}
```

---

## 📋 **How It Works**

### **Step 1: HTML Template (Original)**

```html
<html>
<body>
  <h1>Sign the Document</h1>
  <p>Please review and sign:</p>
  <a href="https://example.com/document">View Document</a>
  <a href="https://example.com/sign">Sign Now</a>
  <a href="https://example.com/help">Get Help</a>
</body>
</html>
```

### **Step 2: Conversion to Image**

The HTML is converted to a PNG image using `html2image`. All visual content is preserved, but links become non-clickable.

### **Step 3: Link Extraction**

The system automatically extracts all hyperlinks:
- `https://example.com/document` → "View Document"
- `https://example.com/sign` → "Sign Now"
- `https://example.com/help` → "Get Help"

### **Step 4: Links Inserted Below Image**

```html
<div>
  <img src="data:image/png;base64,..." alt="Email Content">
</div>

<!-- Automatically generated links section -->
<div style="margin-top: 20px; padding: 20px; background-color: #f8f9fa;">
  <h3>Important Links:</h3>
  <table>
    <tr><td>
      <a href="https://example.com/document">➤ View Document</a>
    </td></tr>
    <tr><td>
      <a href="https://example.com/sign">➤ Sign Now</a>
    </td></tr>
    <tr><td>
      <a href="https://example.com/help">➤ Get Help</a>
    </td></tr>
  </table>
</div>
```

---

## 💡 **Usage Examples**

### **Example 1: Enable Image Conversion with Links**

```python
from main import enable_html_to_image, enable_links_below_image

# Enable HTML-to-image conversion
enable_html_to_image()

# Enable link insertion (default is already ON)
enable_links_below_image()

# Run campaign - images will have clickable links below
```

**Result:**
- ✅ HTML templates converted to images
- ✅ All links extracted and displayed below image
- ✅ Links fully clickable in email client

---

### **Example 2: Customize Link Section Title**

```python
from main import set_link_section_title, enable_html_to_image

# Set custom title
set_link_section_title('Quick Access')

# Enable conversion
enable_html_to_image()

# Run campaign
```

**Result:**
- Links section shows "Quick Access" instead of "Important Links:"

---

### **Example 3: Image Only (No Links)**

```python
from main import enable_html_to_image, disable_links_below_image

# Enable conversion
enable_html_to_image()

# Disable link insertion
disable_links_below_image()

# Run campaign
```

**Result:**
- ✅ HTML templates converted to images
- ❌ No links section (image only)
- Use this when links are not important or embedded elsewhere

---

### **Example 4: Check Configuration**

```python
from main import get_image_links_status

# Get current configuration
status = get_image_links_status()

print(f"Conversion: {status['convert_to_image']}")
print(f"Links enabled: {status['insert_links']}")
print(f"Link title: {status['link_title']}")
```

---

## 🎨 **Link Section Styling**

The generated links section is styled for maximum compatibility with email clients:

### **Features:**
- ✅ Professional blue and white color scheme
- ✅ Responsive design (mobile-friendly)
- ✅ Table-based layout (email client compatible)
- ✅ Rounded corners and subtle shadows
- ✅ Button-style links for better visibility
- ✅ Clear visual hierarchy

### **Visual Design:**
```
┌─────────────────────────────────────┐
│  Image converted from HTML          │
│  (600px wide, auto height)          │
└─────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────┐
│ Important Links:                    │
│ ┌─────────────────────────────────┐│
│ │ ➤ View Document                 ││
│ └─────────────────────────────────┘│
│ ┌─────────────────────────────────┐│
│ │ ➤ Sign Now                      ││
│ └─────────────────────────────────┘│
│ ┌─────────────────────────────────┐│
│ │ ➤ Get Help                      ││
│ └─────────────────────────────────┘│
└─────────────────────────────────────┘
```

---

## 🔍 **Link Extraction Details**

### **What Gets Extracted:**
✅ Valid HTTP/HTTPS URLs  
✅ Link text (cleaned of HTML tags)  
✅ All `<a href="...">` tags in template

### **What Gets Skipped:**
❌ Placeholder links (e.g., `{{link}}`, `{{website}}`)  
❌ Relative URLs without protocol  
❌ JavaScript links (`javascript:void(0)`)  
❌ Mailto links (optional)

### **Example Link Extraction:**

**Input HTML:**
```html
<a href="https://example.com/page1">Page One</a>
<a href="https://example.com/page2"><b>Bold Link</b></a>
<a href="{{link}}">Placeholder</a>
<a href="/relative">Relative</a>
```

**Extracted Links:**
1. `https://example.com/page1` → "Page One"
2. `https://example.com/page2` → "Bold Link" (tags removed)

**Skipped:**
- `{{link}}` (placeholder)
- `/relative` (not absolute URL)

---

## 📊 **Use Cases**

### **Use Case 1: DocuSign-Style Emails**

```python
# Original HTML has "Sign Document" button
# Convert to image to prevent email client tampering
enable_html_to_image()
enable_links_below_image()
set_link_section_title('Action Required')

# Result: Professional document image + clickable "Sign" link below
```

### **Use Case 2: Newsletter with Multiple Links**

```python
# Newsletter template with 5-10 article links
enable_html_to_image()
enable_links_below_image()
set_link_section_title('Read More Articles:')

# Result: Beautiful newsletter image + all article links accessible
```

### **Use Case 3: Simple Announcement (No Links)**

```python
# Announcement with no calls to action
enable_html_to_image()
disable_links_below_image()

# Result: Clean image-only email
```

### **Use Case 4: Mixed Content**

```python
# Some templates need links, some don't
# Configure per campaign:

# Campaign 1: With links
enable_links_below_image()

# Campaign 2: Without links
disable_links_below_image()
```

---

## ⚡ **Quick Reference**

### **Enable Everything:**
```python
from main import enable_html_to_image, enable_links_below_image

enable_html_to_image()
enable_links_below_image()
```

### **Image Only (No Links):**
```python
from main import enable_html_to_image, disable_links_below_image

enable_html_to_image()
disable_links_below_image()
```

### **Custom Title:**
```python
from main import set_link_section_title

set_link_section_title('Quick Links')
```

### **Check Status:**
```python
from main import get_image_links_status

status = get_image_links_status()
print(status['mode'])
```

---

## 🎯 **Best Practices**

### **1. Always Enable Links for Interactive Emails**
If your template has buttons or important links, always enable `insert_links_below_image`.

### **2. Customize Title for Context**
Use descriptive titles:
- `"Action Required"` for urgent links
- `"Quick Links"` for navigation
- `"Read More"` for content links
- `"Resources"` for documentation links

### **3. Test Link Extraction**
Before sending campaigns, verify all links are extracted correctly:

```python
from main import extract_links_from_html

template_html = load_template('your_template.html')
links = extract_links_from_html(template_html)
for link in links:
    print(f"{link['text']}: {link['url']}")
```

### **4. Mobile Optimization**
The generated links are mobile-friendly by default:
- Large touch targets (48px+ height)
- Clear spacing between links
- Readable font sizes (15px+)

---

## 🔧 **Advanced Configuration**

### **Modify Link Styles**

Edit the `create_links_html_section()` function in `main.py` to customize:

**Colors:**
```python
# Change blue theme to green
style="color: #28a745; ... background-color: #d4edda; border: 1px solid #c3e6cb;"
```

**Layout:**
```python
# Change from vertical list to horizontal buttons
# Modify the <table> structure to display inline
```

**Icons:**
```python
# Change arrow icon
'➤ {link["text"]}'  # Current
'🔗 {link["text"]}'  # Link icon
'→ {link["text"]}'   # Arrow
'• {link["text"]}'   # Bullet
```

---

## ✅ **Summary**

**4 Management Functions:**
1. `enable_links_below_image()` - Turn links ON
2. `disable_links_below_image()` - Turn links OFF
3. `set_link_section_title(title)` - Set custom title
4. `get_image_links_status()` - Check configuration

**3 Configuration Options:**
1. `insert_links_below_image` - Enable/disable feature
2. `link_section_title` - Customize title
3. `extract_all_links` - Link extraction mode

**Key Benefits:**
- ✅ Preserves link functionality when using image emails
- ✅ Professional, email-client compatible styling
- ✅ Automatic extraction (no manual work)
- ✅ Fully customizable titles and styling
- ✅ Mobile-friendly design

---

**Your image conversion now intelligently preserves all clickable links!** 🔗
