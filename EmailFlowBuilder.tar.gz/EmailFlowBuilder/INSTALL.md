# Email Marketing Platform - Installation Guide

Complete installation instructions for Windows, Mac, and Linux.

## Prerequisites

Before installing, make sure you have the following installed:

### Required Software
- **Python 3.9.9** (Required - exact version for compatibility)
- **Node.js 20.x or higher** (for frontend)
- **npm** (comes with Node.js)
- **Git** (optional, for cloning)

## Download & Extract

1. Download the project ZIP file
2. Extract to your desired location (e.g., `C:\email-marketing-platform` on Windows)
3. Open a terminal/command prompt in the extracted folder

## Installation Instructions

### For Windows

#### Step 1: Install Python 3.9.9
1. Download Python 3.9.9 from [python.org](https://www.python.org/downloads/release/python-399/)
2. Run the installer
3. **Important**: Check "Add Python to PATH" during installation
4. Verify installation:
   ```cmd
   python --version
   ```
   Should show: `Python 3.9.9`

#### Step 2: Install Node.js
1. Download Node.js LTS from [nodejs.org](https://nodejs.org/)
2. Run the installer (default settings are fine)
3. Verify installation:
   ```cmd
   node --version
   npm --version
   ```

#### Step 3: Install Python Dependencies
Open Command Prompt in the project folder and run:
```cmd
pip install -r requirements.txt
```

If you get an error, try:
```cmd
python -m pip install -r requirements.txt
```

#### Step 4: Install Node.js Dependencies
In the same Command Prompt:
```cmd
npm install
```

#### Step 5: Create Required Folders
```cmd
mkdir subjects
mkdir from_emails
mkdir contacts
mkdir campaigns
```

These folders already exist in the download, but this ensures they're created if missing.

#### Step 6: Configure Environment Variables (Optional)
Create a `.env` file in the `backend` folder with your email credentials:

```env
# Amazon SES SMTP Configuration (Recommended)
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your_ses_username
SES_SMTP_PASSWORD=your_ses_password

# Resend API (Alternative)
RESEND_API_KEY=your_resend_api_key

# Generic SMTP (Alternative)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

#### Step 7: Run the Application

**Option A: Start Both Servers at Once (Recommended)**
```cmd
start-all.bat
```

**Option B: Start Servers Separately**

Terminal 1 (Backend):
```cmd
start-backend.bat
```

Terminal 2 (Frontend):
```cmd
start-frontend.bat
```

**Option C: Manual Start**

Terminal 1 (Backend):
```cmd
cd backend
python app.py
```

Terminal 2 (Frontend):
```cmd
npm run dev
```

#### Access the Application
- **Frontend**: http://localhost:5000
- **Backend API**: http://localhost:8000

---

### For Mac/Linux

#### Step 1: Install Python 3.9.9
**On Mac (using Homebrew):**
```bash
brew install python@3.9
```

**On Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3.9 python3.9-venv python3-pip
```

Verify:
```bash
python3 --version
```

#### Step 2: Install Node.js
**On Mac (using Homebrew):**
```bash
brew install node
```

**On Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

Verify:
```bash
node --version
npm --version
```

#### Step 3: Install Python Dependencies
```bash
pip3 install -r requirements.txt
```

Or using Python 3.9 specifically:
```bash
python3.9 -m pip install -r requirements.txt
```

#### Step 4: Install Node.js Dependencies
```bash
npm install
```

#### Step 5: Create Required Folders
```bash
mkdir -p subjects from_emails contacts campaigns
```

#### Step 6: Configure Environment Variables (Optional)
Create a `.env` file in the `backend` folder (see Windows Step 6 above for content)

#### Step 7: Make Scripts Executable
```bash
chmod +x start-backend.sh
chmod +x start-frontend.sh
chmod +x start-all.sh
```

#### Step 8: Run the Application

**Option A: Start Both Servers at Once**
```bash
./start-all.sh
```

**Option B: Start Servers Separately**

Terminal 1 (Backend):
```bash
./start-backend.sh
```

Terminal 2 (Frontend):
```bash
./start-frontend.sh
```

**Option C: Manual Start**

Terminal 1 (Backend):
```bash
cd backend
python3 app.py
```

Terminal 2 (Frontend):
```bash
npm run dev
```

#### Access the Application
- **Frontend**: http://localhost:5000
- **Backend API**: http://localhost:8000

---

## First Time Setup

After installation and starting the servers:

1. **Open your browser** and go to http://localhost:5000
2. **Upload Contact Lists**: Go to Contacts page and upload a CSV or TXT file with email addresses
3. **Add Subject Lines**: Go to Subjects page and upload or create subject line files
4. **Configure From Emails**: Go to From Emails page and add sender addresses
5. **Review Templates**: Check the Templates page - 10 professional templates are pre-installed
6. **Create Campaign**: Go to Campaigns page to set up your first email campaign
7. **Configure Email Provider**: In the campaign, set your email provider (SES, Resend, or SMTP)

## Email Provider Setup

### Amazon SES (Recommended)
1. Create an AWS account
2. Verify your sender email addresses in SES
3. Get SMTP credentials from SES console
4. Add credentials to `.env` file or campaign configuration

### Resend
1. Sign up at [resend.com](https://resend.com)
2. Get your API key
3. Add to `.env` file or campaign configuration

### Gmail SMTP
1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password
3. Use the app password in SMTP configuration

## Troubleshooting

### Python not found
- Make sure Python 3.9.9 is installed
- On Windows: Add Python to PATH
- On Mac/Linux: Use `python3` instead of `python`

### Port already in use
- Backend (8000): Another app is using the port. Change in `backend/app.py`
- Frontend (5000): Change in `package.json` scripts section

### Dependencies installation fails
**Windows:**
```cmd
python -m pip install --upgrade pip
pip install -r requirements.txt --no-cache-dir
```

**Mac/Linux:**
```bash
python3 -m pip install --upgrade pip
pip3 install -r requirements.txt --no-cache-dir
```

### Frontend won't start
```bash
rm -rf node_modules package-lock.json
npm install
npm run dev
```

**Windows:**
```cmd
rmdir /s /q node_modules
del package-lock.json
npm install
npm run dev
```

## File Structure

```
email-marketing-platform/
├── backend/                 # Python Flask backend
│   └── app.py              # Main backend application
├── frontend/               # React frontend
│   └── src/               # Source files
├── subjects/              # Subject line files (.txt)
├── from_emails/           # Sender email files (.txt)
├── contacts/              # Contact list files (.csv, .txt)
├── templates/             # Email HTML templates
├── campaigns/             # Campaign configurations (.json)
├── requirements.txt       # Python dependencies
├── package.json          # Node.js dependencies
├── start-all.bat         # Windows: Start both servers
├── start-backend.bat     # Windows: Start backend only
├── start-frontend.bat    # Windows: Start frontend only
├── start-all.sh          # Mac/Linux: Start both servers
├── start-backend.sh      # Mac/Linux: Start backend only
├── start-frontend.sh     # Mac/Linux: Start frontend only
└── INSTALL.md           # This file
```

## Deployment to Production

For production deployment, see the deployment section in `replit.md` or use:

```bash
# Build frontend
npm run build

# Run with Gunicorn (production server)
cd backend
gunicorn --bind=0.0.0.0:5000 --reuse-port app:app
```

## Support

For issues or questions:
1. Check this installation guide
2. Review `replit.md` for feature documentation
3. Check the troubleshooting section above

## License

This is a comprehensive email marketing platform for bulk email sending with rotation features.
