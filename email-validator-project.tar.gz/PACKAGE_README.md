# 📧 Email Validator - Complete Package

This package includes **both** the standalone Python script and the full-stack web application.

## 📦 What's Included

```
email-validator/
├── 🔷 STANDALONE VERSION (Python Script)
│   ├── email_validator_standalone.py    # Main standalone script
│   ├── STANDALONE_README.md             # Usage guide
│   ├── STANDALONE_INSTALL.md            # Installation options
│   ├── STANDALONE_COMPARISON.md         # vs Full App
│   ├── requirements_standalone.txt      # Optional: dnspython
│   ├── setup.py                         # pip install support
│   ├── quickstart.sh                    # Quick setup script
│   └── sample_emails.csv                # Example CSV file
│
└── 🌐 FULL WEB APPLICATION (FastAPI + React)
    ├── backend/                         # Python FastAPI backend
    ├── client/                          # React frontend
    ├── server/                          # Node.js orchestration
    ├── shared/                          # Shared TypeScript types
    ├── replit.md                        # Full app documentation
    └── package.json                     # Node.js dependencies
```

## 🚀 Quick Start

### Option 1: Standalone Script (Recommended for Most Users)

**Zero setup - just download and run:**

```bash
# Download the script
curl -O https://raw.githubusercontent.com/yourrepo/main/email_validator_standalone.py

# Validate an email
python3 email_validator_standalone.py validate test@gmail.com

# Validate a CSV file
python3 email_validator_standalone.py bulk emails.csv
```

**That's it!** No installation, no dependencies (except Python 3.7+).

📖 **Full Guide**: See [STANDALONE_README.md](STANDALONE_README.md)

### Option 2: Full Web Application

**For teams and production deployments:**

```bash
# Clone repository
git clone https://github.com/yourrepo/email-validator.git
cd email-validator

# Install dependencies
npm install
pip install -r backend/requirements.txt

# Set up database
npm run db:push

# Start application
npm run dev
```

🌐 **Access**: http://localhost:5173

📖 **Full Guide**: See [replit.md](replit.md) and [INSTALL.md](INSTALL.md)

## 🤔 Which Version Should I Use?

### Use Standalone Script If:
- ✅ You need quick email validation
- ✅ You're comfortable with command line
- ✅ You don't need a web interface
- ✅ You want zero setup time
- ✅ You're validating < 50,000 emails/month
- **→ 90% of users start here**

### Use Full Web App If:
- ✅ You need a web dashboard
- ✅ Multiple team members need access
- ✅ You want user authentication
- ✅ You need API endpoints
- ✅ You want validation history
- **→ For production services**

📊 **Detailed Comparison**: See [STANDALONE_COMPARISON.md](STANDALONE_COMPARISON.md)

## ✨ Key Features

### Both Versions Include:
- ✅ Email format validation
- ✅ MX record DNS lookup
- ✅ Provider detection (Microsoft, Google, Office365, GoDaddy, Mimecast, ARSMTP)
- ✅ Bulk CSV processing (up to 10,000 emails)
- ✅ Results export (CSV format)
- ✅ Performance timing

### Full Web App Additional Features:
- ✅ User authentication (username/password + JWT)
- ✅ Credit system (1 billion credits per user)
- ✅ Rate limiting (60 requests/minute)
- ✅ PostgreSQL database persistence
- ✅ Real-time validation dashboard
- ✅ REST API endpoints
- ✅ Provider-specific exports

## 📋 System Requirements

### Standalone Script:
- Python 3.7 or higher
- (Optional) dnspython for better DNS lookups

### Full Web Application:
- Python 3.11+
- Node.js 20+
- PostgreSQL database
- 512MB+ RAM
- Port 5000 (backend) and 5173 (frontend)

## 🎯 Usage Examples

### Standalone Script

```bash
# Single email validation
python3 email_validator_standalone.py validate admin@company.com

# Bulk CSV validation
python3 email_validator_standalone.py bulk contacts.csv

# Interactive mode
python3 email_validator_standalone.py interactive

# Custom export paths
python3 email_validator_standalone.py bulk emails.csv \
  --export results.csv \
  --deliverable valid_only.txt
```

### Full Web App API

```bash
# Sign up new user
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"username":"demo","password":"Password123!","email":"demo@example.com"}'

# Validate single email
curl -X POST http://localhost:5000/api/validate/single \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"email":"test@gmail.com"}'

# Bulk validation
curl -X POST http://localhost:5000/api/validate/bulk \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"emails":["user1@gmail.com","user2@outlook.com"]}'
```

## 📖 Documentation

| Document | Description |
|----------|-------------|
| [STANDALONE_README.md](STANDALONE_README.md) | Complete standalone script guide |
| [STANDALONE_INSTALL.md](STANDALONE_INSTALL.md) | Installation methods |
| [STANDALONE_COMPARISON.md](STANDALONE_COMPARISON.md) | Feature comparison |
| [replit.md](replit.md) | Full app architecture |
| [INSTALL.md](INSTALL.md) | Full app installation |

## 🔧 Installation Methods

### Standalone Script

**Method 1: Direct Download**
```bash
curl -O https://raw.githubusercontent.com/yourrepo/main/email_validator_standalone.py
python3 email_validator_standalone.py validate test@gmail.com
```

**Method 2: pip Install**
```bash
pip install .
email-validator validate test@gmail.com
```

**Method 3: Docker**
```bash
docker build -t email-validator .
docker run email-validator validate test@gmail.com
```

See [STANDALONE_INSTALL.md](STANDALONE_INSTALL.md) for all options.

### Full Web App

**Standard Installation:**
```bash
npm install
pip install -r backend/requirements.txt
npm run db:push
npm run dev
```

**Replit Deployment:**
1. Import to Replit
2. Click "Run"
3. Done!

## 🌟 Provider Detection

Both versions detect these email providers:

| Provider | Detection Method |
|----------|------------------|
| **Microsoft** | outlook.com, hotmail.com, live.com, msn.com |
| **Google** | gmail.com + MX record patterns |
| **Office365** | mail.protection.outlook.com MX |
| **GoDaddy** | secureserver.net MX records |
| **Mimecast** | mimecast.com MX records |
| **ARSMTP** | antispamcloud.com MX records |

## 📊 Performance

### Validation Speed

- **Format check**: < 1ms per email
- **MX lookup**: 5-50ms per domain (with 5s timeout)
- **Bulk processing**: ~10-30 seconds per 1,000 emails

### Limits

- **Max batch size**: 10,000 emails
- **DNS timeout**: 5 seconds
- **Rate limit** (full app): 60 requests/minute

## 🔒 Security

### Standalone Script
- Runs locally (no network exposure)
- No authentication needed
- Results stored as local files

### Full Web App
- JWT authentication with HTTP-only cookies
- Bcrypt password hashing (12 rounds)
- CORS protection with credentials
- Rate limiting (60 req/min per IP)
- Session management (7-day expiration)

## 💡 Pro Tips

1. **Start Simple**: Try the standalone script first
2. **DNS Performance**: Install `pip install dnspython` for faster lookups
3. **Large Files**: Split CSVs > 10,000 emails into batches
4. **API Keys**: Not needed! Works without any external APIs
5. **Offline Mode**: Cache DNS results for offline validation

## 🐛 Troubleshooting

### Standalone Script

```bash
# "dnspython not installed" warning
pip install dnspython

# Permission denied
chmod +x email_validator_standalone.py

# Python not found
python3 --version  # Check Python installation
```

### Full Web App

```bash
# Database connection issues
npm run db:push --force

# Port already in use
kill $(lsof -t -i:5000)  # Backend
kill $(lsof -t -i:5173)  # Frontend

# Dependencies issues
rm -rf node_modules && npm install
```

## 🤝 Contributing

We welcome contributions! Both the standalone script and full app are open for improvements.

### Areas for Contribution:
- Additional provider detection patterns
- Performance optimizations
- New export formats
- Enhanced validation rules
- Documentation improvements

## 📄 License

MIT License - Use it however you need!

## 🔗 Links

- **GitHub**: https://github.com/yourrepo/email-validator
- **Issues**: https://github.com/yourrepo/email-validator/issues
- **Replit**: https://replit.com/@yourusername/email-validator

## 📞 Support

- 📧 **Email**: support@yourapp.com
- 💬 **Discord**: https://discord.gg/yourserver
- 📚 **Docs**: See documentation files above
- 🐛 **Bug Reports**: GitHub Issues

---

**Happy Validating!** 🚀

Choose the version that fits your needs and start validating emails in minutes!
