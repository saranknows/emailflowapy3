# Email Validator API

## Overview
This project is a full-stack email validation application offering both single and bulk email validation, coupled with comprehensive email service provider detection. It validates email format, performs MX record lookups, and identifies major email providers. Users receive 1 billion validation credits upon registration and can validate up to 10,000 emails per bulk upload. The system also includes a robust email click tracking system, allowing users to create campaigns, generate unique tracking URLs, and analyze click-through data with detailed analytics.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is a React + TypeScript Single Page Application (SPA) built with Vite for fast development. It uses Wouter for routing, TanStack Query for server state management, and `shadcn/ui` components based on Radix UI for accessible and customizable UI. Styling is handled with Tailwind CSS, supporting both light and dark modes, with a primary purple/violet color scheme. Key design decisions include custom rounded corners, dual-mode theming, and provider-specific badge colors for visual consistency.

### Backend Architecture
The backend is built with Express.js (Node.js) and TypeScript, serving both the API and the React frontend from a single Node.js process on port 5000. This unified JavaScript/TypeScript stack simplifies deployment and leverages native async/await for operations like DNS lookups.

**API Structure**:
-   **Authentication Routes**: User login, signup (with license key verification), session management, credits tracking.
-   **Admin Routes**: License key generation, listing, and revocation (protected by requireAdmin middleware).
-   **Validation Routes**: Single and bulk email validation.
-   **Analytics Routes**: API health and rate limit information.
-   **Tracking Routes**: Campaign management, tracking link generation, click analytics.
-   **Public Redirect Route**: `/t/{token}` for click tracking and redirection.

**Email Validation Logic**:
Format validation via regex and Zod schemas, DNS MX record lookups, multi-provider detection via MX record pattern matching, and domain-based detection for major providers.

### Data Storage
PostgreSQL (Neon serverless) is used as the database, managed with Drizzle ORM for type-safe operations.

**Database Tables**:
-   `users`: User accounts with username, password_hash, email, validation credits, license_key (nullable), and is_admin boolean flag.
-   `license_keys`: Admin-managed license keys with id, key, assignedUserId, status (active/revoked), issuedAt, revokedAt, assignedAt.
-   `email_validations`: Stores results of email validations (email, domain, deliverability, provider flags, MX records, validation time).
-   `campaigns`: Click tracking campaign details (name, description, target URL).
-   `tracking_links`: Unique tracking URLs per recipient with token and click count.
-   `click_events`: Detailed click records (IP, user agent, geo-location, referrer).

### Authentication & Security
The system uses username-based authentication with **license key verification** as a mandatory requirement. All users must have a valid, active license key to register and login. JWT tokens are stored in HTTP-only cookies (7-day expiration). Passwords are hashed with Bcrypt (12 salt rounds). Rate limiting is implemented at 60 requests per minute per IP for authentication endpoints. CORS is configured to allow specific origins in production and a regex pattern for local development, always supporting credentials.

**License Key Authentication System:**
-   **Admin-Managed Provisioning**: Admins manually generate license keys via the Admin UI tab in the dashboard.
-   **Registration Flow**: Users must provide a valid, unassigned license key during signup. The system atomically assigns the key to the new user.
-   **Login Verification**: Login requires username, password, AND an active license key. Revoked keys block access immediately.
-   **Admin Controls**: Admins can generate new keys (up to 100 at once), view all keys with assignment status, and revoke keys to disable user access.
-   **Security Architecture**: Separate `license_keys` table with fields: id, key, assignedUserId, status (active/revoked), issuedAt, revokedAt, assignedAt. Admin routes protected by `requireAdmin` middleware that checks `is_admin` boolean field.

### CSV Processing
The bulk upload pipeline supports up to 10,000 emails per CSV file, requires UTF-8 encoding, automatically detects email columns, and performs streaming validation with progress tracking. Results are sorted by provider.

### Click Tracking System
This system enables users to create campaigns, generate unique tracking URLs for email recipients, and track clicks with detailed analytics.
-   **Token Generation**: 128-byte secure random tokens.
-   **Public Endpoint**: `/t/{token}` records clicks and redirects.
-   **Protected API**: `/api/tracking/*` for campaign management and analytics.
-   **Features**: Unique tracking URLs, click counting (total and unique), first/last click timestamps, detailed click events (IP, user agent, referrer, geo-location), campaign statistics, and bulk link generation.
-   **Dashboard Integration**: Fully integrated into the main dashboard with dedicated tabs for single email, bulk upload, link tracking, and admin controls (visible only to admin users).

## External Dependencies

### Core Technologies
-   **Neon Database**: Serverless PostgreSQL.
-   **Drizzle Kit**: Database migrations and schema management.

### Frontend Libraries
-   **Radix UI**: Headless component primitives.
-   **React Hook Form**: Form validation with Zod resolvers.
-   **TanStack Query**: Server state management.
-   **Wouter**: Lightweight client-side routing.
-   **shadcn/ui**: UI component library.
-   **Tailwind CSS**: Styling.

### Backend Libraries
-   **Express.js**: Web framework.
-   **TypeScript**: Type safety.
-   **Zod**: Schema validation.
-   **bcrypt**: Password hashing.
-   **jsonwebtoken**: JWT token handling.
-   **express-rate-limit**: Rate limiting middleware.
-   **dns/promises (Node.js)**: DNS lookups.

### Development Tools
-   **Vite**: Frontend build tool.
-   **tsx**: TypeScript execution for development.
-   **ESBuild**: Fast bundling.

### Deployment Configuration
-   Environment variables for Database URL and Session Secret.