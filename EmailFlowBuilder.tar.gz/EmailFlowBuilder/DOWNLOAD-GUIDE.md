# Download and Setup Guide

This guide helps you prepare the Email Marketing Platform for download and setup on any Windows, Mac, or Linux system with Python 3.9.9.

## 📦 What's Included in the Download

When you download this project, you'll get:

### Core Application Files
- `backend/` - Python Flask backend server
- `frontend/` - React frontend application
- `templates/` - 10 professional email templates (pre-installed)

### Configuration Files
- `requirements.txt` - Python dependencies
- `package.json` - Node.js dependencies
- `vite.config.js` - Frontend build configuration
- `.gitignore` - Git ignore rules

### Documentation
- `README.md` - Project overview and quick start
- `INSTALL.md` - Complete installation instructions
- `replit.md` - Full feature documentation
- `DOWNLOAD-GUIDE.md` - This file

### Run Scripts

**Windows (.bat files):**
- `start-all.bat` - Start both backend and frontend
- `start-backend.bat` - Start backend only
- `start-frontend.bat` - Start frontend only

**Mac/Linux (.sh files):**
- `start-all.sh` - Start both backend and frontend
- `start-backend.sh` - Start backend only
- `start-frontend.sh` - Start frontend only

### Data Folders
- `subjects/` - For subject line files
- `from_emails/` - For sender email address files
- `contacts/` - For contact list files
- `campaigns/` - For campaign configurations

## 🎯 After Download - Quick Setup

### 1. Extract the ZIP file
Extract to your desired location:
- Windows: `C:\email-marketing-platform\`
- Mac/Linux: `~/email-marketing-platform/`

### 2. Install Prerequisites

**You need:**
- Python 3.9.9 (Download from [python.org](https://www.python.org/downloads/release/python-399/))
- Node.js 20.x (Download from [nodejs.org](https://nodejs.org/))

### 3. Install Dependencies

Open terminal/command prompt in the extracted folder:

```bash
# Install Python packages
pip install -r requirements.txt

# Install Node.js packages
npm install
```

### 4. Run the Application

**Windows:**
```cmd
start-all.bat
```

**Mac/Linux:**
```bash
chmod +x start-all.sh
./start-all.sh
```

### 5. Access the Application
Open your browser and go to:
- **Frontend**: http://localhost:5000
- **Backend API**: http://localhost:8000

## 📋 Complete Setup Instructions

For detailed installation instructions, including troubleshooting, see **[INSTALL.md](INSTALL.md)**

## 🚀 First Time Use

1. **Upload Contacts**: Go to the Contacts page and upload your email list (CSV or TXT)
2. **Add Subjects**: Upload or create subject line files on the Subjects page
3. **Configure Senders**: Add sender email addresses on the From Emails page
4. **Review Templates**: 10 professional templates are already included
5. **Create Campaign**: Set up your first email campaign
6. **Configure Email Provider**: Add your SES, Resend, or SMTP credentials
7. **Send**: Start your campaign with automatic rotation

## 🔧 Email Provider Configuration

Create a `.env` file in the `backend` folder:

```env
# Amazon SES (Recommended)
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your_username
SES_SMTP_PASSWORD=your_password

# Or use Resend
RESEND_API_KEY=your_api_key

# Or use Generic SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

## 📂 Project Structure After Extract

```
email-marketing-platform/
├── README.md                  # Overview
├── INSTALL.md                 # Installation guide
├── DOWNLOAD-GUIDE.md          # This file
├── requirements.txt           # Python dependencies
├── package.json              # Node.js dependencies
├── start-all.bat             # Windows: Start all
├── start-all.sh              # Mac/Linux: Start all
├── backend/
│   ├── app.py               # Main backend server
│   └── .env                 # Create this for email config
├── frontend/
│   └── src/                 # React source files
├── templates/
│   ├── template1-professional.html
│   ├── template2-modern.html
│   ├── template3-minimal.html
│   ├── template4-corporate.html
│   ├── template5-newsletter.html
│   ├── template6-promotional.html
│   ├── template7-elegant.html
│   ├── template8-tech.html
│   ├── template9-friendly.html
│   └── template10-announcement.html
├── subjects/                 # Add .txt files here
├── from_emails/              # Add .txt files here
├── contacts/                 # Add .csv/.txt files here
└── campaigns/                # Auto-generated campaign files
```

## ✅ Verification Checklist

After installation, verify:

- [ ] Python 3.9.9 is installed: `python --version`
- [ ] Node.js is installed: `node --version`
- [ ] Python packages installed: `pip list | grep flask`
- [ ] Node packages installed: Check `node_modules/` exists
- [ ] Backend starts: `start-backend.bat` or `./start-backend.sh`
- [ ] Frontend starts: `start-frontend.bat` or `./start-frontend.sh`
- [ ] Can access http://localhost:5000
- [ ] Can access http://localhost:8000/api/health

## 🐛 Common Issues After Download

### "Python is not recognized"
- Install Python 3.9.9
- Add Python to PATH (Windows installer option)
- Restart terminal/command prompt

### "node is not recognized"
- Install Node.js from nodejs.org
- Restart terminal/command prompt

### "pip install fails"
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt --no-cache-dir
```

### "Port already in use"
- Backend (8000): Another app is using it
- Frontend (5000): Another app is using it
- Stop other apps or change ports in configuration

### "Module not found" errors
```bash
# Reinstall Python dependencies
pip install -r requirements.txt --force-reinstall

# Reinstall Node dependencies
rm -rf node_modules
npm install
```

## 💡 Pro Tips

1. **First Run**: Use `start-all.bat` (Windows) or `start-all.sh` (Mac/Linux) to start both servers at once
2. **Development**: Keep both terminals open to see real-time logs
3. **Email Testing**: Start with a small contact list to test your configuration
4. **Templates**: All 10 templates are ready - just create a campaign and they'll auto-rotate
5. **Security**: Never commit your `.env` file with real credentials to version control

## 📖 Need More Help?

- **Quick Start**: See [README.md](README.md)
- **Installation**: See [INSTALL.md](INSTALL.md)
- **Features**: See [replit.md](replit.md)
- **Troubleshooting**: See INSTALL.md troubleshooting section

## 🎉 You're Ready!

Once you've completed the setup:
1. Access http://localhost:5000
2. Upload your contact lists
3. Create your first campaign
4. Start sending emails with automatic rotation!

---

**Note**: This is a standalone application. Once downloaded and set up, it runs entirely on your local machine without needing Replit or any external services (except your chosen email provider like SES or Resend).
