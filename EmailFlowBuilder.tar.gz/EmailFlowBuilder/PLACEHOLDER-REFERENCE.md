# Email Template Placeholder Reference Guide

## Overview
This guide documents all available placeholder variables that can be used in your email templates. Placeholders are automatically replaced with dynamic content when emails are sent.

---

## 📋 **Available Placeholders**

### **Content Placeholders**

#### `{{content}}`
**Purpose:** Main email body content  
**Replaced With:** Your custom email message or content  
**Example Usage:**
```html
<div style="padding: 20px;">
    {{content}}
</div>
```

**Output:**
```html
<div style="padding: 20px;">
    Your email content here
</div>
```

---

### **Branding Placeholders**

#### `{{COMPANYLOGO}}`
**Purpose:** Company logo via Clearbit Logo API  
**Replaced With:** Company domain for logo fetching  
**Source:** `EMAIL_CONFIG['company_logo']` in main.py  
**Example Usage:**
```html
<img src="https://logo.clearbit.com/{{COMPANYLOGO}}" 
     alt="Company Logo" 
     style="width: 120px;">
```

**Output:**
```html
<img src="https://logo.clearbit.com/example.com" 
     alt="Company Logo" 
     style="width: 120px;">
```

**Configuration:**
```python
# In main.py EMAIL_CONFIG section
EMAIL_CONFIG = {
    'company_logo': 'yourcompany.com',  # Change this
    # ...
}
```

---

### **Link Placeholders**

All link placeholders rotate from files in the `links/` folder.

#### `{{link}}`
**Purpose:** Main call-to-action link  
**Source:** `links/main_links.txt`  
**Example Usage:**
```html
<a href="{{link}}" style="color: blue;">Click Here</a>
```

#### `{{website}}`
**Purpose:** Website URL  
**Source:** `links/websites.txt`  
**Example Usage:**
```html
<a href="{{website}}">Visit Our Website</a>
```

#### `{{unsubscribe}}`
**Purpose:** Unsubscribe link  
**Source:** `links/unsubscribe_links.txt`  
**Example Usage:**
```html
<a href="{{unsubscribe}}">Unsubscribe</a>
```

#### `{{privacy}}`
**Purpose:** Privacy policy link  
**Source:** `links/privacy_links.txt`  
**Example Usage:**
```html
<a href="{{privacy}}">Privacy Policy</a>
```

#### `{{contact}}`
**Purpose:** Contact page link  
**Source:** `links/contact_links.txt`  
**Example Usage:**
```html
<a href="{{contact}}">Contact Us</a>
```

#### `{{preferences}}`
**Purpose:** Email preferences link  
**Source:** `links/` folder (auto-generated)  
**Example Usage:**
```html
<a href="{{preferences}}">Manage Preferences</a>
```

#### `{{terms}}`
**Purpose:** Terms of service link  
**Source:** `links/` folder (auto-generated)  
**Example Usage:**
```html
<a href="{{terms}}">Terms of Service</a>
```

#### `{{docs}}`
**Purpose:** Documentation link  
**Source:** `links/` folder (auto-generated)  
**Example Usage:**
```html
<a href="{{docs}}">View Documentation</a>
```

#### `{{archive}}`
**Purpose:** Email archive link  
**Source:** `links/` folder (auto-generated)  
**Example Usage:**
```html
<a href="{{archive}}">View in Browser</a>
```

---

### **Legal Placeholders**

#### `{{disclaimer}}`
**Purpose:** Rotating legal disclaimer text  
**Source:** `disclaimers/` folder (500 files)  
**Rotation:** Automatic with each email  
**Example Usage:**
```html
<p style="font-size: 10px; color: #999;">
    {{disclaimer}}
</p>
```

**Output:**
```html
<p style="font-size: 10px; color: #999;">
    This email and any attachments are confidential and intended 
    solely for the use of the individual to whom it is addressed.
</p>
```

---

### **Dynamic Content Placeholders**

#### `{{qrcode}}`
**Purpose:** Dynamically generated QR code  
**Source:** `EMAIL_CONFIG['qr_code_data']` in main.py  
**Format:** Base64-encoded PNG image  
**Enabled:** `EMAIL_CONFIG['enable_qr_code'] = True`  
**Example Usage:**
```html
<div style="text-align: center;">
    <p>Scan to view document:</p>
    {{qrcode}}
</div>
```

**Output:**
```html
<div style="text-align: center;">
    <p>Scan to view document:</p>
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUg..." width="300" alt="QR Code">
</div>
```

**Configuration:**
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'https://example.com/document',
    'qr_code_size': 300,
}
```

---

## 📁 **Placeholder Sources**

### **File-Based Placeholders**

| Placeholder | Source Folder | File Format | Rotation |
|-------------|---------------|-------------|----------|
| `{{disclaimer}}` | `disclaimers/` | `.txt` files | ✅ Yes (500) |
| `{{link}}` | `links/` | `main_links.txt` | ✅ Yes |
| `{{website}}` | `links/` | `websites.txt` | ✅ Yes |
| `{{unsubscribe}}` | `links/` | `unsubscribe_links.txt` | ✅ Yes |
| `{{privacy}}` | `links/` | `privacy_links.txt` | ✅ Yes |
| `{{contact}}` | `links/` | `contact_links.txt` | ✅ Yes |

### **Configuration-Based Placeholders**

| Placeholder | Source | Configuration Location |
|-------------|--------|------------------------|
| `{{COMPANYLOGO}}` | EMAIL_CONFIG | `main.py` line ~50 |
| `{{content}}` | Hardcoded | Default: "Your email content here" |

---

## 🔧 **How Placeholders Work**

### **1. Replacement Process**

```python
# Step 1: Load template with placeholders
template = "<p>{{content}}</p><a href='{{link}}'>Click</a>"

# Step 2: Replace each placeholder
html_content = template.replace('{{content}}', 'Hello World')
html_content = html_content.replace('{{link}}', 'https://example.com')

# Step 3: Final output
# <p>Hello World</p><a href='https://example.com'>Click</a>
```

### **2. Rotation Logic**

```python
# Disclaimers rotate with each email
disclaimer_cycle = cycle(disclaimers)

for email in emails:
    current_disclaimer = next(disclaimer_cycle)
    html = html.replace('{{disclaimer}}', current_disclaimer)
```

---

## 💡 **Usage Examples**

### **Example 1: Basic Email Template**

```html
<!DOCTYPE html>
<html>
<head>
    <title>Email</title>
</head>
<body>
    <div style="max-width: 600px; margin: 0 auto;">
        <!-- Logo -->
        <img src="https://logo.clearbit.com/{{COMPANYLOGO}}" 
             alt="Logo" 
             style="width: 150px;">
        
        <!-- Content -->
        <div style="padding: 20px;">
            {{content}}
        </div>
        
        <!-- Call to Action -->
        <a href="{{link}}" 
           style="background: blue; color: white; padding: 10px 20px;">
            Click Here
        </a>
        
        <!-- Footer -->
        <div style="padding: 20px; font-size: 10px; color: #999;">
            <p>{{disclaimer}}</p>
            <a href="{{unsubscribe}}">Unsubscribe</a> | 
            <a href="{{privacy}}">Privacy</a>
        </div>
    </div>
</body>
</html>
```

### **Example 2: DocuSign-Style Template**

```html
<table style="width: 100%; max-width: 600px;">
    <tr>
        <td style="padding: 20px; text-align: center;">
            <img src="https://logo.clearbit.com/{{COMPANYLOGO}}" 
                 style="width: 120px;">
        </td>
    </tr>
    <tr>
        <td style="padding: 30px; background: #f5f5f5;">
            <h2>Document Ready for Signature</h2>
            {{content}}
            <a href="{{link}}" 
               style="display: inline-block; margin-top: 20px; 
                      background: #4CAF50; color: white; 
                      padding: 15px 30px; text-decoration: none;">
                Review Document
            </a>
        </td>
    </tr>
    <tr>
        <td style="padding: 20px; background: #eaeaea; text-align: center;">
            <p style="font-size: 10px; color: #666;">{{disclaimer}}</p>
            <a href="{{unsubscribe}}" style="color: #666;">Unsubscribe</a> | 
            <a href="{{privacy}}" style="color: #666;">Privacy Policy</a> | 
            <a href="{{contact}}" style="color: #666;">Contact Us</a>
        </td>
    </tr>
</table>
```

### **Example 3: All Placeholders Used**

```html
<html>
<body>
    <!-- Branding -->
    <img src="https://logo.clearbit.com/{{COMPANYLOGO}}">
    
    <!-- Content -->
    <div>{{content}}</div>
    
    <!-- Links -->
    <a href="{{link}}">Main Link</a>
    <a href="{{website}}">Website</a>
    <a href="{{docs}}">Documentation</a>
    <a href="{{archive}}">View Online</a>
    
    <!-- Footer Links -->
    <a href="{{unsubscribe}}">Unsubscribe</a>
    <a href="{{privacy}}">Privacy Policy</a>
    <a href="{{contact}}">Contact</a>
    <a href="{{preferences}}">Preferences</a>
    <a href="{{terms}}">Terms</a>
    
    <!-- Legal -->
    <p>{{disclaimer}}</p>
</body>
</html>
```

---

## 📝 **Creating Custom Link Files**

### **Add New Links**

1. **Create file in links/ folder:**
```bash
nano links/main_links.txt
```

2. **Add one URL per line:**
```
https://example.com/offer1
https://example.com/offer2
https://example.com/offer3
```

3. **Save and use placeholder:**
```html
<a href="{{link}}">Click Here</a>
```

### **Link File Format**

**Correct:**
```
https://example.com/page1
https://example.com/page2
https://example.com/page3
```

**Incorrect:**
```
<a href="https://example.com">Link</a>  ❌ (No HTML)
example.com  ❌ (Must include https://)
```

---

## 🎨 **Customizing Placeholders**

### **Change Company Logo Domain**

Edit `main.py`:
```python
EMAIL_CONFIG = {
    'company_logo': 'yourcompany.com',  # ← Change this
    # ...
}
```

### **Change Default Content**

Edit `main.py` around line 1114:
```python
# Find this line:
html_content = template_content.replace('{{content}}', 'Your email content here')

# Change to:
html_content = template_content.replace('{{content}}', 'Your custom default content')
```

### **Add Custom Placeholder**

1. **Add to template:**
```html
<p>{{custom}}</p>
```

2. **Add replacement in main.py:**
```python
# After other replacements (around line 1127)
html_content = html_content.replace('{{custom}}', 'Custom Value')
```

---

## 🔍 **Placeholder Best Practices**

### **✅ DO:**

- Use double curly braces: `{{placeholder}}`
- Keep placeholder names lowercase
- Use descriptive names: `{{unsubscribe}}` not `{{u}}`
- Test placeholders before sending
- Provide fallback links in link files

### **❌ DON'T:**

- Mix case: `{{UnSubScribe}}` ❌
- Use single braces: `{placeholder}` ❌
- Use spaces: `{{ link }}` ❌
- Forget closing braces: `{{link}` ❌
- Leave placeholders empty in templates

---

## 🐛 **Troubleshooting**

### **Placeholder Shows Literally (e.g., "{{link}}")**

**Problem:** Placeholder text appears instead of being replaced

**Solutions:**
1. Check spelling matches exactly
2. Verify double curly braces `{{` and `}}`
3. Ensure no spaces inside: `{{link}}` not `{{ link }}`
4. Check source file exists (for file-based placeholders)

### **Placeholder Shows Default URL**

**Problem:** Shows "https://example.com" instead of custom URL

**Solutions:**
1. Create source file in links/ folder
2. Add your URLs (one per line)
3. Verify file name matches placeholder
4. Reload main.py

### **Logo Not Loading**

**Problem:** Company logo doesn't appear

**Solutions:**
1. Check `EMAIL_CONFIG['company_logo']` is set
2. Verify domain is valid
3. Test URL: `https://logo.clearbit.com/yourdomain.com`
4. Ensure company has logo in Clearbit database

---

## 📊 **Placeholder Summary**

### **Total Available Placeholders: 14**

| Category | Count | Placeholders |
|----------|-------|--------------|
| **Content** | 1 | `{{content}}` |
| **Branding** | 1 | `{{COMPANYLOGO}}` |
| **Links** | 9 | `{{link}}`, `{{website}}`, `{{unsubscribe}}`, `{{privacy}}`, `{{contact}}`, `{{preferences}}`, `{{terms}}`, `{{docs}}`, `{{archive}}` |
| **Legal** | 1 | `{{disclaimer}}` |
| **Dynamic** | 1 | `{{qrcode}}` |

### **Rotation Status**

- ✅ **Rotating:** `{{disclaimer}}`, `{{link}}`, `{{website}}`, `{{unsubscribe}}`, `{{privacy}}`, `{{contact}}`
- ⚪ **Static:** `{{COMPANYLOGO}}`, `{{content}}`
- 🔄 **Optional:** `{{preferences}}`, `{{terms}}`, `{{docs}}`, `{{archive}}`
- 🎨 **Dynamic:** `{{qrcode}}` (generated per configuration)

---

## 🚀 **Quick Reference**

### **Most Common Placeholders**

```html
<!-- Essential -->
{{content}}           - Main email body
{{COMPANYLOGO}}       - Company logo domain
{{link}}              - Main CTA link
{{disclaimer}}        - Legal disclaimer

<!-- Footer Links -->
{{unsubscribe}}       - Unsubscribe link
{{privacy}}           - Privacy policy
{{contact}}           - Contact page

<!-- Additional -->
{{website}}           - Homepage
{{preferences}}       - Email preferences
{{terms}}             - Terms of service
```

### **Template Snippet**

```html
<table style="width: 600px;">
    <tr>
        <td style="text-align: center;">
            <img src="https://logo.clearbit.com/{{COMPANYLOGO}}" width="120">
        </td>
    </tr>
    <tr>
        <td style="padding: 20px;">
            {{content}}
        </td>
    </tr>
    <tr>
        <td style="text-align: center;">
            <a href="{{link}}">Click Here</a>
        </td>
    </tr>
    <tr>
        <td style="padding: 20px; font-size: 10px;">
            <p>{{disclaimer}}</p>
            <a href="{{unsubscribe}}">Unsubscribe</a> | 
            <a href="{{privacy}}">Privacy</a>
        </td>
    </tr>
</table>
```

---

## 📚 **Related Documentation**

- **DISCLAIMER-ROTATION-GUIDE.md** - Complete disclaimer system guide
- **links/** folder - Link rotation source files
- **disclaimers/** folder - 500 disclaimer files
- **templates/** folder - 11 DocuSign templates with placeholders

---

**All 13 placeholders are ready to use in your email templates!** 🎉
