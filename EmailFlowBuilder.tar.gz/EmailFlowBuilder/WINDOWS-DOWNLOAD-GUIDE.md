# Windows Download & Setup Guide

This guide shows you exactly which files to download for running the email marketing platform on Windows.

## 🔒 IMPORTANT SECURITY WARNING

**`main.py` contains hardcoded SMTP credentials!**
- Never share this file publicly
- Never commit to GitHub or public repositories
- Keep secure and handle with care

---

## Option 1: Standalone Email Sender (Recommended for Quick Use)

**Use this if you just want to send emails via command line without the web interface.**

### Required Files

Download these files/folders:

```
📁 Your-Project-Folder/
├── main.py                          ⚠️ CONTAINS CREDENTIALS - KEEP SECURE
├── RUN-EMAIL-SENDER.bat             (Double-click to run)
├── requirements.txt                 (Python dependencies)
│
├── 📁 contacts/
│   └── emails.txt                   (Your recipient list)
│
├── 📁 subjects/
│   └── subject.txt                  (Your subject lines)
│
├── 📁 from_emails/
│   └── fromemails.txt               (Your sender addresses)
│
└── 📁 templates/
    ├── default.html
    ├── template1-professional.html
    ├── template2-modern.html
    ├── template3-minimal.html
    ├── template4-corporate.html
    ├── template5-newsletter.html
    ├── template6-promotional.html
    ├── template7-elegant.html
    ├── template8-tech.html
    ├── template9-friendly.html
    └── template10-announcement.html
```

### Optional Documentation

```
├── MAIN-PY-USAGE-GUIDE.md          (How to use main.py)
├── README.md                        (Project overview)
└── SOCKS-PROXY-SETUP.md            (If using SOCKS proxy)
```

### Installation Steps (Standalone)

1. **Install Python 3.9.9 for Windows**
   - Download from: https://www.python.org/downloads/
   - ✅ Check "Add Python to PATH" during installation

2. **Create your project folder:**
   ```cmd
   mkdir C:\EmailMarketing
   cd C:\EmailMarketing
   ```

3. **Download and copy all required files** (listed above) into this folder

4. **Install Python dependencies:**
   ```cmd
   pip install -r requirements.txt
   ```

5. **Run the sender:**
   - Double-click `RUN-EMAIL-SENDER.bat`, OR
   - Run `python main.py` in Command Prompt

**That's it! No configuration needed.**

---

## Option 2: Full Web Interface (Backend + Frontend)

**Use this if you want the complete web-based email marketing platform with dashboard.**

### Required Files

Download **ALL** of these files/folders:

```
📁 Your-Project-Folder/
├── main.py                          ⚠️ CONTAINS CREDENTIALS
├── RUN-EMAIL-SENDER.bat
├── start-all.bat                    (Starts web interface)
├── requirements.txt
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── index.html
│
├── 📁 backend/
│   ├── app.py
│   ├── requirements.txt
│   └── .env.example
│
├── 📁 frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   ├── tailwind.config.css
│   └── 📁 src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── index.css
│       ├── 📁 components/
│       ├── 📁 pages/
│       └── 📁 utils/
│
├── 📁 contacts/
│   └── emails.txt
│
├── 📁 subjects/
│   └── subject.txt
│
├── 📁 from_emails/
│   └── fromemails.txt
│
├── 📁 templates/
│   └── (all .html template files)
│
├── 📁 attachments/         (empty folder - for file uploads)
├── 📁 qr_codes/           (empty folder - auto-generated)
└── 📁 html_images/        (empty folder - auto-generated)
```

### Optional Documentation

```
├── README.md
├── INSTALL.md
├── MAIN-PY-USAGE-GUIDE.md
├── SOCKS-PROXY-SETUP.md
└── ENV-SETUP-GUIDE.md
```

### Installation Steps (Full Web Interface)

1. **Install Python 3.9.9**
   - Download from: https://www.python.org/downloads/
   - ✅ Check "Add Python to PATH"

2. **Install Node.js 20.x**
   - Download from: https://nodejs.org/
   - Use LTS version (20.x or higher)

3. **Create project folder:**
   ```cmd
   mkdir C:\EmailMarketing
   cd C:\EmailMarketing
   ```

4. **Download and copy all required files** into this folder

5. **Install Python dependencies:**
   ```cmd
   pip install -r requirements.txt
   cd backend
   pip install -r requirements.txt
   cd ..
   ```

6. **Install Node.js dependencies:**
   ```cmd
   npm install
   ```

7. **Start the application:**
   - Double-click `start-all.bat`, OR
   - Run `start-all.bat` in Command Prompt

8. **Open your browser:**
   ```
   http://localhost:5000
   ```

---

## Quick Download Checklist

### For Standalone Email Sender (main.py only):

- [ ] main.py ⚠️
- [ ] RUN-EMAIL-SENDER.bat
- [ ] requirements.txt
- [ ] contacts/ folder with emails.txt
- [ ] subjects/ folder with .txt files
- [ ] from_emails/ folder with fromemails.txt
- [ ] templates/ folder with all .html files
- [ ] MAIN-PY-USAGE-GUIDE.md (optional)

**Total: ~13 files + documentation**

### For Full Web Interface:

- [ ] Everything from standalone list above
- [ ] start-all.bat
- [ ] package.json, vite.config.js, tailwind.config.js
- [ ] backend/ folder (complete)
- [ ] frontend/ folder (complete)
- [ ] attachments/, qr_codes/, html_images/ folders (create empty)
- [ ] All documentation files

**Total: ~100+ files (entire project)**

---

## File Size Reference

- **Standalone (main.py)**: ~200KB total
- **Full Web Interface**: ~50MB with node_modules (after npm install)

---

## System Requirements

### Minimum:
- Windows 10 or higher
- Python 3.9.9
- 2GB RAM
- 100MB disk space (standalone)
- 500MB disk space (full interface with dependencies)

### For Full Web Interface:
- Node.js 20.x or higher
- npm (comes with Node.js)
- Modern web browser (Chrome, Firefox, Edge)

---

## After Download - Quick Start

### Standalone Email Sender:
```cmd
1. Open Command Prompt
2. cd C:\EmailMarketing
3. pip install -r requirements.txt
4. python main.py
```

### Full Web Interface:
```cmd
1. Open Command Prompt
2. cd C:\EmailMarketing
3. pip install -r requirements.txt
4. npm install
5. start-all.bat
6. Open browser to http://localhost:5000
```

---

## Configuration

### main.py (Standalone):
All configuration is **hardcoded** in the file. No setup needed!

To change settings, edit the `EMAIL_CONFIG` section at the top of `main.py`:
- Email provider (SES or SMTP)
- Delay between emails
- SOCKS proxy settings

### Web Interface:
The backend needs environment variables. Create `backend/.env`:
```bash
SES_SMTP_HOST=email-smtp.eu-central-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your-username
SES_SMTP_PASSWORD=your-password
```

---

## Troubleshooting

### "Python is not recognized"
- Reinstall Python and check "Add Python to PATH"
- Restart Command Prompt after installation

### "pip is not recognized"
- Run: `python -m pip install -r requirements.txt`

### "npm is not recognized"
- Reinstall Node.js
- Restart Command Prompt

### Port already in use (Full Web Interface)
- Close any apps using ports 5000 or 8000
- Or change ports in configuration files

---

## Security Checklist

- [ ] main.py stored in secure location
- [ ] main.py never uploaded to public repositories
- [ ] File permissions set appropriately
- [ ] Credentials rotated regularly
- [ ] Backups stored in encrypted location

---

## Support

For detailed documentation:
- **main.py usage**: See `MAIN-PY-USAGE-GUIDE.md`
- **Installation help**: See `INSTALL.md`
- **Proxy setup**: See `SOCKS-PROXY-SETUP.md`

---

**🎯 Recommended for most users**: Start with **Option 1 (Standalone)** first to test, then upgrade to full web interface if needed.
