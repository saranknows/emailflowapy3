# Environment Variables Setup Guide

This guide explains how to configure Amazon SES SMTP credentials and other email provider settings using environment variables.

## Quick Setup

### 1. Create Your .env File

Copy the example file to create your own environment configuration:

```bash
cp .env.example .env
```

### 2. Get Amazon SES SMTP Credentials

1. **Sign in to AWS Console**: https://console.aws.amazon.com/ses/
2. **Navigate to SMTP Settings**: 
   - Go to "Account Dashboard" → "SMTP Settings"
3. **Create SMTP Credentials**:
   - Click "Create SMTP Credentials"
   - Download and save your credentials securely
4. **Note Your Region's SMTP Endpoint**:
   - Example: `email-smtp.us-east-1.amazonaws.com` for US East (N. Virginia)

### 3. Configure Your .env File

Open `.env` in a text editor and fill in your credentials:

```bash
# Amazon SES SMTP Configuration
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your-actual-ses-smtp-username
SES_SMTP_PASSWORD=your-actual-ses-smtp-password
```

### 4. Restart the Backend

After configuring your `.env` file, restart the backend server to load the new credentials:

```bash
cd backend
python3 app.py
```

Or if using Replit, just restart the backend workflow.

## Configuration Options

### Amazon SES SMTP (Recommended)

**Best for**: High volume sending, excellent deliverability, production use

```bash
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your-ses-username
SES_SMTP_PASSWORD=your-ses-password
```

**Common SES SMTP Endpoints by Region:**
- US East (N. Virginia): `email-smtp.us-east-1.amazonaws.com`
- US West (Oregon): `email-smtp.us-west-2.amazonaws.com`
- EU (Ireland): `email-smtp.eu-west-1.amazonaws.com`
- Asia Pacific (Singapore): `email-smtp.ap-southeast-1.amazonaws.com`

**Ports:**
- `587` - STARTTLS (recommended)
- `465` - SSL/TLS
- `2587` - Alternative STARTTLS (if 587 is blocked)

### Generic SMTP Server

**Best for**: Using other email providers (Gmail, Outlook, etc.)

```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

### Resend API

**Best for**: Modern API-based sending, developer-friendly

```bash
RESEND_API_KEY=re_your_api_key_here
```

Get your API key from: https://resend.com/api-keys

### SOCKS Proxy Configuration

**Best for**: Bypassing network restrictions, routing through specific servers

```bash
PROXY_TYPE=socks5
PROXY_HOST=127.0.0.1
PROXY_PORT=1080
PROXY_USERNAME=your-proxy-username    # Optional
PROXY_PASSWORD=your-proxy-password    # Optional
```

**Supported Proxy Types:**
- `socks5` - SOCKS5 proxy (most common, recommended)
- `socks4` - SOCKS4 proxy (older, less features)
- `http` - HTTP/HTTPS proxy

**When to use:**
- Your network blocks SMTP ports (587, 465)
- You need to route traffic through a specific server
- You're behind a restrictive firewall
- You need additional privacy/anonymity

**Example configurations:**
```bash
# Local SOCKS5 proxy (SSH tunnel, etc.)
PROXY_TYPE=socks5
PROXY_HOST=127.0.0.1
PROXY_PORT=1080

# Remote SOCKS5 proxy with authentication
PROXY_TYPE=socks5
PROXY_HOST=proxy.example.com
PROXY_PORT=1080
PROXY_USERNAME=myusername
PROXY_PASSWORD=mypassword

# HTTP proxy
PROXY_TYPE=http
PROXY_HOST=proxy.company.com
PROXY_PORT=8080
```

## How It Works

### Priority Order

The system uses credentials in this order:
1. **Campaign Settings** (highest priority) - Settings passed in the campaign configuration
2. **Environment Variables** - Values from your `.env` file
3. **Default Values** (lowest priority) - Built-in fallback values

This means you can:
- Set default credentials in `.env` for all campaigns
- Override specific campaigns with different credentials
- Mix and match as needed

### Example Usage

#### Using Environment Variables (Easiest)

1. Configure `.env` with your SES credentials
2. Create a campaign and select provider `ses`
3. Leave SMTP settings blank - it will use `.env` values automatically

#### Overriding Per Campaign

In your campaign settings, you can override environment variables:

```json
{
  "provider": "ses",
  "ses_settings": {
    "host": "email-smtp.eu-west-1.amazonaws.com",
    "port": 587,
    "user": "different-username",
    "pass": "different-password"
  }
}
```

## Security Best Practices

### ✅ DO:
- Keep your `.env` file secure and never share it
- Use different credentials for development and production
- Enable MFA on your AWS account
- Rotate credentials regularly
- Use AWS IAM policies to limit SES permissions

### ❌ DON'T:
- Commit `.env` to git (it's already in `.gitignore`)
- Share your SMTP credentials in chat or email
- Use production credentials in development
- Hardcode credentials in your code

## Troubleshooting

### "Amazon SES SMTP credentials not configured"

**Solution**: Make sure your `.env` file has:
```bash
SES_SMTP_USERNAME=your-username
SES_SMTP_PASSWORD=your-password
```
Then restart the backend.

### "Authentication failed"

**Possible causes**:
1. Wrong username or password - double-check your credentials
2. Region mismatch - ensure SMTP host matches your SES region
3. Credentials not active - verify in AWS SES console

### "Connection timeout"

**Possible causes**:
1. Firewall blocking SMTP ports (587, 465, 2587)
2. Wrong SMTP host or region
3. Try alternative port (2587) if port 587 is blocked

### Emails not sending from SES

**Amazon SES Sandbox Limitations**:
- By default, SES is in "sandbox mode"
- Can only send to verified email addresses
- Limited to 200 emails per 24 hours
- **Solution**: Request production access from AWS SES console

**Verify Your Email Addresses**:
1. Go to AWS SES Console → "Verified Identities"
2. Add and verify your sender email addresses
3. Check spam folders if verification emails don't arrive

## Testing Your Configuration

### Test Environment Variables Loading

Create a simple test to verify your `.env` is loading:

```python
import os
from dotenv import load_dotenv

load_dotenv()

print("SES Host:", os.getenv('SES_SMTP_HOST'))
print("SES Port:", os.getenv('SES_SMTP_PORT'))
print("SES User:", os.getenv('SES_SMTP_USERNAME')[:5] + "***")  # Partial display for security
print("Credentials configured:", bool(os.getenv('SES_SMTP_USERNAME')))
```

### Test Sending a Single Email

Use the dashboard to create a test campaign:
1. Add one test email address (must be verified if in SES sandbox)
2. Select provider `ses`
3. Send the campaign
4. Check backend logs for success/error messages

## Additional Resources

- **AWS SES Documentation**: https://docs.aws.amazon.com/ses/
- **SES Sending Limits**: https://docs.aws.amazon.com/ses/latest/dg/quotas.html
- **Moving Out of Sandbox**: https://docs.aws.amazon.com/ses/latest/dg/request-production-access.html
- **SES SMTP Endpoints**: https://docs.aws.amazon.com/ses/latest/dg/smtp-connect.html

## Support

If you encounter issues:
1. Check the backend logs for detailed error messages
2. Verify all credentials in `.env` are correct
3. Ensure you've restarted the backend after changing `.env`
4. Check AWS SES console for sending statistics and errors
