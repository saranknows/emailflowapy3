# 🚀 Email Validator - Upload & Auto-Organize

## Three Ways to Validate Emails

### 1. 📤 **CLI Upload (NEW!)** - Automatic File Organization
Upload a CSV file and get organized results in folders

```bash
python validate_upload.py your_emails.csv
```

✨ **Results automatically organized into:**
- ✅ Deliverable emails
- ❌ Undeliverable emails  
- 🏢 Emails by provider (Microsoft, Google, Office365, etc.)
- 📊 Summary report
- 📄 Full CSV results

### 2. 🖥️ **Standalone Script** - Simple CLI Tool
Quick validation without any setup

```bash
python email_validator_standalone.py validate test@gmail.com
python email_validator_standalone.py bulk emails.csv
```

### 3. 🌐 **Full Web Application** - Complete Dashboard
React UI with user accounts and API

```bash
npm run dev  # Starts on http://localhost:5173
```

---

## 🎯 Quick Comparison

| Feature | CLI Upload | Standalone Script | Web App |
|---------|-----------|------------------|---------|
| **Setup** | 0 min | 0 min | 5-10 min |
| **Auto-organize results** | ✅ Yes | ❌ No | ✅ Yes |
| **Folder structure** | ✅ Yes | ❌ No | ❌ No |
| **CSV upload** | ✅ Yes | ✅ Yes | ✅ Yes |
| **User accounts** | ❌ No | ❌ No | ✅ Yes |
| **Web interface** | ❌ No | ❌ No | ✅ Yes |
| **Best for** | **Batch processing** | Quick checks | Teams |

---

## 📤 CLI Upload - Detailed Guide

### What Makes It Special?

When you upload a CSV file, it **automatically creates organized folders**:

```
validation_output/
└── 20251121_012040/
    ├── SUMMARY.txt                    # 📊 Quick overview
    ├── full_results.csv               # 📄 Complete data
    ├── by_status/
    │   ├── deliverable.txt           # ✅ Ready to use
    │   ├── undeliverable.txt         # ❌ Remove these
    │   └── invalid_format.txt        # ⚠️ Malformed
    └── by_provider/
        ├── microsoft_emails.txt      # Outlook, Hotmail
        ├── google_emails.txt         # Gmail
        ├── office365_emails.txt      # Business emails
        ├── godaddy_emails.txt        # GoDaddy
        └── unknown_emails.txt        # Others
```

### Usage Examples

**Basic Upload:**
```bash
python validate_upload.py customers.csv
```

**Custom Session Name:**
```bash
python validate_upload.py leads.csv --session-id q4_leads_2024
```

**Limit Emails:**
```bash
python validate_upload.py huge_list.csv --max-emails 5000
```

### Sample Output

```
============================================================
📧 EMAIL VALIDATOR - CLI MODE
============================================================

📂 Reading CSV file: customers.csv
✅ Found 1,234 emails

🔍 Validating emails...
✅ Validation complete!
   Total processed: 1,234
   New validations: 1,234
   From cache: 0

📁 Organizing results into folders...
✅ Results organized successfully!

============================================================
📊 VALIDATION SUMMARY
============================================================

Total Emails: 1,234
Valid Format: 1,180 (95%)
Deliverable: 1,050 (89%)
Undeliverable: 130

Provider Breakdown (Deliverable):
------------------------------------------------------------
  Microsoft       :   420 emails
  Google          :   380 emails
  Office365       :   150 emails
  Unknown         :   100 emails

============================================================
✨ Validation Complete!
============================================================
```

### What You Get

1. **deliverable.txt** - Import into your CRM
2. **microsoft_emails.txt** - Send via Microsoft routes
3. **google_emails.txt** - Send via Google routes
4. **SUMMARY.txt** - Share with your team
5. **full_results.csv** - Detailed analysis

---

## 🖥️ Standalone Script - Quick Reference

### Single Email
```bash
python email_validator_standalone.py validate admin@company.com
```

### Bulk CSV
```bash
python email_validator_standalone.py bulk contacts.csv
```

### Interactive Mode
```bash
python email_validator_standalone.py interactive
```

📖 **Full Guide:** [STANDALONE_README.md](STANDALONE_README.md)

---

## 🌐 Full Web Application

### Start Server
```bash
npm run dev
```

### Access
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- API Docs: http://localhost:5000/docs

### Features
- ✅ User authentication (1 billion credits per user)
- ✅ Real-time validation dashboard
- ✅ CSV upload via web interface
- ✅ Provider-specific downloads
- ✅ Validation history
- ✅ Rate limiting (60 req/min)

📖 **Full Guide:** [replit.md](replit.md)

---

## 📋 CSV File Format

All three methods support any CSV format:

**Simple List:**
```csv
john@example.com
jane@gmail.com
```

**With Headers:**
```csv
Name,Email,Phone
John,john@example.com,555-1234
```

**Multiple Columns:**
```csv
First,Last,Email,Company
John,Doe,john@acme.com,Acme Corp
```

The system auto-detects emails!

---

## ✨ Features (All Methods)

### Validation
- ✅ Email format validation
- ✅ MX record DNS lookup
- ✅ Deliverability check
- ✅ Performance timing

### Provider Detection
- ✅ Microsoft (Outlook, Hotmail, Live)
- ✅ Google (Gmail, Google Workspace)
- ✅ Office365 (Business emails)
- ✅ GoDaddy
- ✅ Mimecast
- ✅ ARSMTP

### Processing
- ✅ Bulk CSV (up to 10,000 emails)
- ✅ Duplicate detection
- ✅ Automatic caching
- ✅ Export results

---

## 🎯 Choose Your Method

### Use **CLI Upload** if you:
- ✅ Want organized output folders
- ✅ Process batches regularly
- ✅ Need provider segmentation
- ✅ Want clean file structure
- **→ Best for data processing**

### Use **Standalone Script** if you:
- ✅ Need quick validation
- ✅ Want simple output
- ✅ Integrate into scripts
- ✅ Prefer minimal dependencies
- **→ Best for quick checks**

### Use **Web App** if you:
- ✅ Have multiple users
- ✅ Want web interface
- ✅ Need user accounts
- ✅ Want API access
- **→ Best for teams**

---

## 📚 Documentation

- **[UPLOAD_VALIDATION_GUIDE.md](UPLOAD_VALIDATION_GUIDE.md)** - CLI upload complete guide
- **[STANDALONE_README.md](STANDALONE_README.md)** - Standalone script guide
- **[STANDALONE_INSTALL.md](STANDALONE_INSTALL.md)** - Installation methods
- **[STANDALONE_COMPARISON.md](STANDALONE_COMPARISON.md)** - Feature comparison
- **[QUICK_START.md](QUICK_START.md)** - 30-second guide
- **[replit.md](replit.md)** - Full web app architecture

---

## 🚀 Getting Started

### Option 1: CLI Upload (Recommended)

```bash
# 1. Download or clone
git clone <your-repo>

# 2. Upload and validate
python validate_upload.py your_emails.csv

# 3. Check results
ls validation_output/
```

### Option 2: Standalone Script

```bash
# 1. Download script
curl -O email_validator_standalone.py

# 2. Validate
python email_validator_standalone.py bulk emails.csv
```

### Option 3: Web Application

```bash
# 1. Clone and install
git clone <your-repo>
npm install

# 2. Start server
npm run dev

# 3. Open browser
open http://localhost:5173
```

---

## 📦 Requirements

### CLI Upload & Standalone
- Python 3.7+
- (Optional) dnspython for better DNS lookups

### Web Application
- Python 3.11+
- Node.js 20+
- PostgreSQL database

---

## 💡 Pro Tips

1. **Start with CLI Upload** for batch processing
2. **Use Standalone** for quick checks
3. **Deploy Web App** when you need multi-user access
4. **Organize by provider** for targeted email campaigns
5. **Check SUMMARY.txt** for quick insights

---

## 🎁 What's New?

### ✨ CLI Upload Feature (Latest)
- **Auto-organized folders** by provider and status
- **Summary reports** for quick insights
- **Clean file structure** for easy access
- **Provider segmentation** built-in

### Previous Updates
- Standalone Python script (zero dependencies)
- Provider detection (6 major providers)
- Bulk CSV processing (10,000 emails)
- Web application with authentication

---

## 🔍 Example Workflow

```bash
# 1. Upload and validate
python validate_upload.py customer_list.csv --session-id customers_nov

# 2. Check summary
cat validation_output/customers_nov/SUMMARY.txt

# 3. Import deliverable emails
# → Use validation_output/customers_nov/by_status/deliverable.txt

# 4. Send targeted campaigns
# → Microsoft: validation_output/customers_nov/by_provider/microsoft_emails.txt
# → Google: validation_output/customers_nov/by_provider/google_emails.txt
```

---

## 🤝 Support

- 📖 **Documentation**: See guides above
- 🐛 **Issues**: GitHub Issues
- 💬 **Questions**: Check documentation first

---

**Choose your validation method and start cleaning your email lists!** 📧✨
