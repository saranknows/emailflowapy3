# Link Configuration Guide

## Overview
The Email Marketing Platform supports **8 different link types** with automatic rotation capabilities. Each link type uses a dedicated placeholder in your email templates and rotates through URLs from uploaded `.txt` files. This guide explains how to configure, upload, and use all link types in your campaigns.

---

## Supported Link Types

| Link Type | Placeholder | File Name | Use Case |
|-----------|-------------|-----------|----------|
| **LINK** | `{{link}}` | `main_links.txt` | Main call-to-action links |
| **GOOGLE REDIRECTLINK** | `{{google_redirect}}` | `google_redirect_links.txt` | Google redirect tracking URLs |
| **OAUTH2URL** | `{{oauth2url}}` | `oauth2_urls.txt` | OAuth2 authentication links |
| **GOOGLESITESURL** | `{{googlesitesurl}}` | `google_sites_urls.txt` | Google Sites page URLs |
| **ROTATION_LINK** | `{{rotation_link}}` | `rotation_links.txt` | General rotating links |
| **DEFAULT_LINK** | `{{default_link}}` | `default_links.txt` | Default fallback links |
| **URLQR** | `{{urlqr}}` | `urlqr_links.txt` | QR code destination URLs |
| **DYNAMICS** | `{{dynamics}}` | `dynamics_links.txt` | Microsoft Dynamics CRM links |

---

## How Link Rotation Works

### Automatic Rotation Process
```
Email #1 → Uses first URL from each file
Email #2 → Uses second URL from each file
Email #3 → Uses third URL from each file
...
Email #N → Cycles back to first URL when list exhausted
```

### Processing Order in Campaigns
```
1. Load template
2. Replace {{link}} placeholders    ← Links processed FIRST
3. Replace {{COMPANYLOGO}}           ← Company logo SECOND
4. Generate QR codes (if enabled)    ← QR codes THIRD
5. Convert to image (if enabled)     ← HTML-to-image LAST
6. Send email
```

---

## Upload Link Files via Campaign Dashboard

### Step-by-Step Instructions

1. **Open Campaign Dashboard**
   - Navigate to the "Campaigns" page
   - Click the **"Manage Links"** button (purple button, top right)

2. **View Link Files Status**
   - See all 8 link types in a grid layout
   - Check status: ✓ Uploaded (green) or ✗ Not uploaded (red)
   - View link count and preview of first 5 URLs

3. **Upload a Link File**
   - Click **"Upload"** button for the desired link type
   - Select a `.txt` file from your computer
   - File format: One URL per line (see format section below)
   - Click "Open" to upload

4. **Replace Existing File**
   - Click **"Replace"** button (yellow) to update existing file
   - Upload new `.txt` file
   - Old file is overwritten

5. **Delete Link File**
   - Click the **trash icon** (🗑️) next to a link type
   - Confirm deletion
   - Link file is removed

---

## Link File Format

### Basic Format
Each `.txt` file should contain **one URL per line**:

```
https://example.com/page1
https://example.com/page2
https://example.com/page3
https://example.com/page4
https://example.com/page5
```

### Rules
- ✅ One URL per line
- ✅ Include full URLs with `http://` or `https://`
- ✅ Any number of URLs (minimum: 1)
- ✅ Blank lines are ignored
- ❌ No commas or semicolons
- ❌ No headers or comments

---

## Usage in Email Templates

### Example Template with All Link Types

```html
<!DOCTYPE html>
<html>
<head>
  <title>Email Campaign</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 20px;">
  
  <!-- Header -->
  <h1>Special Offer!</h1>
  
  <!-- Main CTA Button -->
  <a href="{{link}}" 
     style="display: inline-block; padding: 15px 30px; 
            background-color: #007bff; color: #ffffff; 
            text-decoration: none; border-radius: 5px;">
    Claim Your Offer Now!
  </a>
  
  <!-- Google Redirect Link -->
  <p>Track your click: <a href="{{google_redirect}}">Click here</a></p>
  
  <!-- OAuth2 Login Link -->
  <p>Login with OAuth2: <a href="{{oauth2url}}">Secure Login</a></p>
  
  <!-- Google Sites Link -->
  <p>View our site: <a href="{{googlesitesurl}}">Visit Page</a></p>
  
  <!-- Rotating Link -->
  <p>More info: <a href="{{rotation_link}}">Learn More</a></p>
  
  <!-- Default Link -->
  <p>Homepage: <a href="{{default_link}}">Go to Homepage</a></p>
  
  <!-- QR Code Link (for QR code destination) -->
  <p>Scan QR to visit: <a href="{{urlqr}}">QR Destination</a></p>
  
  <!-- Dynamics CRM Link -->
  <p>Customer Portal: <a href="{{dynamics}}">Access Portal</a></p>
  
  <!-- Footer -->
  <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
    <p style="font-size: 12px; color: #666;">
      <a href="{{link}}" style="color: #666;">Unsubscribe</a> | 
      <a href="{{default_link}}" style="color: #666;">Privacy Policy</a>
    </p>
  </div>
  
</body>
</html>
```

### Output After Replacement

When sending to recipients, placeholders are replaced with actual URLs:

```html
<!-- Before -->
<a href="{{link}}">Claim Offer</a>

<!-- After (Email #1) -->
<a href="https://example.com/offer1">Claim Offer</a>

<!-- After (Email #2) -->
<a href="https://example.com/offer2">Claim Offer</a>

<!-- After (Email #3) -->
<a href="https://example.com/offer3">Claim Offer</a>
```

---

## Link Type Use Cases

### 1. LINK (`{{link}}`)
**Purpose:** Main call-to-action links  
**File:** `main_links.txt`  
**Example URLs:**
```
https://example.com/offer1
https://example.com/offer2
https://example.com/special-deal
```

**Use in template:**
```html
<a href="{{link}}" style="background: #007bff; color: white; padding: 15px 30px;">
  Get Started Now!
</a>
```

---

### 2. GOOGLE REDIRECTLINK (`{{google_redirect}}`)
**Purpose:** Google redirect URLs for tracking  
**File:** `google_redirect_links.txt`  
**Example URLs:**
```
https://www.google.com/url?q=https://example.com&source=gmail
https://www.google.com/url?q=https://example.com/page2&source=gmail
```

**Use in template:**
```html
<a href="{{google_redirect}}">Track your click</a>
```

---

### 3. OAUTH2URL (`{{oauth2url}}`)
**Purpose:** OAuth2 authentication links  
**File:** `oauth2_urls.txt`  
**Example URLs:**
```
https://accounts.google.com/o/oauth2/auth?client_id=123
https://login.microsoftonline.com/oauth2/authorize
https://github.com/login/oauth/authorize
```

**Use in template:**
```html
<a href="{{oauth2url}}">Login with OAuth2</a>
```

---

### 4. GOOGLESITESURL (`{{googlesitesurl}}`)
**Purpose:** Google Sites page URLs  
**File:** `google_sites_urls.txt`  
**Example URLs:**
```
https://sites.google.com/view/mysite/page1
https://sites.google.com/view/mysite/page2
https://sites.google.com/d/1234567890/p/9876543210
```

**Use in template:**
```html
<a href="{{googlesitesurl}}">Visit Our Google Site</a>
```

---

### 5. ROTATION_LINK (`{{rotation_link}}`)
**Purpose:** General purpose rotating links  
**File:** `rotation_links.txt`  
**Example URLs:**
```
https://example.com/product-a
https://example.com/product-b
https://example.com/product-c
```

**Use in template:**
```html
<a href="{{rotation_link}}">View Product</a>
```

---

### 6. DEFAULT_LINK (`{{default_link}}`)
**Purpose:** Default fallback links (homepage, privacy, etc.)  
**File:** `default_links.txt`  
**Example URLs:**
```
https://example.com
https://example.com/privacy
https://example.com/terms
```

**Use in template:**
```html
<a href="{{default_link}}">Visit Homepage</a>
```

---

### 7. URLQR (`{{urlqr}}`)
**Purpose:** QR code destination URLs  
**File:** `urlqr_links.txt`  
**Example URLs:**
```
https://example.com/qr-landing
https://example.com/mobile-app
https://example.com/scan-reward
```

**Use in template:**
```html
<p>Scan QR code to visit: <a href="{{urlqr}}">Mobile Page</a></p>
```

**Note:** This is different from QR code generation. Use this when you want a clickable link to the QR code's destination URL.

---

### 8. DYNAMICS (`{{dynamics}}`)
**Purpose:** Microsoft Dynamics 365 CRM links  
**File:** `dynamics_links.txt`  
**Example URLs:**
```
https://org.crm.dynamics.com/main.aspx?pagetype=entityrecord
https://org.crm.dynamics.com/api/data/v9.0/contacts
https://org.crm4.dynamics.com/portal/login
```

**Use in template:**
```html
<a href="{{dynamics}}">Access Customer Portal</a>
```

---

## API Endpoints Reference

### Get All Link Files
```
GET /api/links
```

**Response:**
```json
[
  {
    "name": "main_links.txt",
    "type": "LINK",
    "placeholder": "{{link}}",
    "count": 10,
    "preview": ["https://example.com/1", "https://example.com/2"],
    "exists": true
  },
  {
    "name": "google_redirect_links.txt",
    "type": "GOOGLE_REDIRECTLINK",
    "placeholder": "{{google_redirect}}",
    "count": 0,
    "preview": [],
    "exists": false
  }
]
```

### Upload Link File
```
POST /api/links/upload
Content-Type: multipart/form-data

file: <file.txt>
link_type: main_links
```

**Response:**
```json
{
  "success": true,
  "message": "main_links.txt uploaded",
  "filename": "main_links.txt"
}
```

### Get Specific Link File
```
GET /api/links/main_links.txt
```

**Response:**
```json
{
  "name": "main_links.txt",
  "content": "https://example.com/1\nhttps://example.com/2\n"
}
```

### Delete Link File
```
DELETE /api/links/main_links.txt
```

**Response:**
```json
{
  "success": true,
  "message": "main_links.txt deleted"
}
```

---

## Best Practices

### 1. Link Quantity
- **Minimum:** 1 URL per file
- **Recommended:** 10-50 URLs per file for good rotation
- **Maximum:** No limit (but keep files manageable)

### 2. URL Quality
- ✅ Use HTTPS for security
- ✅ Test all URLs before uploading
- ✅ Keep URLs active and working
- ✅ Use tracking parameters if needed

### 3. Organization
- 📁 Keep link files organized by campaign type
- 📁 Use descriptive URLs for easy identification
- 📁 Update files regularly to remove dead links

### 4. Rotation Strategy
- 🔄 Upload more URLs than expected recipients for true randomness
- 🔄 Replace files when starting new campaigns
- 🔄 Monitor which URLs perform best

---

## Integration with Other Features

### Works With HTML-to-Image
```
1. Template loaded with {{link}} placeholder
2. Link replaced with actual URL
3. HTML converted to PNG image
4. Link becomes part of clickable image
```

**Result:** The entire image is clickable with the rotated URL.

### Works With QR Codes
```
1. QR code generated with data from campaign
2. Link placeholders in template replaced
3. Both QR code and links present in email
```

**Use case:** QR code for mobile scanning, `{{urlqr}}` for desktop clicking.

### Works With Company Logo
```
1. Links replaced first
2. Company logo fetched and inserted
3. All placeholders processed
4. Final email sent
```

**Order matters:** Links → Logo → QR → Image → Send

---

## Troubleshooting

### Problem: Links not rotating
**Solution:** Check that:
- Link file is uploaded (check "Manage Links" panel)
- File contains multiple URLs
- URLs are one per line
- Placeholder matches exactly (case-insensitive)

### Problem: File upload fails
**Solution:** Verify:
- File is `.txt` format
- File size is reasonable (< 10 MB)
- URLs are valid format
- No special characters in URLs

### Problem: Wrong URLs appearing
**Solution:**
- Clear browser cache
- Re-upload link file
- Check file contents in "Manage Links" panel
- Verify placeholder spelling in template

### Problem: Default fallback URLs showing
**Solution:**
- This happens when link file doesn't exist
- Upload the corresponding `.txt` file
- Default: `https://example.com/{link_type}`

---

## Example Campaign Workflow

### Step 1: Prepare Link Files
Create `main_links.txt`:
```
https://example.com/offer1
https://example.com/offer2
https://example.com/offer3
```

Create `google_redirect_links.txt`:
```
https://www.google.com/url?q=https://example.com&source=gmail
https://www.google.com/url?q=https://example.com/page2&source=gmail
```

### Step 2: Upload to Dashboard
1. Go to Campaigns page
2. Click "Manage Links"
3. Upload `main_links.txt` → LINK type
4. Upload `google_redirect_links.txt` → GOOGLE REDIRECTLINK type

### Step 3: Create Template
```html
<a href="{{link}}">Click here!</a>
<a href="{{google_redirect}}">Track click</a>
```

### Step 4: Create Campaign
- Select your template
- Configure campaign settings
- Send campaign

### Step 5: Results
- Email #1: Uses offer1 + google redirect URL #1
- Email #2: Uses offer2 + google redirect URL #2
- Email #3: Uses offer3 + google redirect URL #1 (cycles back)

---

## Technical Implementation

### Backend Processing
```python
# Load link files
links_data = load_link_files()

# For each email recipient
for recipient in recipients:
    # Process link placeholders
    html = process_link_placeholders(template, links_data)
    
    # Replace {{link}} → https://example.com/offer1
    # Replace {{google_redirect}} → https://google.com/url?q=...
    # etc.
    
    send_email(recipient, html)
```

### Link Rotation Logic
```python
# Uses itertools.cycle for automatic rotation
from itertools import cycle

link_cycle = cycle(["url1", "url2", "url3"])

# First call: url1
# Second call: url2
# Third call: url3
# Fourth call: url1 (cycles back)
```

---

## Summary

✅ **8 link types supported:** LINK, GOOGLE REDIRECTLINK, OAUTH2URL, GOOGLESITESURL, ROTATION_LINK, DEFAULT_LINK, URLQR, DYNAMICS  
✅ **Automatic rotation:** Links cycle through uploaded URLs  
✅ **Easy management:** Upload, replace, delete via Campaign Dashboard  
✅ **File format:** Simple `.txt` files with one URL per line  
✅ **Template usage:** Use placeholders like `{{link}}`, `{{google_redirect}}`, etc.  
✅ **Integration:** Works with HTML-to-image, QR codes, and company logo features  

---

**Last Updated:** November 22, 2025  
**Feature:** Comprehensive Link Configuration System  
**Status:** Active ✅
