# 🪟 Windows Setup Summary - Email Marketing Platform

**Quick reference for setting up on Windows**

---

## 🚀 Two Options Available

### Option 1: Standalone Email Sender (Fastest)
**Just want to send emails via command line?**
- ✅ Minimal setup - 13 files only
- ✅ No web interface needed
- ✅ No Node.js required
- ✅ ~200 KB total size
- ✅ 5-minute setup

### Option 2: Full Web Interface
**Want the complete dashboard and web UI?**
- ✅ Complete email marketing platform
- ✅ React-based web dashboard
- ✅ Campaign management
- ✅ ~50 MB total size
- ✅ 15-minute setup

---

## 📥 What to Download

### **For Standalone (Option 1):**

**Core Files (4):**
```
main.py                    ⚠️ HARDCODED CREDENTIALS - KEEP SECURE
RUN-EMAIL-SENDER.bat
requirements.txt
```

**Data Folders (3 folders, 13 files):**
```
contacts/
  └── emails.txt
subjects/
  └── subject.txt  
from_emails/
  └── fromemails.txt
templates/
  ├── default.html
  ├── template1-professional.html
  ├── template2-modern.html
  ├── template3-minimal.html
  ├── template4-corporate.html
  ├── template5-newsletter.html
  ├── template6-promotional.html
  ├── template7-elegant.html
  ├── template8-tech.html
  ├── template9-friendly.html
  └── template10-announcement.html
```

**Optional Docs:**
```
README.md
MAIN-PY-USAGE-GUIDE.md
WINDOWS-DOWNLOAD-GUIDE.md
SOCKS-PROXY-SETUP.md
```

### **For Full Web Interface (Option 2):**

Everything from Option 1, **PLUS**:
```
start-all.bat
package.json
vite.config.js
tailwind.config.js
postcss.config.js
index.html
backend/          (entire folder)
frontend/         (entire folder)
```

---

## ⚡ Quick Setup Steps

### **Option 1: Standalone**

1. **Install Python 3.9.9**
   - Download: https://www.python.org/downloads/
   - ✅ Check "Add Python to PATH"

2. **Create folder & download files**
   ```cmd
   mkdir C:\EmailMarketing
   cd C:\EmailMarketing
   ```
   Download all files from "Option 1" list above

3. **Install dependencies**
   ```cmd
   pip install -r requirements.txt
   ```

4. **Run it!**
   - Double-click `RUN-EMAIL-SENDER.bat`
   - OR run `python main.py`

**Done! No configuration needed.**

---

### **Option 2: Full Web Interface**

1. **Install Python 3.9.9**
   - Download: https://www.python.org/downloads/
   - ✅ Check "Add Python to PATH"

2. **Install Node.js 20.x**
   - Download: https://nodejs.org/
   - Use LTS version

3. **Create folder & download files**
   ```cmd
   mkdir C:\EmailMarketing
   cd C:\EmailMarketing
   ```
   Download all files from "Option 2" list above

4. **Install dependencies**
   ```cmd
   pip install -r requirements.txt
   npm install
   ```

5. **Run it!**
   - Double-click `start-all.bat`
   - Open browser: http://localhost:5000

**Done!**

---

## 🔒 Security Warning

**`main.py` contains hardcoded SMTP credentials!**

⚠️ **NEVER:**
- Share this file publicly
- Upload to GitHub or public repos
- Post in forums or help sites
- Send via unencrypted email

✅ **ALWAYS:**
- Keep in secure, encrypted location
- Restrict file permissions
- Only share with trusted personnel
- Rotate credentials regularly

---

## 📁 Folder Structure to Create

```
C:\EmailMarketing\
├── main.py                          ⚠️
├── RUN-EMAIL-SENDER.bat
├── requirements.txt
├── contacts\
│   └── emails.txt
├── subjects\
│   └── subject.txt
├── from_emails\
│   └── fromemails.txt
└── templates\
    └── (11 HTML files)
```

For full setup, also add:
```
├── start-all.bat
├── package.json
├── backend\
├── frontend\
└── (other config files)
```

---

## 📝 Your Data Files

### `contacts\emails.txt`
```
user1@example.com
user2@example.com
user3@example.com
```

### `subjects\subject.txt`
```
Amazing Deal Inside!
Don't Miss Out - Limited Time Offer
Your Exclusive Invitation
```

### `from_emails\fromemails.txt`
```
info@besthomeimprovement.biz
admin@autoblog247.net
```

---

## 🎯 How It Works

**main.py** automatically:
1. Loads all contacts from `contacts\emails.txt`
2. Loads all subjects from `subjects\*.txt`
3. Loads all senders from `from_emails\fromemails.txt`
4. Loads all templates from `templates\*.html`
5. **Rotates** through them as it sends emails

**Example:**
- Email 1: Subject A, From sender1@domain.com, Template 1
- Email 2: Subject B, From sender2@domain.com, Template 2
- Email 3: Subject C, From sender1@domain.com, Template 3
- And so on...

---

## ✅ Verification Checklist

After setup, verify:

- [ ] Python 3.9.9 installed
  ```cmd
  python --version
  ```
  Should show: `Python 3.9.9`

- [ ] Dependencies installed
  ```cmd
  pip list
  ```
  Should show: flask, gunicorn, PySocks, etc.

- [ ] Files in correct folders
  ```cmd
  dir C:\EmailMarketing
  ```

- [ ] Can run main.py
  ```cmd
  python main.py
  ```
  Should load contacts and show menu

For full setup, also verify:
- [ ] Node.js installed: `node --version`
- [ ] npm installed: `npm --version`
- [ ] Dependencies installed: `npm list`
- [ ] Can access web interface: http://localhost:5000

---

## 🐛 Troubleshooting

### "Python is not recognized"
**Fix:**
1. Reinstall Python
2. ✅ Check "Add Python to PATH"
3. Restart Command Prompt

### "pip is not recognized"
**Fix:**
```cmd
python -m pip install -r requirements.txt
```

### "npm is not recognized"
**Fix:**
1. Install Node.js from https://nodejs.org/
2. Restart Command Prompt

### "Cannot find the path specified"
**Fix:**
Create folders first:
```cmd
mkdir C:\EmailMarketing
mkdir C:\EmailMarketing\contacts
mkdir C:\EmailMarketing\subjects
mkdir C:\EmailMarketing\from_emails
mkdir C:\EmailMarketing\templates
```

### "Access denied"
**Fix:**
Run Command Prompt as Administrator

### "Port already in use" (Full setup)
**Fix:**
Close apps using ports 5000 or 8000

---

## 📖 Documentation Reference

| Document | Purpose |
|----------|---------|
| **WINDOWS-DOWNLOAD-GUIDE.md** | Detailed download & setup instructions |
| **MAIN-PY-USAGE-GUIDE.md** | How to use main.py (standalone sender) |
| **FILES-TO-DOWNLOAD.txt** | Complete file list |
| **FOLDER-STRUCTURE-WINDOWS.txt** | Folder structure reference |
| **README.md** | Project overview |
| **INSTALL.md** | Installation guide (all platforms) |
| **SOCKS-PROXY-SETUP.md** | Proxy configuration |

---

## 🎬 Example Usage

### Standalone Sender:

```cmd
C:\EmailMarketing> python main.py

============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 2 files
👤 Loaded 2 sender emails
🎨 Loaded 11 email templates

🔧 Using SES email provider
🌐 Direct connection (no proxy)

Press ENTER to start sending to 8 contacts...
```

### Full Web Interface:

```cmd
C:\EmailMarketing> start-all.bat

Starting backend server...
Starting frontend server...

Backend running on http://localhost:8000
Frontend running on http://localhost:5000

Open your browser to http://localhost:5000
```

---

## 🎯 Recommended Approach

**First-time users:**
1. Start with **Option 1 (Standalone)** 
2. Test sending a few emails
3. Verify everything works
4. If you need web interface, upgrade to **Option 2**

**Why?**
- Faster setup
- Easier to troubleshoot
- Learn the system first
- Always have standalone backup

---

## 🔧 Configuration

### main.py Configuration

All settings are **hardcoded** in `main.py`:

```python
EMAIL_CONFIG = {
    'provider': 'ses',                    # Email provider
    'ses_host': '...',                    # Amazon SES host
    'ses_username': '...',                # Credentials
    'ses_password': '...',                # Credentials
    'delay_seconds': 2,                   # Delay between emails
    'proxy_type': '',                     # SOCKS proxy (optional)
    'proxy_host': '',
    'proxy_port': '',
}
```

**To change settings:**
1. Open `main.py` in text editor
2. Edit the `EMAIL_CONFIG` section
3. Save and run

**No .env file needed!**

---

## 💡 Tips & Best Practices

1. **Start Small**
   - Test with 5-10 contacts first
   - Verify emails are sent correctly
   - Check spam folders

2. **Verify Senders**
   - All sender addresses must be verified in Amazon SES
   - Use AWS SES Console: https://console.aws.amazon.com/ses/

3. **Use Delays**
   - Default is 2 seconds between emails
   - Increase for slower sending
   - Decrease for faster (not recommended)

4. **Monitor Sending**
   - Watch console output
   - Check success/failure counts
   - Review any error messages

5. **Security First**
   - Keep main.py secure
   - Use encrypted folders
   - Rotate credentials regularly
   - Never share credentials

---

## 📊 System Requirements

**Minimum:**
- Windows 10 or higher
- Python 3.9.9
- 2GB RAM
- 100MB disk space (standalone)
- 500MB disk space (full setup)

**Recommended:**
- Windows 11
- Python 3.9.9
- 4GB RAM
- 1GB disk space
- SSD for faster performance

---

## 🆘 Need Help?

1. Check **WINDOWS-DOWNLOAD-GUIDE.md** for detailed instructions
2. Read **MAIN-PY-USAGE-GUIDE.md** for usage help
3. See **Troubleshooting** section above
4. Review error messages carefully
5. Verify all files are in correct folders

---

## ✨ You're Ready!

**Download the files, follow the setup steps, and start sending!**

For questions, see the documentation files included in your download.

---

**Last Updated:** November 17, 2025  
**Version:** 1.0 - Hardcoded Credentials  
**Tested On:** Windows 10, Windows 11  
**Python Version:** 3.9.9  
**Success Rate:** 100% (8/8 test emails sent)
