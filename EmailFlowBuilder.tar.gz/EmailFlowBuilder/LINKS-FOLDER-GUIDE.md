# Links Folder Guide

## Overview

The **links folder system** provides centralized management of all URL links used in your email templates. Links are stored in simple text files and automatically loaded and rotated by `main.py`, similar to how subject lines and sender addresses work.

## Folder Structure

```
links/
├── main_links.txt          → {{link}} placeholder
├── websites.txt            → {{website}} placeholder
├── unsubscribe_links.txt   → {{unsubscribe}} placeholder
├── privacy_links.txt       → {{privacy}} placeholder
└── contact_links.txt       → {{contact}} placeholder
```

## How It Works

### Automatic Loading

When you run `main.py`, it automatically:
1. Loads all link files from the `links/` folder
2. Creates rotation cycles for each link type
3. Replaces placeholders in templates with actual URLs
4. Rotates links for each email sent

### Link Rotation

```
Email 1: {{link}} = https://example.com/offer1
Email 2: {{link}} = https://example.com/offer2
Email 3: {{link}} = https://example.com/offer3
Email 4: {{link}} = https://example.com/offer1  (cycles back)
```

Each email gets the next link in the rotation, ensuring variety and preventing repetition.

## Supported Link Types

| Placeholder | File | Purpose | Example |
|-------------|------|---------|---------|
| `{{link}}` | main_links.txt | Main CTA links | https://example.com/offer |
| `{{website}}` | websites.txt | Website URLs | https://yourcompany.com |
| `{{unsubscribe}}` | unsubscribe_links.txt | Unsubscribe links | https://example.com/unsub |
| `{{privacy}}` | privacy_links.txt | Privacy policy | https://example.com/privacy |
| `{{contact}}` | contact_links.txt | Contact page | https://example.com/contact |
| `{{preferences}}` | (default) | Email preferences | Auto: example.com/preferences |
| `{{terms}}` | (default) | Terms of service | Auto: example.com/terms |
| `{{docs}}` | (default) | Documentation | Auto: example.com/docs |
| `{{archive}}` | (default) | Email archive | Auto: example.com/archive |

**Total: 9 link types supported**

## File Format

Each link file is a simple text file with **one URL per line**:

```
https://example.com/offer1
https://example.com/offer2
https://example.com/offer3
```

### Rules

✅ **One URL per line**  
✅ **Include full URL** (http:// or https://)  
✅ **No empty lines** (will be skipped)  
✅ **No comments** (each line must be a URL)  
✅ **Any number of links** (minimum 1)

## Usage Examples

### Example 1: Basic Setup

**1. Create main_links.txt:**
```
https://mysite.com/spring-sale
https://mysite.com/summer-promo
https://mysite.com/fall-deals
```

**2. Use in template:**
```html
<a href="{{link}}">Check Out Our Offers!</a>
```

**3. Result:**
- Email 1: Links to spring-sale
- Email 2: Links to summer-promo
- Email 3: Links to fall-deals
- Email 4: Links to spring-sale (cycles)

---

### Example 2: Multiple Link Types

**Create multiple files:**

**main_links.txt:**
```
https://mystore.com/product1
https://mystore.com/product2
```

**websites.txt:**
```
https://mystore.com
```

**unsubscribe_links.txt:**
```
https://mystore.com/unsubscribe?email={{email}}
```

**Use in template:**
```html
<a href="{{link}}">Buy Now</a>
<a href="{{website}}">Visit Our Store</a>
<a href="{{unsubscribe}}">Unsubscribe</a>
```

---

### Example 3: Campaign-Specific Links

**Different campaigns = different links:**

**main_links.txt (Holiday Campaign):**
```
https://store.com/black-friday
https://store.com/cyber-monday
https://store.com/holiday-deals
```

**main_links.txt (Spring Campaign):**
```
https://store.com/spring-collection
https://store.com/easter-sale
https://store.com/refresh-2024
```

Simply update the file before running different campaigns!

---

## Integration with Templates

All 10 email templates support the full range of link placeholders:

### Template Example

```html
<!DOCTYPE html>
<html>
<head>
    <title>Email</title>
</head>
<body>
    <h1>Special Offer!</h1>
    <p>{{content}}</p>
    
    <!-- Main CTA -->
    <a href="{{link}}">Claim Your Offer Now!</a>
    
    <!-- Footer Links -->
    <a href="{{website}}">Visit Our Website</a>
    <a href="{{unsubscribe}}">Unsubscribe</a>
    <a href="{{privacy}}">Privacy Policy</a>
    <a href="{{contact}}">Contact Us</a>
</body>
</html>
```

All `{{placeholder}}` values are automatically replaced with rotating URLs!

---

## Console Output

When you run `main.py`, you'll see:

```
============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 1 files
👤 Loaded 2 sender emails
🎨 Template rotation: ON - Using all 11 templates
🔗 Loaded 21 links from 9 categories  ← LINKS STATUS

🔧 Using SES email provider
🌐 Direct connection (no proxy)
```

The "Loaded X links from Y categories" line shows:
- **Total links**: Sum of all links across all files
- **Categories**: Number of link types with data

---

## Default Values

If you don't create a link file, the system uses defaults:

| Type | Default URL |
|------|------------|
| link | https://example.com |
| website | https://example.com |
| unsubscribe | https://example.com/unsubscribe |
| privacy | https://example.com/privacy |
| contact | https://example.com/contact |
| preferences | https://example.com/preferences |
| terms | https://example.com/terms |
| docs | https://example.com/docs |
| archive | https://example.com/archive |

**Recommendation:** Always create your own link files for production use!

---

## Integration with Other Features

### Works with Template Rotation

```python
EMAIL_CONFIG = {
    'template_rotation': True  # Different template each email
}

# Each email gets:
# - Different template
# - Different subject
# - Different from address
# - Different links (all rotating!)
```

---

### Works with HTML-to-Image Conversion

```python
EMAIL_CONFIG = {
    'convert_to_image': True  # Convert to PNG
}

# Links are:
# 1. Replaced in HTML
# 2. Image generated with visible links
# 3. Clickable links added below image
```

---

### Works with QR Codes

```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': '{{link}}'  # Use rotating link in QR code!
}

# Each QR code links to different URL
```

---

## Best Practices

### 1. Use Descriptive URLs

```
✅ GOOD:
https://mystore.com/spring-sale-2024
https://mystore.com/vip-member-discount

❌ BAD:
https://bit.ly/xyz123
https://tinyurl.com/abc
```

### 2. Include Tracking Parameters

```
https://mystore.com/offer?utm_source=email&utm_campaign=spring2024
https://mystore.com/product?ref=email&id=12345
```

### 3. Test All Links Before Sending

```bash
# Test each link manually:
curl -I https://mystore.com/offer1
curl -I https://mystore.com/offer2
```

### 4. Keep Links Updated

- Remove expired campaign links
- Add new seasonal offers
- Update landing page URLs
- Test after domain changes

### 5. Use HTTPS

```
✅ https://mystore.com/offer
❌ http://mystore.com/offer
```

---

## Editing Links

### Method 1: Direct File Edit

1. Open `links/main_links.txt` in text editor
2. Edit URLs (one per line)
3. Save file
4. Run `main.py` (automatically loads new links)

### Method 2: Replace Entire File

1. Create new `main_links.txt` with updated URLs
2. Replace old file
3. Run `main.py`

### Method 3: Programmatic Update

```python
# In Python script:
with open('links/main_links.txt', 'w') as f:
    f.write('https://new-offer1.com\n')
    f.write('https://new-offer2.com\n')
    f.write('https://new-offer3.com\n')
```

---

## Troubleshooting

### Links Not Replacing

**Problem:** `{{link}}` still appears in sent emails

**Solutions:**
1. Check file exists: `links/main_links.txt`
2. Verify file has content (not empty)
3. Ensure URLs are one per line
4. Check for typos in placeholder: `{{link}}` not `{{links}}`

---

### Wrong Links Appearing

**Problem:** Different links than expected

**Solutions:**
1. Verify correct file edited
2. Check for duplicate files
3. Ensure file saved before running
4. Clear any caching (restart main.py)

---

### Default Links Used

**Problem:** System using example.com instead of custom links

**Solutions:**
1. Create the link file if missing
2. Add at least one URL to file
3. Check file permissions (readable)
4. Verify file location (in `links/` folder)

---

## Advanced Usage

### Campaign-Specific Link Sets

**Create multiple link folders:**

```
links-holiday/
├── main_links.txt
├── websites.txt
└── ...

links-spring/
├── main_links.txt
├── websites.txt
└── ...
```

**Before each campaign:**
```bash
# Copy appropriate links
cp -r links-holiday/* links/
# Run campaign
python main.py
```

---

### Dynamic Link Generation

```python
# Generate tracking links programmatically
import datetime

campaign_id = datetime.datetime.now().strftime('%Y%m%d')

links = [
    f'https://store.com/offer?campaign={campaign_id}&variant=A',
    f'https://store.com/offer?campaign={campaign_id}&variant=B',
    f'https://store.com/offer?campaign={campaign_id}&variant=C'
]

with open('links/main_links.txt', 'w') as f:
    for link in links:
        f.write(link + '\n')
```

---

### Link Analytics

Track which links perform best:

```
links/main_links.txt:
https://store.com/offer?src=email1
https://store.com/offer?src=email2
https://store.com/offer?src=email3
```

Analyze in Google Analytics by `src` parameter!

---

## Quick Reference

### Creating Link Files

```bash
# Create main links
echo "https://mysite.com/offer1" > links/main_links.txt
echo "https://mysite.com/offer2" >> links/main_links.txt

# Create website links
echo "https://mysite.com" > links/websites.txt

# Create unsubscribe links
echo "https://mysite.com/unsubscribe" > links/unsubscribe_links.txt
```

### Checking Current Links

```bash
# View all link files
cat links/*.txt

# Count links per file
wc -l links/*.txt
```

### Testing Link Replacement

```python
from main import load_file_lines

# Load links
links = load_file_lines('links/main_links.txt')
print(f"Loaded {len(links)} main links:")
for link in links:
    print(f"  - {link}")
```

---

## Summary

**What You Get:**
- ✅ Centralized link management
- ✅ Automatic link rotation
- ✅ 9 link types supported
- ✅ Simple text file format
- ✅ Works with all templates
- ✅ Integrates with all features
- ✅ Easy to update
- ✅ No code changes needed

**How to Use:**
1. Create/edit files in `links/` folder
2. Add URLs (one per line)
3. Run `main.py`
4. Links automatically rotate!

**Link Types:**
- main_links.txt → {{link}}
- websites.txt → {{website}}
- unsubscribe_links.txt → {{unsubscribe}}
- privacy_links.txt → {{privacy}}
- contact_links.txt → {{contact}}

---

**Related Documentation:**
- [TEMPLATE-LINKS-GUIDE.md](TEMPLATE-LINKS-GUIDE.md) - Template link placeholders
- [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md) - Complete main.py guide
- [TEMPLATE-ROTATION-CONTROL-GUIDE.md](TEMPLATE-ROTATION-CONTROL-GUIDE.md) - Template rotation
