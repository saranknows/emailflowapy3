# Email Marketing Platform - Environment Configuration

## Quick Start: Configure Amazon SES SMTP

### Step 1: Create .env File

Copy the example file:
```bash
cp .env.example .env
```

### Step 2: Add Your Amazon SES Credentials

Edit `.env` and add your credentials:

```bash
SES_SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SES_SMTP_PORT=587
SES_SMTP_USERNAME=your-ses-smtp-username
SES_SMTP_PASSWORD=your-ses-smtp-password
```

### Step 3: Restart Backend

Restart the backend workflow to load the new configuration.

### Step 4: Create a Campaign

When creating a campaign:
- Select provider: `ses`
- Leave SMTP settings blank - it will automatically use your `.env` credentials

## What Changed

✅ **Added python-dotenv** - Automatically loads `.env` file on startup
✅ **Environment variable defaults** - SES credentials from `.env` used as defaults
✅ **Flexible configuration** - Override per campaign if needed
✅ **Better security** - Credentials in `.env`, not in code
✅ **UTF-8 encoding fixed** - All file operations now use UTF-8 encoding

## Files Added

- `.env.example` - Template showing all available environment variables
- `ENV-SETUP-GUIDE.md` - Comprehensive setup and troubleshooting guide
- `README-ENV-CONFIG.md` - Quick start guide (this file)

## Priority System

Credentials are loaded in this order:
1. Campaign settings (highest priority)
2. Environment variables from `.env`
3. Default values (lowest priority)

This means you can set default credentials in `.env` and override per campaign when needed.

## Security

Your `.env` file is already in `.gitignore` and will never be committed to version control.

## Documentation

For detailed setup instructions, troubleshooting, and best practices, see:
- `ENV-SETUP-GUIDE.md` - Complete guide with AWS SES setup instructions
- `.env.example` - All available configuration options

## Testing

To verify your configuration works:
1. Add a test email to contacts (must be verified if in SES sandbox)
2. Create a campaign with provider `ses`
3. Send to one recipient
4. Check backend logs for success/error messages
