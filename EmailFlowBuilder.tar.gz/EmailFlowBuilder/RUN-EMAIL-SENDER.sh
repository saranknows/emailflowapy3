#!/bin/bash
# Email Marketing Platform - Quick Send Script
# Run this script to start sending emails

echo ""
echo "============================================================"
echo "   EMAIL MARKETING PLATFORM - Quick Sender"
echo "============================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.9+ first"
    exit 1
fi

# Run the email sender
python3 main.py
