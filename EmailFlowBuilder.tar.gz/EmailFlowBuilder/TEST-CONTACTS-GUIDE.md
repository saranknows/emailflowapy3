# Test Contacts & From Emails Guide

## Overview
This guide documents the 50 generic test contacts and 20 sender email addresses configured for inbox delivery testing across multiple email service providers.

---

## 📧 **Test Contacts (50 Total)**

### **Purpose**
Generic test email addresses across various email service providers to validate inbox delivery, spam filter performance, and antibot security effectiveness.

### **Email Service Distribution**

| Email Provider | Count | Examples |
|----------------|-------|----------|
| **Gmail** | 1 | john.smith@gmail.com |
| **Yahoo** | 2 | sarah.johnson@yahoo.com, kathleen.rogers@yahoo.com.br |
| **Outlook/Hotmail** | 2 | michael.brown@outlook.com, emily.davis@hotmail.com |
| **AOL** | 1 | david.wilson@aol.com |
| **ProtonMail** | 1 | jennifer.martinez@protonmail.com |
| **iCloud/Me** | 2 | james.anderson@icloud.com, thomas.robinson@me.com |
| **Mail.com** | 1 | lisa.taylor@mail.com |
| **GMX** | 1 | robert.thomas@gmx.com |
| **Zoho** | 1 | mary.jackson@zoho.com |
| **FastMail** | 1 | william.white@fastmail.com |
| **Yandex** | 1 | patricia.harris@yandex.com |
| **Tutanota** | 1 | charles.martin@tutanota.com |
| **Inbox.com** | 1 | barbara.thompson@inbox.com |
| **Live/MSN** | 2 | joseph.garcia@live.com, susan.martinez@msn.com |
| **Rediffmail** | 1 | jessica.clark@rediffmail.com |
| **Hushmail** | 1 | christopher.rodriguez@hushmail.com |
| **Mail.ru** | 1 | karen.lewis@mail.ru |
| **Asian Providers** (QQ, 163, Sina, etc.) | 5 | daniel.lee@qq.com, nancy.walker@163.com, etc. |
| **European Providers** (Libero, Wanadoo, Web.de, etc.) | 10 | sandra.hernandez@libero.it, steven.lopez@web.de, etc. |
| **Korean Providers** (Naver, Daum, Kakao) | 4 | jason.phillips@naver.com, sharon.campbell@daum.net, etc. |
| **Brazilian Providers** (UOL, BOL, Terra, etc.) | 5 | gary.edwards@uol.com.br, helen.collins@bol.com.br, etc. |

### **Geographic Coverage**

- 🇺🇸 **North America**: 15 contacts (Gmail, Yahoo, Outlook, AOL, etc.)
- 🇪🇺 **Europe**: 15 contacts (GMX, Libero, Orange, Web.de, etc.)
- 🇦🇸 **Asia**: 10 contacts (QQ, Naver, Daum, Kakao, etc.)
- 🇧🇷 **South America**: 5 contacts (UOL, BOL, Terra, Globo, etc.)
- 🌍 **Global/Secure**: 5 contacts (ProtonMail, Tutanota, Hushmail, etc.)

---

## 📤 **From Email Addresses (20 Total)**

### **Domain 1: besthomeimprovement.biz (10 addresses)**

```
info@besthomeimprovement.biz
support@besthomeimprovement.biz
contact@besthomeimprovement.biz
sales@besthomeimprovement.biz
service@besthomeimprovement.biz
help@besthomeimprovement.biz
team@besthomeimprovement.biz
noreply@besthomeimprovement.biz
notifications@besthomeimprovement.biz
updates@besthomeimprovement.biz
```

### **Domain 2: autoblog247.net (10 addresses)**

```
admin@autoblog247.net
info@autoblog247.net
contact@autoblog247.net
support@autoblog247.net
news@autoblog247.net
editor@autoblog247.net
team@autoblog247.net
noreply@autoblog247.net
notifications@autoblog247.net
updates@autoblog247.net
```

### **Sender Address Categories**

| Category | Purpose | Examples |
|----------|---------|----------|
| **General** | Primary communication | info@, contact@ |
| **Support** | Customer support | support@, help@, service@ |
| **Sales** | Sales and marketing | sales@ |
| **Team** | Team communications | team@, admin@, editor@ |
| **Automated** | System notifications | noreply@, notifications@, updates@ |
| **News** | Content distribution | news@ (autoblog247) |

---

## 🔄 **Rotation Behavior**

### **How It Works**

When sending to 50 contacts with 20 from addresses:

1. **Email #1**: From `info@besthomeimprovement.biz`
2. **Email #2**: From `support@besthomeimprovement.biz`
3. **Email #3**: From `contact@besthomeimprovement.biz`
4. ...
5. **Email #20**: From `updates@autoblog247.net`
6. **Email #21**: Cycles back to `info@besthomeimprovement.biz`
7. And so on...

**Result**: Each sender address is used **2-3 times** across 50 recipients, distributing sender load evenly.

---

## 🧪 **Testing Recommendations**

### **Small Test Campaign (10 contacts)**

```python
# Test with first 10 contacts
# Recommended settings:
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 2,
    'delay_max': 5,
    'humanize_sending': False,  # Disable for quick test
}
```

**Expected results:**
- Time: ~3-5 minutes
- From addresses: 10 different senders
- Each provider: 1 email

### **Medium Test Campaign (20 contacts)**

```python
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 3,
    'delay_max': 8,
    'humanize_sending': True,  # Enable for realism
}
```

**Expected results:**
- Time: ~8-12 minutes
- From addresses: All 20 senders used once
- Geographic spread: Good coverage

### **Full Test Campaign (50 contacts)**

```python
EMAIL_CONFIG = {
    'enable_antibot': True,
    'randomize_delays': True,
    'delay_min': 5,
    'delay_max': 15,
    'humanize_sending': True,
}
```

**Expected results:**
- Time: ~25-35 minutes
- From addresses: Each sender used 2-3 times
- Complete coverage: All email providers tested
- Humanization: 3-5 pauses during sending

---

## 📊 **Inbox Delivery Testing**

### **What to Monitor**

After sending test campaign, check:

1. **Inbox Placement Rate**
   - How many emails landed in inbox vs spam
   - Target: >90% inbox placement

2. **Provider-Specific Performance**
   - Gmail inbox rate
   - Outlook inbox rate
   - Yahoo inbox rate
   - Other providers

3. **Spam Folder Analysis**
   - Which providers marked as spam
   - Common patterns in spam-flagged emails

4. **Delivery Time**
   - How long until emails appear
   - Target: <5 minutes for most providers

5. **Authentication Headers**
   - SPF pass rate
   - DKIM pass rate
   - DMARC alignment

### **How to Check Results**

**Manual Method:**
1. Log into each test email account
2. Check inbox and spam folders
3. Verify email appearance and formatting
4. Test all links and placeholders
5. Review email headers for authentication

**Automated Method (Recommended):**
1. Use email testing service (e.g., Mail-Tester, GlockApps)
2. Monitor bounce rates via Amazon SES console
3. Track complaint rates
4. Review delivery metrics

---

## ⚙️ **Configuration Files**

### **contacts/emails.txt**
- **Location**: `contacts/emails.txt`
- **Total contacts**: 50
- **Format**: One email per line
- **Encoding**: UTF-8

### **from_emails/fromemails.txt**
- **Location**: `from_emails/fromemails.txt`
- **Total addresses**: 20
- **Format**: One email per line
- **Domains**: besthomeimprovement.biz (10), autoblog247.net (10)

---

## 🔧 **Quick Test Commands**

### **Test with Python script:**

```bash
# Run full campaign
python3 main.py

# Expected output:
# 📧 Loaded 50 contacts
# 👤 Loaded 20 sender emails
# 📝 Loaded 10000 subject lines
# 🛡️  Antibot Security: Antibot: ON | Features: 7/7
# ...
# ✅ Successfully sent: 50
```

### **Verify file contents:**

```bash
# Count contacts
wc -l contacts/emails.txt
# Output: 50

# Count from addresses
wc -l from_emails/fromemails.txt
# Output: 20

# Show first 10 contacts
head -10 contacts/emails.txt

# Show all from addresses
cat from_emails/fromemails.txt
```

---

## 🎯 **Campaign Statistics**

### **Expected Performance (50 contacts, 20 senders)**

| Metric | Value | Details |
|--------|-------|---------|
| **Total emails** | 50 | All test contacts |
| **Sender addresses** | 20 | Rotated evenly |
| **Emails per sender** | 2-3 | Load distributed |
| **Email providers** | 25+ | Wide coverage |
| **Geographic regions** | 4+ | Global testing |
| **Subject variations** | 50 | From 10,000 pool |
| **Template variations** | 11 | DocuSign-style |
| **Total rotation** | 7 features | Full platform |

### **Antibot Security Active**

| Feature | Status | Impact |
|---------|--------|--------|
| Randomized delays | ✅ | 2-8s per email |
| Custom Message-ID | ✅ | Unique per email |
| User agent variation | ✅ | 15 clients |
| Randomized headers | ✅ | 7+ headers |
| Reply-To headers | ✅ | Better deliverability |
| Humanization | ✅ | Natural pauses |
| Priority rotation | ✅ | Weighted distribution |

---

## ✅ **Pre-Deployment Checklist**

Before running full campaign:

- ✅ **Contacts file ready**: 50 email addresses loaded
- ✅ **From addresses configured**: 20 sender addresses
- ✅ **SMTP credentials verified**: Amazon SES or SMTP configured
- ✅ **Antibot security enabled**: All 7 features active
- ✅ **Subject rotation active**: 10,000 subjects loaded
- ✅ **Templates ready**: 11 DocuSign templates
- ✅ **Links configured**: 21 links across 9 categories
- ✅ **Disclaimers loaded**: 500 disclaimers
- ✅ **Sender authentication**: SPF/DKIM/DMARC configured
- ✅ **Test campaign**: Small batch tested successfully

---

## 📈 **Success Metrics**

### **Target Goals**

| Metric | Target | Excellent | Good | Needs Improvement |
|--------|--------|-----------|------|-------------------|
| **Inbox rate** | >90% | >95% | 85-94% | <85% |
| **Spam rate** | <5% | <2% | 2-10% | >10% |
| **Bounce rate** | <2% | <1% | 1-3% | >3% |
| **Complaint rate** | <0.1% | 0% | <0.5% | >0.5% |
| **Delivery time** | <5 min | <2 min | 2-10 min | >10 min |

### **Provider-Specific Targets**

| Provider | Inbox Rate Target | Notes |
|----------|-------------------|-------|
| Gmail | >92% | Strictest filters |
| Outlook | >90% | Good with proper auth |
| Yahoo | >88% | Moderate filtering |
| Others | >85% | Varies by provider |

---

## 🚀 **Next Steps**

1. **Verify Sender Authentication**
   - Check SPF records for both domains
   - Verify DKIM signatures
   - Configure DMARC policy

2. **Run Small Test**
   - Test with 5-10 contacts first
   - Monitor inbox placement
   - Check email formatting

3. **Scale Up Gradually**
   - 10 contacts → 20 contacts → 50 contacts
   - Monitor metrics at each stage
   - Adjust antibot settings as needed

4. **Analyze Results**
   - Review inbox vs spam placement
   - Check authentication pass rates
   - Optimize based on findings

5. **Production Deployment**
   - Use full contact list
   - Enable all antibot features
   - Monitor ongoing performance

---

## 📚 **Related Documentation**

- **ANTIBOT-SECURITY-GUIDE.md**: Complete antibot system guide
- **SUBJECT-MANAGEMENT-GUIDE.md**: Subject line rotation guide
- **QR-CODE-PLACEHOLDER-GUIDE.md**: QR code embedding guide
- **PLACEHOLDER-REFERENCE.md**: All 14 placeholders documented

---

## 📋 **Quick Reference**

### **File Locations**

```
contacts/emails.txt              (50 test contacts)
from_emails/fromemails.txt       (20 sender addresses)
subjects/subjects_01.txt - subjects_10.txt  (10,000 subjects)
templates/template1-11.html      (11 DocuSign templates)
disclaimers/*.txt                (500 disclaimers)
```

### **Key Statistics**

- ✅ **Contacts**: 50 generic test emails
- ✅ **Senders**: 20 addresses (10 per domain)
- ✅ **Subjects**: 10,000 lines
- ✅ **Templates**: 11 DocuSign-style
- ✅ **Disclaimers**: 500 unique
- ✅ **Antibot features**: 7 active
- ✅ **Email providers**: 25+ covered

---

**Your test contact system is ready for comprehensive inbox delivery testing!** 📧

Use these 50 diverse contacts to validate your antibot security and maximize inbox placement rates across all major email providers worldwide.
