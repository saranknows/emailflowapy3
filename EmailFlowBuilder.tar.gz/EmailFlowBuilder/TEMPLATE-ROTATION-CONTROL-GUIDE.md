# Template Rotation Control Guide

## Overview

The email marketing platform now includes **template rotation on/off control** in `main.py`. This allows you to choose between rotating through all templates or using a single specific template for your campaign.

## Configuration Options

### In EMAIL_CONFIG

```python
EMAIL_CONFIG = {
    ...
    # Template Rotation Configuration
    'template_rotation': True,  # True = use all templates, False = use specific template
    'selected_template': 'default.html',  # Template to use when rotation is OFF
    ...
}
```

## Available Functions

### 1. enable_template_rotation()

**Enable template rotation to use all available templates**

```python
enable_template_rotation()
```

**Output:**
```
✅ Template rotation enabled - will use all templates
```

**Result:**
- All templates in `templates/` folder will be used
- Templates will rotate automatically for each email
- Each recipient gets a different template

---

### 2. disable_template_rotation(template_name=None)

**Disable template rotation and use a single specific template**

```python
# Disable rotation (use currently selected template)
disable_template_rotation()

# Disable rotation and set specific template
disable_template_rotation('template1-professional.html')
```

**Output:**
```
✅ Template rotation disabled - using template1-professional.html
```

**Result:**
- Only the selected template will be used
- All recipients get the same template
- Consistent branding across all emails

---

### 3. set_template(template_name)

**Set a specific template to use (automatically disables rotation)**

```python
set_template('template2-modern.html')
```

**Output:**
```
✅ Set template to: template2-modern.html (rotation disabled)
```

**Returns:**
- `True` if template exists
- `False` if template not found

**Result:**
- Template rotation is disabled
- Only the specified template will be used
- Validates that template exists before setting

---

### 4. get_template_rotation_status()

**Get current template rotation status**

```python
status = get_template_rotation_status()

print(status)
# {
#     'rotation_enabled': True/False,
#     'selected_template': 'template-name.html',
#     'mode': 'All templates (rotating)' or 'Single template: template-name.html'
# }
```

**Returns:** Dictionary with:
- `rotation_enabled`: Boolean indicating if rotation is on
- `selected_template`: Name of selected template (used when rotation is off)
- `mode`: Human-readable description of current mode

---

## Usage Examples

### Example 1: Enable Rotation for Variety

```python
# Use all templates to add variety
enable_template_rotation()

# Run main.py
# Output will show:
# 🎨 Template rotation: ON - Using all 11 templates
```

**Use Case:** 
- Testing multiple templates
- A/B testing different designs
- Keeping emails fresh and varied

---

### Example 2: Use Single Template for Consistency

```python
# Use one template for brand consistency
disable_template_rotation('template1-professional.html')

# Or use set_template()
set_template('template1-professional.html')

# Run main.py
# Output will show:
# 🎨 Template rotation: OFF - Using template1-professional.html
```

**Use Case:**
- Brand consistency across campaign
- Official announcements
- Corporate communications

---

### Example 3: Check Current Status

```python
# Check what mode you're in
status = get_template_rotation_status()

if status['rotation_enabled']:
    print(f"Rotating through all templates")
else:
    print(f"Using only: {status['selected_template']}")
```

---

### Example 4: Switch Between Modes

```python
# Start with rotation on
enable_template_rotation()
# Send first batch...

# Switch to single template
set_template('template-corporate.html')
# Send second batch...

# Back to rotation
enable_template_rotation()
# Send third batch...
```

---

## How It Works

### Rotation ON (Default)

**Configuration:**
```python
'template_rotation': True
```

**Behavior:**
```
Email 1 → template1-professional.html
Email 2 → template2-modern.html
Email 3 → template3-minimal.html
Email 4 → template4-corporate.html
...
Email 11 → template10-announcement.html
Email 12 → template1-professional.html  (cycles back)
```

**Console Output:**
```
🎨 Template rotation: ON - Using all 11 templates
```

**When to Use:**
- Testing multiple template designs
- Adding visual variety to campaigns
- A/B testing which templates perform best
- Keeping emails fresh over time

---

### Rotation OFF

**Configuration:**
```python
'template_rotation': False,
'selected_template': 'template1-professional.html'
```

**Behavior:**
```
Email 1 → template1-professional.html
Email 2 → template1-professional.html
Email 3 → template1-professional.html
Email 4 → template1-professional.html
...
All emails → template1-professional.html
```

**Console Output:**
```
🎨 Template rotation: OFF - Using template1-professional.html
```

**When to Use:**
- Brand consistency required
- Official company communications
- Legal or compliance emails
- Specific campaign with one design

---

## Configuration Methods

### Method 1: Edit EMAIL_CONFIG Directly

```python
# In main.py, find EMAIL_CONFIG section (around line 48)

EMAIL_CONFIG = {
    ...
    # Enable rotation
    'template_rotation': True,
    
    # OR disable rotation and set specific template
    'template_rotation': False,
    'selected_template': 'template2-modern.html',
    ...
}
```

### Method 2: Use Functions Programmatically

```python
# At the top of your script or in interactive mode

# Enable rotation
enable_template_rotation()

# Disable rotation
disable_template_rotation()

# Set specific template
set_template('template3-minimal.html')

# Check status
status = get_template_rotation_status()
print(status['mode'])
```

---

## Complete Workflow Examples

### Example 1: Professional Business Email Campaign

```python
# Use professional template only
set_template('template1-professional.html')

# Verify
status = get_template_rotation_status()
print(f"Mode: {status['mode']}")
# Output: Mode: Single template: template1-professional.html

# Run campaign
# python main.py
```

---

### Example 2: Newsletter with Variety

```python
# Enable rotation for visual variety
enable_template_rotation()

# Verify
status = get_template_rotation_status()
print(f"Mode: {status['mode']}")
# Output: Mode: All templates (rotating)

# Run campaign
# python main.py
```

---

### Example 3: A/B Testing Templates

```python
# Test 1: Use template A for first 100 contacts
set_template('template1-professional.html')
# Send to first 100...

# Test 2: Use template B for next 100 contacts
set_template('template2-modern.html')
# Send to next 100...

# Compare which performs better
```

---

## Integration with Other Features

### Works with QR Codes

```python
# Template rotation + QR codes
EMAIL_CONFIG = {
    'template_rotation': True,  # Rotate templates
    'enable_qr_code': True,     # Embed QR code
    'qr_code_data': 'https://example.com/offer'
}

# QR code will be embedded in ALL templates
```

---

### Works with Subject Rotation

```python
# Both template and subject rotation
EMAIL_CONFIG = {
    'template_rotation': True,  # Rotate templates
}

# Subject files in subjects/ folder will also rotate
# Each email gets: different subject + different template
```

---

### Works with From Email Rotation

```python
# Triple rotation: templates + subjects + from emails
EMAIL_CONFIG = {
    'template_rotation': True,
}

# Each email gets:
# - Different template
# - Different subject line
# - Different sender address
# Maximum variety!
```

---

## Console Output Reference

### When Rotation is ON
```
============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 1 files
👤 Loaded 2 sender emails
🎨 Template rotation: ON - Using all 11 templates

Press ENTER to start sending to 8 contacts...
```

### When Rotation is OFF
```
============================================================
   EMAIL MARKETING SENDER - STANDALONE VERSION
============================================================

📧 Loaded 8 contacts
📝 Loaded 10 subject lines from 1 files
👤 Loaded 2 sender emails
🎨 Template rotation: OFF - Using template1-professional.html

Press ENTER to start sending to 8 contacts...
```

---

## Best Practices

### ✅ DO:

1. **Use rotation OFF for important announcements**
   ```python
   set_template('template4-corporate.html')
   ```

2. **Use rotation ON for newsletters and marketing**
   ```python
   enable_template_rotation()
   ```

3. **Check status before large sends**
   ```python
   status = get_template_rotation_status()
   print(f"Current mode: {status['mode']}")
   # Confirm before sending to thousands
   ```

4. **Validate selected template exists**
   ```python
   if set_template('my-template.html'):
       print("Template ready to use")
   else:
       print("Template not found, choose another")
   ```

### ❌ DON'T:

1. **Don't forget to verify your setting**
   ```python
   # Bad: Change setting and forget to check
   set_template('template.html')
   # Run without verifying
   
   # Good: Change and verify
   set_template('template.html')
   status = get_template_rotation_status()
   print(status['mode'])  # Verify before sending
   ```

2. **Don't use rotation for legal/compliance emails**
   ```python
   # Bad: Random templates for legal notices
   enable_template_rotation()  # DON'T DO THIS
   
   # Good: Consistent template
   set_template('template-legal.html')
   ```

---

## Troubleshooting

### Template Not Found Error

```python
set_template('missing-template.html')
# Output: ❌ Template not found: missing-template.html
```

**Solution:**
```python
# List available templates
templates = list_templates()
for t in templates:
    print(t['name'])

# Use one that exists
set_template('template1-professional.html')
```

---

### Rotation Not Working

**Check configuration:**
```python
status = get_template_rotation_status()
print(status)

# If rotation_enabled is False, enable it:
enable_template_rotation()
```

---

### Only One Template Being Used

**Possible causes:**
1. Rotation is disabled
   ```python
   enable_template_rotation()
   ```

2. Only one template in templates/ folder
   ```bash
   ls templates/
   # Add more .html files to templates/
   ```

---

## Advanced: Dynamic Template Selection

```python
def select_mode_based_on_campaign(campaign_type):
    """Select template mode based on campaign type"""
    
    if campaign_type == 'newsletter':
        enable_template_rotation()
        print("📧 Newsletter mode: Using all templates")
    
    elif campaign_type == 'announcement':
        set_template('template4-corporate.html')
        print("📢 Announcement mode: Using corporate template")
    
    elif campaign_type == 'promotional':
        set_template('template6-promotional.html')
        print("🎉 Promotional mode: Using promotional template")
    
    else:
        enable_template_rotation()
        print("📧 Default mode: Using all templates")

# Use it
select_mode_based_on_campaign('newsletter')
# Then run main.py
```

---

## Summary

**4 New Functions:**
1. ✅ `enable_template_rotation()` - Use all templates
2. ✅ `disable_template_rotation()` - Use single template
3. ✅ `set_template(name)` - Set specific template
4. ✅ `get_template_rotation_status()` - Check current mode

**Configuration Options:**
- `template_rotation`: True/False
- `selected_template`: Template filename

**Use Cases:**
- ✅ Brand consistency (rotation OFF)
- ✅ Visual variety (rotation ON)
- ✅ A/B testing (switch between modes)
- ✅ Campaign-specific designs

**Integration:**
- ✅ Works with QR codes
- ✅ Works with subject rotation
- ✅ Works with from email rotation
- ✅ Works with all existing features

---

**Related Documentation:**
- [TEMPLATE-FUNCTIONS-GUIDE.md](TEMPLATE-FUNCTIONS-GUIDE.md) - Template management functions
- [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md) - Complete main.py guide
- [QR-CODE-FEATURE-GUIDE.md](QR-CODE-FEATURE-GUIDE.md) - QR code functionality
- [README.md](README.md) - Project overview
