# MIME Formatting - Quick Start

## Overview
All emails are automatically sent in MIME format with HTML body delivery. This ensures maximum compatibility and professional appearance across all email clients.

---

## 🎯 **What is MIME?**

**MIME** (Multipurpose Internet Mail Extensions) is the standard format for sending emails with:
- HTML content
- Plain text fallback
- File attachments
- Proper headers
- UTF-8 encoding

---

## 📊 **MIME Structure**

### **Your Email:**

```html
<html>
<body>
    <h1>Hello {{firstname}}!</h1>
    <p>Your ID: {{randomnumber}}</p>
    <a href="{{link}}">Click Here</a>
</body>
</html>
```

### **Sent as MIME:**

```
multipart/alternative
├── text/plain (fallback)
└── text/html (primary) ← Recipients see this
```

---

## ✅ **What Recipients See**

### **99%+ of recipients:**
✅ Beautiful HTML email with:
- Full formatting
- Clickable links
- Colors and styling
- Images and tables

### **1% old email clients:**
✅ Plain text version (automatic fallback)

---

## 🔧 **No Configuration Needed**

Everything is automatic:

✅ **HTML → Primary content** (what people see)  
✅ **Plain text → Auto-generated** (fallback)  
✅ **Headers → Auto-added** (Date, Message-ID, etc.)  
✅ **Encoding → UTF-8** (international characters)  
✅ **Attachments → Properly formatted** (multipart/mixed)  

---

## 📧 **MIME Parts**

### **Part 1: Plain Text** (Lower Priority)
```
Hello Michael!
Your ID: 45821
Click Here
```

### **Part 2: HTML** (Higher Priority - DISPLAYED)
```html
<html>
<body>
    <h1>Hello Michael!</h1>
    <p>Your ID: 45821</p>
    <a href="https://example.com">Click Here</a>
</body>
</html>
```

Email clients display **Part 2 (HTML)** by default.

---

## 🎯 **Examples**

### **Example 1: DocuSign-Style**

```html
<div style="max-width: 600px;">
    <h1>Signature Required</h1>
    <p>Dear {{fullname}},</p>
    <p>Document #{{randomnumber}}</p>
    <a href="{{link}}">Sign Now</a>
</div>
```

**Delivered as:**
- ✅ MIME formatted
- ✅ HTML body displayed
- ✅ Clickable link works
- ✅ Plain text fallback included

---

### **Example 2: Marketing Email**

```html
<html>
<head>
    <style>
        .header { background: #2563eb; color: white; padding: 20px; }
        .button { background: #10b981; color: white; padding: 10px; }
    </style>
</head>
<body>
    <div class="header"><h1>Special Offer!</h1></div>
    <p>Hi {{firstname}}!</p>
    <a href="{{link}}" class="button">Claim Offer</a>
</body>
</html>
```

**Delivered as:**
- ✅ MIME formatted
- ✅ CSS styling applied
- ✅ Colorful header and button
- ✅ Professional appearance

---

### **Example 3: With Attachment**

**Template:** HTML email  
**Attachment:** PDF file

**MIME Structure:**
```
multipart/mixed
├── multipart/alternative
│   ├── text/plain
│   └── text/html ← Displayed
└── application/pdf ← Downloadable
```

**Recipients get:**
- ✅ HTML email (displayed)
- ✅ PDF attachment (downloadable)

---

## ✅ **Email Client Compatibility**

### **100% Compatible:**

✅ Gmail  
✅ Outlook (all versions)  
✅ Yahoo Mail  
✅ Apple Mail  
✅ Thunderbird  
✅ AOL Mail  
✅ ProtonMail  
✅ Mobile email apps  

**All display the HTML body correctly!**

---

## 🔍 **MIME Headers** (Auto-Added)

Every email includes:

```
From: Sender Name <sender@example.com>
To: recipient@example.com
Subject: Your Document
Date: Thu, 20 Nov 2025 10:30:45 -0800
Message-ID: <unique-id@example.com>
MIME-Version: 1.0
Content-Type: multipart/alternative
```

---

## 💡 **Key Benefits**

✅ **Professional Appearance** - HTML emails look polished  
✅ **Maximum Compatibility** - Works with all email clients  
✅ **Automatic Fallback** - Plain text for old clients  
✅ **Enhanced Functionality** - Links, images, styling work  
✅ **Standard Compliance** - RFC 2045-2049 compliant  
✅ **Better Deliverability** - Recognized by email servers  

---

## 📚 **Full Documentation**

For complete details, see **MIME-FORMATTING-GUIDE.md**

---

**All your emails are automatically sent in MIME format with HTML body delivery!** 📧
