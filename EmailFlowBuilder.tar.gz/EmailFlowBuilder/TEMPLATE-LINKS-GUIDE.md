# Template Links Guide

## Overview

All email templates now include **full link support** with clickable buttons, text links, and multiple link placeholders. You can easily add URLs to your campaigns for landing pages, unsubscribe links, privacy policies, and more.

## Available Link Placeholders

Each template includes these link placeholders that you can replace with your actual URLs:

### Primary Links

| Placeholder | Purpose | Example URL |
|------------|---------|-------------|
| `{{link}}` | Main call-to-action link | `https://example.com/offer` |
| `{{website}}` | Your website or landing page | `https://yourcompany.com` |
| `{{content}}` | Main email content/message | Any text content |

### Footer Links

| Placeholder | Purpose | Example URL |
|------------|---------|-------------|
| `{{unsubscribe}}` | Unsubscribe/opt-out link | `https://example.com/unsubscribe?id=123` |
| `{{privacy}}` | Privacy policy link | `https://example.com/privacy` |
| `{{contact}}` | Contact page link | `https://example.com/contact` |
| `{{preferences}}` | Email preferences link | `https://example.com/preferences` |
| `{{terms}}` | Terms & conditions link | `https://example.com/terms` |

### Additional Links

| Placeholder | Purpose | Example URL |
|------------|---------|-------------|
| `{{docs}}` | Documentation link | `https://docs.example.com` |
| `{{archive}}` | Newsletter archive | `https://example.com/newsletter/archive` |

## How to Use Links

### Method 1: Replace in main.py

Update the `replace_template_placeholders()` function or replace manually:

```python
# In your email sending logic
html_content = template_content.replace('{{link}}', 'https://example.com/offer')
html_content = html_content.replace('{{website}}', 'https://yourcompany.com')
html_content = html_content.replace('{{unsubscribe}}', 'https://example.com/unsubscribe')
html_content = html_content.replace('{{privacy}}', 'https://example.com/privacy')
```

### Method 2: Use Template Functions

```python
# Using the built-in function
from main import replace_template_placeholders

template_content = load_template('template1-professional.html')

link_data = {
    'link': 'https://example.com/special-offer',
    'website': 'https://yourcompany.com',
    'content': 'Check out our amazing new product!',
    'unsubscribe': 'https://example.com/unsubscribe?id=12345',
    'privacy': 'https://yourcompany.com/privacy-policy'
}

final_html = replace_template_placeholders(template_content, link_data)
```

### Method 3: Direct Template Editing

Edit the template HTML files directly and replace placeholders with actual URLs.

## Template-Specific Link Features

### Template 1 - Professional
- Clean CTA button: "Learn More"
- Inline website link
- Footer: Unsubscribe & Privacy Policy links

### Template 2 - Modern  
- Gradient CTA button: "Get Started Now"
- Styled inline link with border
- Footer: Unsubscribe, Privacy, Archive links

### Template 3 - Minimal
- Simple bordered button: "Take Action →"
- Underlined text link
- Footer: Unsubscribe & Privacy links

### Template 4 - Corporate
- Formal button: "VIEW DETAILS"
- Professional underlined link
- Footer: Update Preferences, Privacy, Contact Us

### Template 5 - Newsletter
- Newsletter button: "Read Full Newsletter"
- Community hub link
- Footer: Unsubscribe, Preferences, Archive

### Template 6 - Promotional
- Bold CTA: "🚀 CLAIM OFFER NOW! 🚀"
- Eye-catching gradient button
- Footer: Unsubscribe & Terms links

### Template 7 - Elegant
- Bordered elegant button: "Discover More"
- Distinguished portal link
- Footer: Manage Preferences & Privacy

### Template 8 - Tech
- Tech-style button: "[ ACCESS SYSTEM ]"
- Status dashboard link
- Footer: Unsubscribe & Documentation

### Template 9 - Friendly
- Fun button: "🎉 Let's Go! 🎉"
- Colorful gradient style
- Footer: Unsubscribe & Preferences

### Template 10 - Announcement
- Bold button: "READ FULL DETAILS"
- Help center link
- Footer: Unsubscribe, Privacy, Contact Support

## Complete Example

```python
# Example: Send campaign with all links configured

from main import load_template, replace_template_placeholders, send_email

# Load template
template = load_template('template1-professional.html')

# Define all your links
links = {
    'link': 'https://example.com/summer-sale',
    'website': 'https://example.com',
    'content': 'Our biggest sale of the year is happening now! Save up to 50% on all products.',
    'unsubscribe': 'https://example.com/unsubscribe?email={{email}}',
    'privacy': 'https://example.com/privacy',
    'contact': 'https://example.com/contact'
}

# Replace placeholders
email_html = replace_template_placeholders(template, links)

# Send email
send_email(smtp_server, 'sales@example.com', 'customer@email.com', 
           'Huge Summer Sale!', email_html)
```

## Link Styling

All links in templates are styled for:
- ✅ Proper color contrast
- ✅ Clear visual indication (underlines, buttons, borders)
- ✅ Hover effects (where supported)
- ✅ Mobile responsiveness
- ✅ Accessibility

## Best Practices

### 1. Always Use HTTPS
```python
# Good
'link': 'https://example.com/offer'

# Bad
'link': 'http://example.com/offer'  # Not secure
```

### 2. Track Your Links
```python
# Add UTM parameters for analytics
'link': 'https://example.com/offer?utm_source=email&utm_campaign=summer2025'
```

### 3. Personalize Unsubscribe Links
```python
# Include user identifier
'unsubscribe': f'https://example.com/unsubscribe?id={user_id}'
```

### 4. Test All Links
```python
# Before sending, verify all links work
test_links = ['link', 'website', 'unsubscribe', 'privacy']
for link_key in test_links:
    url = links.get(link_key)
    # Test that URL is valid and accessible
```

### 5. Use Descriptive Link Text
```python
# Good - tells user where link goes
html = html.replace('{{website}}', 'https://example.com')
# Button text: "Visit Our Website"

# Bad - vague link text
# Button text: "Click Here"
```

## Troubleshooting

### Links Not Clickable
**Problem:** Links appear as text, not clickable  
**Solution:** Make sure you're replacing the placeholder with a full URL including `https://`

### Broken Links
**Problem:** Links lead to 404 errors  
**Solution:** Verify URLs are correct and accessible

### Styling Issues
**Problem:** Links don't match template design  
**Solution:** Use the built-in styled links rather than adding custom HTML

## Integration with Other Features

### With QR Codes
```python
EMAIL_CONFIG = {
    'enable_qr_code': True,
    'qr_code_data': 'https://example.com/mobile-offer'  # Same as {{link}}
}
```

### With Template Rotation
All templates support the same link placeholders, so your links work across all rotated templates.

### With Attachment Rotation
Links work independently of attachments - you can have both clickable links and file attachments in the same email.

## Summary

**Link Placeholders Available:**
- ✅ `{{link}}` - Main CTA
- ✅ `{{website}}` - Your website
- ✅ `{{content}}` - Email content
- ✅ `{{unsubscribe}}` - Opt-out link
- ✅ `{{privacy}}` - Privacy policy
- ✅ `{{contact}}` - Contact page
- ✅ `{{preferences}}` - Email settings
- ✅ `{{terms}}` - Terms & conditions
- ✅ `{{docs}}` - Documentation
- ✅ `{{archive}}` - Newsletter archive

**All 10 Templates Updated:**
- ✅ Professional buttons and links
- ✅ Styled for each template's theme
- ✅ Mobile-responsive design
- ✅ Accessible markup
- ✅ Ready to use

---

**Related Documentation:**
- [TEMPLATE-FUNCTIONS-GUIDE.md](TEMPLATE-FUNCTIONS-GUIDE.md) - Template management
- [TEMPLATE-ROTATION-CONTROL-GUIDE.md](TEMPLATE-ROTATION-CONTROL-GUIDE.md) - Template rotation
- [MAIN-PY-USAGE-GUIDE.md](MAIN-PY-USAGE-GUIDE.md) - Complete usage guide
