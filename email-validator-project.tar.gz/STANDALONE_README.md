# Standalone Email Validator

A **single-file Python script** for email validation with provider detection. No database, no web server, no repository cloning required!

## ✨ Features

- ✅ Email format validation
- ✅ MX record DNS lookup
- ✅ Provider detection (Microsoft, Google, Office365, GoDaddy, Mimecast, ARSMTP)
- ✅ Single email validation
- ✅ Bulk CSV processing (up to 10,000 emails)
- ✅ Results export (CSV and TXT)
- ✅ Interactive mode
- ✅ **No external dependencies** (works with Python standard library)
- ✅ Optional `dnspython` for better MX lookups

## 📋 Requirements

- **Python 3.7+** (that's it!)
- **Optional**: `dnspython` for improved MX record lookups

## 🚀 Quick Start

### 1. Download the Script

Just download the `email_validator_standalone.py` file - that's all you need!

### 2. (Optional) Install dnspython

For better MX record lookups:

```bash
pip install dnspython
```

> **Note**: The script will work without dnspython, but MX lookups will be limited.

### 3. Run the Validator

#### Validate a Single Email

```bash
python email_validator_standalone.py validate user@example.com
```

**Output:**
```
============================================================
Email: user@example.com
Domain: example.com
Valid Format: ✅ Yes
Deliverable: ✅ Yes
Provider: Unknown
MX Records: mail.example.com
Validation Time: 245.32ms
============================================================
```

#### Bulk Validate from CSV

```bash
python email_validator_standalone.py bulk emails.csv
```

**Output:**
```
📂 Reading emails from emails.csv...
   Found 1500 emails

🔍 Validating 1500 emails...
   Progress: 100/1500 (6%)
   Progress: 200/1500 (13%)
   ...
   Progress: 1500/1500 (100%)

============================================================
📊 VALIDATION SUMMARY
============================================================
Total Emails: 1500
Valid Format: 1450 (96%)
Deliverable: 1380 (92%)

📈 Provider Breakdown (Deliverable Only):
  Microsoft: 450
  Google: 380
  Office365: 320
  Unknown: 180
  GoDaddy: 50
============================================================

✅ Exported 1500 results to validation_results_20251120_153045.csv
✅ Exported 1380 deliverable emails to deliverable_emails_20251120_153045.txt
```

#### Interactive Mode

```bash
python email_validator_standalone.py interactive
```

```
============================================================
📧 INTERACTIVE EMAIL VALIDATOR
============================================================
Type 'exit' or 'quit' to stop

Enter email address: test@gmail.com

============================================================
Email: test@gmail.com
Domain: gmail.com
Valid Format: ✅ Yes
Deliverable: ✅ Yes
Provider: Google
MX Records: gmail-smtp-in.l.google.com, alt1.gmail-smtp-in.l.google.com
Validation Time: 156.78ms
============================================================

Enter email address: exit
👋 Goodbye!
```

## 📖 Usage Examples

### Basic Validation

```bash
# Validate one email
python email_validator_standalone.py validate admin@company.com
```

### Bulk Validation with Custom Export

```bash
# Validate CSV and export results
python email_validator_standalone.py bulk contacts.csv --export my_results.csv --deliverable valid_only.txt
```

### CSV File Format

Your CSV file can have any format - the script will automatically detect email addresses:

**Option 1: Simple list**
```csv
user1@example.com
user2@gmail.com
admin@company.com
```

**Option 2: With headers**
```csv
Name,Email,Phone
John Doe,john@example.com,555-1234
Jane Smith,jane@gmail.com,555-5678
```

**Option 3: Multiple columns**
```csv
First Name,Last Name,Email Address,Company
John,Doe,john@example.com,Acme Corp
Jane,Smith,jane@gmail.com,Tech Inc
```

## 📊 Output Files

### Full Results CSV

Contains complete validation data:

```csv
email,domain,is_valid_format,is_deliverable,mx_records,provider,validation_time_ms,error
user@gmail.com,gmail.com,True,True,"gmail-smtp-in.l.google.com, alt1.gmail-smtp-in.l.google.com",Google,234.56,
invalid@,,,False,False,,Unknown,12.34,Invalid email format
```

### Deliverable Emails TXT

Simple list of valid emails (one per line):

```
user@gmail.com
admin@company.com
contact@business.org
```

## 🎯 Provider Detection

The script automatically detects these email providers:

| Provider | Detection Method |
|----------|------------------|
| **Microsoft** | outlook.com, hotmail.com, live.com, msn.com domains |
| **Google** | gmail.com, googlemail.com domains + MX patterns |
| **Office365** | mail.protection.outlook.com MX records |
| **GoDaddy** | secureserver.net MX + godaddy*.outlook.com |
| **Mimecast** | mimecast.com MX records |
| **ARSMTP** | antispamcloud.com, pphosted.com MX |

## 🔧 Command Reference

```bash
# Show help
python email_validator_standalone.py

# Validate single email
python email_validator_standalone.py validate <email>

# Bulk validate with default exports
python email_validator_standalone.py bulk <csv_file>

# Bulk validate with custom export filenames
python email_validator_standalone.py bulk <csv_file> --export <results.csv> --deliverable <valid.txt>

# Interactive mode
python email_validator_standalone.py interactive
```

## 💡 Tips

1. **Large CSV Files**: The script limits processing to 10,000 emails by default to prevent memory issues
2. **MX Lookups**: Install `dnspython` for more reliable MX record lookups
3. **Timeout**: DNS lookups have a 5-second timeout to prevent hanging
4. **Export Naming**: If you don't specify export filenames, the script creates timestamped files automatically

## 🐛 Troubleshooting

### "dnspython not installed" Warning

```bash
pip install dnspython
```

### CSV Reading Errors

- Ensure your CSV is UTF-8 encoded
- Check that at least one column contains email addresses with `@` symbol

### Slow Validation

- DNS lookups can take time, especially for domains with slow DNS servers
- Each email has a 5-second timeout for MX lookups

## 📦 No Installation Required

This is a **completely standalone script**. You don't need to:

- ❌ Clone a Git repository
- ❌ Set up a database
- ❌ Configure environment variables
- ❌ Install web frameworks
- ❌ Run multiple services

Just download `email_validator_standalone.py` and run it with Python!

## 🆚 Compared to Full Application

| Feature | Standalone Script | Full Web App |
|---------|------------------|--------------|
| Setup | ✅ One file | ❌ Complex setup |
| Dependencies | ✅ Optional | ❌ Many required |
| UI | ❌ CLI only | ✅ Web interface |
| Database | ❌ No persistence | ✅ PostgreSQL |
| Authentication | ❌ None | ✅ User accounts |
| Credit System | ❌ None | ✅ 1B credits |
| Rate Limiting | ❌ None | ✅ 60 req/min |
| Deployment | ✅ Run anywhere | ❌ Needs server |
| Best For | Quick validation | Production use |

## 📄 License

This is a standalone utility script - use it however you need!

## 🤝 Contributing

Since this is a single-file script, you can:
- Modify it for your needs
- Add custom provider patterns
- Extend validation logic
- Share improvements with others

---

**Happy Validating!** 📧✨
