from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import sys
import json
import csv
import itertools
import random
import threading
import time
from datetime import datetime
import smtplib
import socket
import socks
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders
from email.utils import formataddr
import logging
import qrcode
from io import BytesIO
import base64
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configure logging first
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Resend import (optional)
try:
    import resend
    RESEND_AVAILABLE = True
except ImportError:
    RESEND_AVAILABLE = False
    logger.warning("Resend not available")

# HTML to Image import (optional)
try:
    from html2image import Html2Image
    HTML2IMAGE_AVAILABLE = True
except ImportError:
    HTML2IMAGE_AVAILABLE = False
    logger.warning("html2image not available")

# AWS SES import (optional)
try:
    import boto3
    from botocore.exceptions import ClientError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False
    logger.warning("boto3 not available")

app = Flask(__name__)
CORS(app)

# Directories
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUBJECTS_DIR = os.path.join(BASE_DIR, 'subjects')
FROM_EMAILS_DIR = os.path.join(BASE_DIR, 'from_emails')
CONTACTS_DIR = os.path.join(BASE_DIR, 'contacts')
TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
CAMPAIGNS_DIR = os.path.join(BASE_DIR, 'campaigns')
ATTACHMENTS_DIR = os.path.join(BASE_DIR, 'attachments')
QRCODES_DIR = os.path.join(BASE_DIR, 'qrcodes')
HTML_IMAGES_DIR = os.path.join(BASE_DIR, 'html_images')
LINKS_DIR = os.path.join(BASE_DIR, 'links')

# Email sending status
sending_status = {
    'active': False,
    'total': 0,
    'sent': 0,
    'failed': 0,
    'current_email': '',
    'start_time': None
}

# Rotation iterators
subject_iterator = None
from_email_iterator = None
template_iterator = None
attachment_iterator = None

# Link rotation iterators
link_iterator = None
google_redirect_iterator = None
oauth2url_iterator = None
googlesitesurl_iterator = None
rotation_link_iterator = None
default_link_iterator = None
urlqr_iterator = None
dynamics_iterator = None

# Initialize AWS SES client (if available)
ses_client = None
if BOTO3_AVAILABLE:
    try:
        aws_access_key = os.environ.get('AWS_ACCESS_KEY_ID')
        aws_secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
        aws_region = os.environ.get('AWS_REGION', 'us-east-1')
        
        if aws_access_key and aws_secret_key:
            ses_client = boto3.client(
                'ses',
                region_name=aws_region,
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key
            )
            logger.info(f"AWS SES client initialized for region: {aws_region}")
        else:
            logger.warning("AWS credentials not found in environment variables")
    except Exception as e:
        logger.error(f"Failed to initialize AWS SES client: {str(e)}")
        ses_client = None

def load_file_lines(directory, filename):
    """Load lines from a file in the specified directory"""
    filepath = os.path.join(directory, filename)
    if not os.path.exists(filepath):
        return []
    with open(filepath, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

def save_file_lines(directory, filename, lines):
    """Save lines to a file in the specified directory"""
    os.makedirs(directory, exist_ok=True)
    filepath = os.path.join(directory, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

def validate_upload_file(filename, allowed_extensions):
    """Validate and sanitize uploaded filename"""
    if not filename:
        return None, "No filename provided"
    
    sanitized = secure_filename(filename)
    if not sanitized:
        return None, "Invalid filename"
    
    if '.' not in sanitized:
        return None, "File must have an extension"
    
    ext = sanitized.rsplit('.', 1)[1].lower()
    if ext not in allowed_extensions:
        return None, f"Invalid file type. Allowed: {', '.join(allowed_extensions)}"
    
    return sanitized, None

def get_next_rotated(items, iterator_name):
    """Get next item from rotation"""
    global subject_iterator, from_email_iterator, template_iterator, attachment_iterator
    global link_iterator, google_redirect_iterator, oauth2url_iterator, googlesitesurl_iterator
    global rotation_link_iterator, default_link_iterator, urlqr_iterator, dynamics_iterator
    
    if not items:
        return None
    
    # Normalize iterator_name to lowercase for consistent matching
    iterator_key = iterator_name.lower() if iterator_name else ''
    
    if iterator_key == 'subject':
        if subject_iterator is None:
            subject_iterator = itertools.cycle(items)
        return next(subject_iterator)
    elif iterator_key == 'from_email':
        if from_email_iterator is None:
            from_email_iterator = itertools.cycle(items)
        return next(from_email_iterator)
    elif iterator_key == 'template':
        if template_iterator is None:
            template_iterator = itertools.cycle(items)
        return next(template_iterator)
    elif iterator_key == 'attachment':
        if attachment_iterator is None:
            attachment_iterator = itertools.cycle(items)
        return next(attachment_iterator)
    
    # Link iterators - normalize to lowercase and match
    elif iterator_key == '{{link}}':
        if link_iterator is None:
            link_iterator = itertools.cycle(items)
        return next(link_iterator)
    elif iterator_key == '{{google_redirect}}':
        if google_redirect_iterator is None:
            google_redirect_iterator = itertools.cycle(items)
        return next(google_redirect_iterator)
    elif iterator_key == '{{oauth2url}}':
        if oauth2url_iterator is None:
            oauth2url_iterator = itertools.cycle(items)
        return next(oauth2url_iterator)
    elif iterator_key == '{{googlesitesurl}}':
        if googlesitesurl_iterator is None:
            googlesitesurl_iterator = itertools.cycle(items)
        return next(googlesitesurl_iterator)
    elif iterator_key == '{{rotation_link}}':
        if rotation_link_iterator is None:
            rotation_link_iterator = itertools.cycle(items)
        return next(rotation_link_iterator)
    elif iterator_key == '{{default_link}}':
        if default_link_iterator is None:
            default_link_iterator = itertools.cycle(items)
        return next(default_link_iterator)
    elif iterator_key == '{{urlqr}}':
        if urlqr_iterator is None:
            urlqr_iterator = itertools.cycle(items)
        return next(urlqr_iterator)
    elif iterator_key == '{{dynamics}}':
        if dynamics_iterator is None:
            dynamics_iterator = itertools.cycle(items)
        return next(dynamics_iterator)
    
    return random.choice(items)

def generate_qr_code(data, size=300):
    """
    Generate QR code from data and return as base64 encoded image
    
    Args:
        data: String data to encode in QR code (URL, text, etc.)
        size: Size of QR code in pixels (default 300)
    
    Returns:
        base64 encoded PNG image string, or None if error
    """
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        img_base64 = base64.b64encode(buffer.getvalue()).decode()
        
        return img_base64
    except Exception as e:
        logger.error(f"QR code generation error: {str(e)}")
        return None

def convert_html_to_image(html_content, output_filename=None, size=(800, 600)):
    """
    Convert HTML content to image
    
    Args:
        html_content: HTML string to convert
        output_filename: Optional filename to save (default: auto-generated)
        size: Tuple of (width, height) in pixels
    
    Returns:
        Path to saved image file, or None if error
    """
    if not HTML2IMAGE_AVAILABLE:
        logger.error("html2image library not available")
        return None
        
    try:
        os.makedirs(HTML_IMAGES_DIR, exist_ok=True)
        
        if not output_filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_filename = f'email_{timestamp}.png'
        
        # Find Chrome/Chromium executable
        import shutil
        chrome_path = None
        
        # Try common Chrome/Chromium paths
        possible_paths = [
            shutil.which('chromium'),
            shutil.which('chromium-browser'),
            shutil.which('chrome'),
            shutil.which('google-chrome'),
            '/usr/bin/chromium',
            '/usr/bin/chromium-browser',
            '/usr/bin/google-chrome',
            '/nix/store/*/bin/chromium'  # Nix store path
        ]
        
        for path in possible_paths:
            if path and os.path.exists(path):
                chrome_path = path
                break
        
        # If still not found, try to find chromium in nix store
        if not chrome_path:
            import glob
            nix_chromium = glob.glob('/nix/store/*/bin/chromium')
            if nix_chromium:
                chrome_path = nix_chromium[0]
        
        # Custom flags for containerized environments (Replit)
        custom_flags = [
            '--no-sandbox',  # Required for containerized environments
            '--headless',  # Run without GUI
            '--disable-gpu',  # Disable GPU hardware acceleration
            '--disable-dev-shm-usage',  # Overcome limited shared memory
            '--disable-setuid-sandbox',  # Alternative sandbox bypass
            '--disable-software-rasterizer',
            '--disable-extensions',
            '--disable-background-networking',
            '--disable-sync',
            '--metrics-recording-only',
            '--disable-default-apps',
            '--mute-audio',
            '--no-first-run',
            '--disable-crashpad'
        ]
        
        logger.info(f"Using Chrome/Chromium at: {chrome_path}")
        
        if chrome_path:
            hti = Html2Image(
                output_path=HTML_IMAGES_DIR,
                size=size,
                browser_executable=chrome_path,
                custom_flags=custom_flags
            )
        else:
            # Fallback: try without specifying path
            logger.warning("Chrome/Chromium not found, trying default browser")
            hti = Html2Image(
                output_path=HTML_IMAGES_DIR,
                size=size,
                custom_flags=custom_flags
            )
        
        # Generate image from HTML
        logger.info(f"Generating image: {output_filename}")
        hti.screenshot(html_str=html_content, save_as=output_filename)
        
        output_path = os.path.join(HTML_IMAGES_DIR, output_filename)
        
        if os.path.exists(output_path):
            logger.info(f"✅ Image generated successfully: {output_path}")
            return output_path
        else:
            logger.error(f"⚠️ Image generation failed - file not created: {output_path}")
            return None
            
    except Exception as e:
        logger.error(f"❌ HTML to image conversion error: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None

def extract_domain_from_email(email):
    """Extract domain from email address"""
    try:
        if "@" in email:
            domain = email.split("@")[1]
            return domain.strip()
        return None
    except Exception as e:
        logger.error(f"Failed to extract domain from email {email}: {str(e)}")
        return None

def process_company_logo_placeholder(html_content, recipient_email):
    """
    Replace {{COMPANYLOGO}} placeholder with company logo URL
    Fetches logo from recipient email domain using Clearbit Logo API
    
    Args:
        html_content: HTML template content
        recipient_email: Recipient email address
    
    Returns:
        HTML content with {{COMPANYLOGO}} replaced by logo URL
    """
    try:
        # Check if placeholder exists (case-insensitive)
        if "{{COMPANYLOGO}}" not in html_content.upper():
            return html_content
        
        # Extract domain from recipient email
        domain = extract_domain_from_email(recipient_email)
        
        if not domain:
            logger.warning(f"Could not extract domain from email: {recipient_email}")
            # Replace with empty string if domain extraction fails
            import re
            html_content = re.sub(r"\{\{COMPANYLOGO\}\}", "", html_content, flags=re.IGNORECASE)
            return html_content
        
        # Generate Clearbit Logo API URL
        logo_url = f"https://logo.clearbit.com/{domain}"
        
        logger.info(f"Replacing {{{{COMPANYLOGO}}}} with logo for domain: {domain}")
        
        # Replace placeholder (case-insensitive)
        import re
        html_content = re.sub(
            r"\{\{COMPANYLOGO\}\}",
            logo_url,
            html_content,
            flags=re.IGNORECASE
        )
        
        return html_content
        
    except Exception as e:
        logger.error(f"Error processing company logo placeholder: {str(e)}")
        # On error, remove placeholder
        import re
        html_content = re.sub(r"\{\{COMPANYLOGO\}\}", "", html_content, flags=re.IGNORECASE)
        return html_content

def process_link_placeholders(html_content, links_data):
    """
    Replace all link placeholders in HTML content with rotating links
    
    Args:
        html_content: HTML template content
        links_data: Dictionary with link types and their URLs
    
    Returns:
        HTML content with all link placeholders replaced
    """
    import re
    
    placeholder_map = {
        '{{link}}': links_data.get('link', []),
        '{{google_redirect}}': links_data.get('google_redirect', []),
        '{{oauth2url}}': links_data.get('oauth2url', []),
        '{{googlesitesurl}}': links_data.get('googlesitesurl', []),
        '{{rotation_link}}': links_data.get('rotation_link', []),
        '{{default_link}}': links_data.get('default_link', []),
        '{{urlqr}}': links_data.get('urlqr', []),
        '{{dynamics}}': links_data.get('dynamics', [])
    }
    
    # Replace each placeholder with a link from the list
    for placeholder, urls in placeholder_map.items():
        if urls:
            # Check if placeholder exists (case-insensitive)
            pattern = re.compile(re.escape(placeholder), re.IGNORECASE)
            if pattern.search(html_content):
                # Use cycle to get next URL (with rotation)
                url = get_next_rotated(urls, placeholder)
                # Case-insensitive replacement
                html_content = pattern.sub(url, html_content)
    
    return html_content

def load_link_files():
    """Load all link files from links directory"""
    links_data = {
        'link': [],
        'google_redirect': [],
        'oauth2url': [],
        'googlesitesurl': [],
        'rotation_link': [],
        'default_link': [],
        'urlqr': [],
        'dynamics': []
    }
    
    link_file_mapping = {
        'link': 'main_links.txt',
        'google_redirect': 'google_redirect_links.txt',
        'oauth2url': 'oauth2_urls.txt',
        'googlesitesurl': 'google_sites_urls.txt',
        'rotation_link': 'rotation_links.txt',
        'default_link': 'default_links.txt',
        'urlqr': 'urlqr_links.txt',
        'dynamics': 'dynamics_links.txt'
    }
    
    for link_type, filename in link_file_mapping.items():
        filepath = os.path.join(LINKS_DIR, filename)
        if os.path.exists(filepath):
            links_data[link_type] = load_file_lines(LINKS_DIR, filename)
            logger.info(f"Loaded {len(links_data[link_type])} {link_type} links from {filename}")
        else:
            # Set default fallback URL
            links_data[link_type] = [f'https://example.com/{link_type}']
            logger.warning(f"Link file not found: {filename}, using default")
    
    return links_data

@app.route('/', methods=['GET'])
def root():
    """Root health check endpoint for deployment"""
    return jsonify({'status': 'ok', 'message': 'Email Marketing Platform API', 'version': '1.0.0'})

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'ok', 'message': 'Email Marketing System API'})

@app.route('/api/subjects', methods=['GET'])
def get_subjects():
    """Get all subject files and their contents"""
    files = []
    if os.path.exists(SUBJECTS_DIR):
        for filename in os.listdir(SUBJECTS_DIR):
            if filename.endswith('.txt'):
                filepath = os.path.join(SUBJECTS_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    lines = [line for line in content.split('\n') if line.strip()]
                files.append({
                    'name': filename,
                    'count': len(lines),
                    'preview': lines[:5] if lines else []
                })
    return jsonify(files)

@app.route('/api/subjects/<filename>', methods=['GET', 'POST', 'DELETE'])
def manage_subject_file(filename):
    """Manage individual subject file"""
    filepath = os.path.join(SUBJECTS_DIR, filename)
    
    if request.method == 'GET':
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            return jsonify({'name': filename, 'content': content})
        return jsonify({'error': 'File not found'}), 404
    
    elif request.method == 'POST':
        data = request.json
        content = data.get('content', '')
        os.makedirs(SUBJECTS_DIR, exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'message': f'{filename} saved'})
    
    elif request.method == 'DELETE':
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': f'{filename} deleted'})
        return jsonify({'error': 'File not found'}), 404

@app.route('/api/subjects/upload', methods=['POST'])
def upload_subjects():
    """Upload subject file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    sanitized_filename, error = validate_upload_file(file.filename, {'txt'})
    if error:
        return jsonify({'error': error}), 400
    
    os.makedirs(SUBJECTS_DIR, exist_ok=True)
    filepath = os.path.join(SUBJECTS_DIR, sanitized_filename)
    file.save(filepath)
    
    return jsonify({'success': True, 'message': f'{sanitized_filename} uploaded', 'filename': sanitized_filename})

@app.route('/api/from-emails', methods=['GET'])
def get_from_emails():
    """Get all from email files"""
    files = []
    if os.path.exists(FROM_EMAILS_DIR):
        for filename in os.listdir(FROM_EMAILS_DIR):
            if filename.endswith('.txt'):
                filepath = os.path.join(FROM_EMAILS_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    lines = [line for line in content.split('\n') if line.strip()]
                files.append({
                    'name': filename,
                    'count': len(lines),
                    'preview': lines[:5] if lines else []
                })
    return jsonify(files)

@app.route('/api/from-emails/<filename>', methods=['GET', 'POST', 'DELETE'])
def manage_from_email_file(filename):
    """Manage individual from email file"""
    filepath = os.path.join(FROM_EMAILS_DIR, filename)
    
    if request.method == 'GET':
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            return jsonify({'name': filename, 'content': content})
        return jsonify({'error': 'File not found'}), 404
    
    elif request.method == 'POST':
        data = request.json
        content = data.get('content', '')
        os.makedirs(FROM_EMAILS_DIR, exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'message': f'{filename} saved'})
    
    elif request.method == 'DELETE':
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': f'{filename} deleted'})
        return jsonify({'error': 'File not found'}), 404

@app.route('/api/from-emails/upload', methods=['POST'])
def upload_from_emails():
    """Upload from email file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    sanitized_filename, error = validate_upload_file(file.filename, {'txt'})
    if error:
        return jsonify({'error': error}), 400
    
    os.makedirs(FROM_EMAILS_DIR, exist_ok=True)
    filepath = os.path.join(FROM_EMAILS_DIR, sanitized_filename)
    file.save(filepath)
    
    return jsonify({'success': True, 'message': f'{sanitized_filename} uploaded', 'filename': sanitized_filename})

@app.route('/api/contacts', methods=['GET'])
def get_contacts():
    """Get all contact list files"""
    files = []
    if os.path.exists(CONTACTS_DIR):
        for filename in os.listdir(CONTACTS_DIR):
            if filename.endswith('.txt') or filename.endswith('.csv'):
                filepath = os.path.join(CONTACTS_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    lines = [line.strip() for line in f if line.strip()]
                files.append({
                    'name': filename,
                    'count': len(lines),
                    'preview': lines[:10] if lines else []
                })
    return jsonify(files)

@app.route('/api/contacts/upload', methods=['POST'])
def upload_contacts():
    """Upload contact list CSV file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    sanitized_filename, error = validate_upload_file(file.filename, {'csv', 'txt'})
    if error:
        return jsonify({'error': error}), 400
    
    os.makedirs(CONTACTS_DIR, exist_ok=True)
    filepath = os.path.join(CONTACTS_DIR, sanitized_filename)
    file.save(filepath)
    
    return jsonify({'success': True, 'message': f'{sanitized_filename} uploaded', 'filename': sanitized_filename})

@app.route('/api/templates', methods=['GET'])
def get_templates():
    """Get all email templates"""
    templates = []
    if os.path.exists(TEMPLATES_DIR):
        for filename in os.listdir(TEMPLATES_DIR):
            if filename.endswith('.html') or filename.endswith('.txt'):
                filepath = os.path.join(TEMPLATES_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                templates.append({
                    'name': filename,
                    'content': content[:200] + '...' if len(content) > 200 else content
                })
    return jsonify(templates)

@app.route('/api/templates/<filename>', methods=['GET', 'POST', 'DELETE'])
def manage_template(filename):
    """Manage individual template"""
    filepath = os.path.join(TEMPLATES_DIR, filename)
    
    if request.method == 'GET':
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            return jsonify({'name': filename, 'content': content})
        return jsonify({'error': 'File not found'}), 404
    
    elif request.method == 'POST':
        data = request.json
        content = data.get('content', '')
        os.makedirs(TEMPLATES_DIR, exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'message': f'{filename} saved'})
    
    elif request.method == 'DELETE':
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': f'{filename} deleted'})
        return jsonify({'error': 'File not found'}), 404

@app.route('/api/attachments', methods=['GET'])
def get_attachments():
    """Get all attachment files"""
    files = []
    if os.path.exists(ATTACHMENTS_DIR):
        for filename in os.listdir(ATTACHMENTS_DIR):
            if filename.endswith(('.pdf', '.svg', '.html', '.mhtml', '.eml')):
                filepath = os.path.join(ATTACHMENTS_DIR, filename)
                file_size = os.path.getsize(filepath)
                file_size_kb = round(file_size / 1024, 2)
                files.append({
                    'name': filename,
                    'size': file_size,
                    'size_kb': file_size_kb,
                    'extension': os.path.splitext(filename)[1]
                })
    return jsonify(files)

@app.route('/api/attachments/upload', methods=['POST'])
def upload_attachment():
    """Upload attachment file (.pdf, .svg, .html, .mhtml, .eml)"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    sanitized_filename, error = validate_upload_file(file.filename, {'pdf', 'svg', 'html', 'mhtml', 'eml'})
    if error:
        return jsonify({'error': error}), 400
    
    os.makedirs(ATTACHMENTS_DIR, exist_ok=True)
    filepath = os.path.join(ATTACHMENTS_DIR, sanitized_filename)
    file.save(filepath)
    
    return jsonify({'success': True, 'message': f'{sanitized_filename} uploaded', 'filename': sanitized_filename})

@app.route('/api/attachments/<filename>', methods=['DELETE'])
def delete_attachment(filename):
    """Delete an attachment file"""
    # Sanitize filename to prevent directory traversal
    safe_filename = secure_filename(filename)
    if not safe_filename or safe_filename != filename:
        return jsonify({'error': 'Invalid filename'}), 400
    
    filepath = os.path.join(ATTACHMENTS_DIR, safe_filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        return jsonify({'success': True, 'message': f'{safe_filename} deleted'})
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/attachments/auto-generate', methods=['POST'])
def auto_generate_attachments():
    """Auto-generate all attachment file types (PDF, SVG, HTML, MHTML, EML)"""
    try:
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main import auto_generate_attachments as generate_attachments
        
        generated_files = generate_attachments()
        
        return jsonify({
            'success': True,
            'message': f'Generated {len(generated_files)} attachment files',
            'files': generated_files
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/attachments/<filename>/content', methods=['GET'])
def get_attachment_content(filename):
    """Get attachment file content for editing"""
    safe_filename = secure_filename(filename)
    if not safe_filename or safe_filename != filename:
        return jsonify({'error': 'Invalid filename'}), 400
    
    try:
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main import get_attachment_content as get_content
        
        result = get_content(safe_filename)
        
        if result is None:
            return jsonify({'error': 'Attachment not found'}), 404
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/attachments/<filename>/content', methods=['PUT'])
def update_attachment_content(filename):
    """Update attachment file content"""
    safe_filename = secure_filename(filename)
    if not safe_filename or safe_filename != filename:
        return jsonify({'error': 'Invalid filename'}), 400
    
    try:
        data = request.json
        content = data.get('content', '')
        encoding = data.get('encoding', 'utf-8')
        
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main import save_attachment_content
        
        success = save_attachment_content(safe_filename, content, encoding)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'{safe_filename} updated successfully'
            })
        else:
            return jsonify({'error': 'Failed to save attachment'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/attachments/<filename>/preview', methods=['GET'])
def preview_attachment(filename):
    """Get attachment preview data for rendering"""
    safe_filename = secure_filename(filename)
    if not safe_filename or safe_filename != filename:
        return jsonify({'error': 'Invalid filename'}), 400
    
    try:
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main import get_attachment_preview
        
        result = get_attachment_preview(safe_filename)
        
        if result is None:
            return jsonify({'error': 'Attachment not found'}), 404
        
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error previewing attachment: {str(e)}")
        return jsonify({'error': str(e)}), 500

# ============================================================================
# LINK MANAGEMENT ENDPOINTS
# ============================================================================

@app.route('/api/links', methods=['GET'])
def get_links():
    """Get all link files and their contents"""
    files = []
    os.makedirs(LINKS_DIR, exist_ok=True)
    
    # Define all supported link types with their file mappings
    link_types = {
        'main_links.txt': {'type': 'LINK', 'placeholder': '{{link}}'},
        'google_redirect_links.txt': {'type': 'GOOGLE_REDIRECTLINK', 'placeholder': '{{google_redirect}}'},
        'oauth2_urls.txt': {'type': 'OAUTH2URL', 'placeholder': '{{oauth2url}}'},
        'google_sites_urls.txt': {'type': 'GOOGLESITESURL', 'placeholder': '{{googlesitesurl}}'},
        'rotation_links.txt': {'type': 'ROTATION_LINK', 'placeholder': '{{rotation_link}}'},
        'default_links.txt': {'type': 'DEFAULT_LINK', 'placeholder': '{{default_link}}'},
        'urlqr_links.txt': {'type': 'URLQR', 'placeholder': '{{urlqr}}'},
        'dynamics_links.txt': {'type': 'DYNAMICS', 'placeholder': '{{dynamics}}'}
    }
    
    for filename, meta in link_types.items():
        filepath = os.path.join(LINKS_DIR, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [line for line in content.split('\n') if line.strip()]
            files.append({
                'name': filename,
                'type': meta['type'],
                'placeholder': meta['placeholder'],
                'count': len(lines),
                'preview': lines[:5] if lines else [],
                'exists': True
            })
        else:
            files.append({
                'name': filename,
                'type': meta['type'],
                'placeholder': meta['placeholder'],
                'count': 0,
                'preview': [],
                'exists': False
            })
    
    return jsonify(files)

@app.route('/api/links/<filename>', methods=['GET', 'POST', 'DELETE'])
def manage_link_file(filename):
    """Manage individual link file"""
    # Validate filename is in allowed list
    allowed_files = [
        'main_links.txt', 'google_redirect_links.txt', 'oauth2_urls.txt',
        'google_sites_urls.txt', 'rotation_links.txt', 'default_links.txt',
        'urlqr_links.txt', 'dynamics_links.txt'
    ]
    
    if filename not in allowed_files:
        return jsonify({'error': 'Invalid link file'}), 400
    
    filepath = os.path.join(LINKS_DIR, filename)
    
    if request.method == 'GET':
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            return jsonify({'name': filename, 'content': content})
        return jsonify({'error': 'File not found'}), 404
    
    elif request.method == 'POST':
        data = request.json
        content = data.get('content', '')
        os.makedirs(LINKS_DIR, exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'message': f'{filename} saved'})
    
    elif request.method == 'DELETE':
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': f'{filename} deleted'})
        return jsonify({'error': 'File not found'}), 404

@app.route('/api/links/upload', methods=['POST'])
def upload_links():
    """Upload link file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Get link type from form data
    link_type = request.form.get('link_type', 'main_links')
    
    # Map link type to filename
    filename_map = {
        'main_links': 'main_links.txt',
        'google_redirect': 'google_redirect_links.txt',
        'oauth2': 'oauth2_urls.txt',
        'google_sites': 'google_sites_urls.txt',
        'rotation': 'rotation_links.txt',
        'default': 'default_links.txt',
        'urlqr': 'urlqr_links.txt',
        'dynamics': 'dynamics_links.txt'
    }
    
    target_filename = filename_map.get(link_type, 'main_links.txt')
    
    os.makedirs(LINKS_DIR, exist_ok=True)
    filepath = os.path.join(LINKS_DIR, target_filename)
    file.save(filepath)
    
    return jsonify({
        'success': True,
        'message': f'{target_filename} uploaded',
        'filename': target_filename
    })

@app.route('/api/campaigns', methods=['GET', 'POST'])
def manage_campaigns():
    """Get all campaigns or create new campaign"""
    if request.method == 'GET':
        campaigns = []
        if os.path.exists(CAMPAIGNS_DIR):
            for filename in os.listdir(CAMPAIGNS_DIR):
                if filename.endswith('.json'):
                    filepath = os.path.join(CAMPAIGNS_DIR, filename)
                    with open(filepath, 'r', encoding='utf-8') as f:
                        campaign = json.load(f)
                        campaigns.append(campaign)
        return jsonify(campaigns)
    
    elif request.method == 'POST':
        campaign_data = request.json
        campaign_id = f"campaign_{int(time.time())}"
        campaign_data['id'] = campaign_id
        campaign_data['created_at'] = datetime.now().isoformat()
        campaign_data['status'] = 'draft'
        
        os.makedirs(CAMPAIGNS_DIR, exist_ok=True)
        filepath = os.path.join(CAMPAIGNS_DIR, f"{campaign_id}.json")
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(campaign_data, f, indent=2)
        
        return jsonify({'success': True, 'campaign': campaign_data})

@app.route('/api/campaigns/<campaign_id>', methods=['GET', 'PUT', 'DELETE'])
def manage_campaign(campaign_id):
    """Manage individual campaign"""
    filepath = os.path.join(CAMPAIGNS_DIR, f"{campaign_id}.json")
    
    if request.method == 'GET':
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                campaign = json.load(f)
            return jsonify(campaign)
        return jsonify({'error': 'Campaign not found'}), 404
    
    elif request.method == 'PUT':
        campaign_data = request.json
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(campaign_data, f, indent=2)
        return jsonify({'success': True, 'campaign': campaign_data})
    
    elif request.method == 'DELETE':
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': 'Campaign deleted'})
        return jsonify({'error': 'Campaign not found'}), 404

@app.route('/api/send-campaign', methods=['POST'])
def send_campaign():
    """Send email campaign with rotation"""
    global sending_status
    
    data = request.json
    campaign_id = data.get('campaign_id')
    
    # Load campaign
    filepath = os.path.join(CAMPAIGNS_DIR, f"{campaign_id}.json")
    if not os.path.exists(filepath):
        return jsonify({'error': 'Campaign not found'}), 404
    
    with open(filepath, 'r', encoding='utf-8') as f:
        campaign = json.load(f)
    
    # Start sending in background thread
    thread = threading.Thread(target=send_emails_background, args=(campaign,))
    thread.daemon = True
    thread.start()
    
    return jsonify({'success': True, 'message': 'Campaign sending started'})

def send_emails_background(campaign):
    """Background task to send emails"""
    global sending_status, subject_iterator, from_email_iterator, template_iterator, attachment_iterator
    
    try:
        # Reset iterators for new campaign
        subject_iterator = None
        from_email_iterator = None
        template_iterator = None
        attachment_iterator = None
        
        # Reset status
        sending_status['active'] = True
        sending_status['sent'] = 0
        sending_status['failed'] = 0
        sending_status['start_time'] = datetime.now().isoformat()
        
        # Load recipients
        contact_file = campaign.get('contact_list')
        recipients = load_file_lines(CONTACTS_DIR, contact_file)
        sending_status['total'] = len(recipients)
        
        # Load subjects
        subject_file = campaign.get('subject_file')
        subjects = load_file_lines(SUBJECTS_DIR, subject_file)
        
        # Load from emails
        from_email_file = campaign.get('from_email_file')
        from_emails = load_file_lines(FROM_EMAILS_DIR, from_email_file)
        
        # Check template rotation setting (1 = on, 0 = off)
        template_rotation = campaign.get('template_rotation', 1)
        
        # Load templates based on rotation setting
        templates = []
        if template_rotation == 1:
            # When rotation is ON: Load ALL available templates
            for template_file in os.listdir(TEMPLATES_DIR):
                if template_file.endswith('.html'):
                    template_path = os.path.join(TEMPLATES_DIR, template_file)
                    with open(template_path, 'r', encoding='utf-8') as f:
                        templates.append(f.read())
            logger.info(f"Template rotation ON: Loaded {len(templates)} templates")
        else:
            # When rotation is OFF: Load only the selected template
            template_files = campaign.get('templates', [])
            if not template_files:
                template_file = campaign.get('template')
                if template_file:
                    template_files = [template_file]
            
            for template_file in template_files:
                template_path = os.path.join(TEMPLATES_DIR, template_file)
                if os.path.exists(template_path):
                    with open(template_path, 'r', encoding='utf-8') as f:
                        templates.append(f.read())
            logger.info(f"Template rotation OFF: Using {len(templates)} template(s)")
        
        if not templates:
            raise Exception("No templates found for campaign")
        
        # Check attachment rotation setting (1 = on, 0 = off)
        attachment_rotation = campaign.get('attachment_rotation', 0)
        
        # Load attachments based on rotation setting
        attachments = []
        if attachment_rotation == 1:
            # When rotation is ON: Load ALL available attachments
            if os.path.exists(ATTACHMENTS_DIR):
                for attachment_file in os.listdir(ATTACHMENTS_DIR):
                    if attachment_file.endswith(('.pdf', '.svg', '.html', '.mhtml', '.eml')):
                        attachment_path = os.path.join(ATTACHMENTS_DIR, attachment_file)
                        attachments.append(attachment_path)
                logger.info(f"Attachment rotation ON: Loaded {len(attachments)} attachments")
            else:
                logger.info("Attachment rotation ON: No attachments directory found")
        else:
            # When rotation is OFF: Load only the selected attachment if provided
            attachment_file = campaign.get('attachment')
            if attachment_file:
                attachment_path = os.path.join(ATTACHMENTS_DIR, attachment_file)
                if os.path.exists(attachment_path):
                    attachments.append(attachment_path)
                    logger.info(f"Attachment rotation OFF: Using 1 attachment ({attachment_file})")
                else:
                    logger.info(f"Attachment rotation OFF: Selected attachment not found ({attachment_file})")
            else:
                logger.info("Attachment rotation OFF: No attachment selected")
        
        # Load link files for placeholder replacement
        links_data = load_link_files()
        
        # Get email provider settings
        email_settings = campaign.get('email_settings', campaign.get('smtp_settings', {}))
        
        # Send emails
        for recipient in recipients:
            if not sending_status['active']:
                break
            
            sending_status['current_email'] = recipient
            
            # Rotate subject, from email, and template
            subject = get_next_rotated(subjects, 'subject')
            from_email = get_next_rotated(from_emails, 'from_email')
            
            # Template rotation: 1 = rotate, 0 = use first template only
            if template_rotation == 1:
                template_content = get_next_rotated(templates, 'template')
            else:
                template_content = templates[0]
            
            # Attachment rotation: 1 = rotate, 0 = use first/selected attachment only
            attachment_path = None
            if attachments:
                if attachment_rotation == 1:
                    attachment_path = get_next_rotated(attachments, 'attachment')
                else:
                    attachment_path = attachments[0]
            
            # Process link placeholders FIRST
            final_html_content = process_link_placeholders(template_content, links_data)
            
            # Process {{COMPANYLOGO}} placeholder SECOND (after links, before QR and HTML-to-image)
            final_html_content = process_company_logo_placeholder(final_html_content, recipient)
            
            # QR Code Integration
            if campaign.get('enable_qr_code', False):
                qr_data = campaign.get('qr_code_data', '')
                if qr_data:
                    # Generate QR code as base64 image
                    qr_base64 = generate_qr_code(qr_data)
                    if qr_base64:
                        # Embed QR code in HTML
                        qr_img_tag = f'<img src="data:image/png;base64,{qr_base64}" alt="QR Code" style="max-width: 300px; display: block; margin: 20px auto;" />'
                        # Insert QR code before closing body tag
                        if '</body>' in final_html_content:
                            final_html_content = final_html_content.replace('</body>', f'{qr_img_tag}</body>')
                        else:
                            final_html_content += qr_img_tag
                        logger.info(f"QR code embedded for {recipient}")
            
            # HTML to Image Conversion
            html_image_attachment = None
            if campaign.get('enable_html_to_image', False):
                # Get image settings from campaign
                image_width = campaign.get('image_width', 600)
                image_quality = campaign.get('image_quality', 95)
                
                # Convert HTML to image with campaign settings
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                output_filename = f'email_{timestamp}.png'
                
                logger.info(f"Converting HTML to image (width: {image_width}px, quality: {image_quality}%)")
                image_path = convert_html_to_image(
                    html_content=final_html_content,
                    output_filename=output_filename,
                    size=(image_width, 800)
                )
                
                if image_path:
                    html_image_attachment = image_path
                    logger.info(f"✅ HTML converted to image for {recipient}: {image_path}")
                else:
                    logger.error(f"❌ HTML to image conversion failed for {recipient}")
            
            # Send email
            try:
                # Use modified HTML content (with QR code if enabled)
                email_html = final_html_content
                final_attachment = attachment_path
                
                # Handle HTML to image: if enabled, use CID attachment method (SMTP only)
                cid_image_for_email = None
                provider = email_settings.get('provider', 'smtp').lower()
                
                if html_image_attachment and os.path.exists(html_image_attachment):
                    # Only use CID for SMTP provider (SES/Resend don't support CID attachments)
                    if provider == 'smtp':
                        try:
                            # Extract the first valid link from original HTML to make entire image clickable
                            import re
                            link_pattern = r'<a[^>]+href=["\'](.*?)["\'][^>]*>'
                            matches = re.findall(link_pattern, final_html_content, re.IGNORECASE)
                            
                            # Find first valid HTTP/HTTPS link
                            clickable_url = None
                            for url in matches:
                                if url and url.startswith('http') and '{{' not in url:
                                    clickable_url = url
                                    break
                            
                            # Create email with entire image wrapped in clickable link
                            # The image will be embedded using Content-ID attachment method
                            if clickable_url:
                                # Wrap entire image in anchor tag
                                email_html = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif;">
    <div style="max-width: 600px; margin: 0 auto;">
        <a href="{clickable_url}" style="display: block; text-decoration: none;">
            <img src="cid:email_content_image" alt="Email Content - Click to view" width="600" style="width: 100%; max-width: 600px; height: auto; display: block; border: none;" />
        </a>
    </div>
</body>
</html>'''
                                logger.info(f"✅ HTML-to-Image: Entire image linked to {clickable_url}")
                            else:
                                # No valid link found, just display image without link
                                email_html = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif;">
    <div style="max-width: 600px; margin: 0 auto;">
        <img src="cid:email_content_image" alt="Email Content - Please enable images to view" width="600" style="width: 100%; max-width: 600px; height: auto; display: block;" />
    </div>
</body>
</html>'''
                                logger.info(f"✅ HTML-to-Image: Image displayed without link (no valid URL found)")
                            
                            # Set CID image path for SMTP provider
                            cid_image_for_email = html_image_attachment
                            logger.info(f"✅ HTML-to-Image: Using CID attachment for {recipient}")
                        except Exception as img_err:
                            logger.error(f"❌ Failed to prepare CID image: {str(img_err)}")
                            # Fallback to original HTML (no CID reference)
                            email_html = final_html_content
                            cid_image_for_email = None
                    else:
                        # For SES/Resend, use original HTML (no image conversion support)
                        logger.warning(f"⚠️ HTML-to-Image not supported for {provider} provider, using standard HTML")
                        email_html = final_html_content
                
                send_email(
                    to_email=recipient,
                    from_email=from_email,
                    from_name=campaign.get('from_name', 'Marketing Team'),
                    subject=subject,
                    html_content=email_html,
                    settings=email_settings,
                    attachment_path=final_attachment,
                    cid_image_path=cid_image_for_email
                )
                sending_status['sent'] += 1
                logger.info(f"Sent to {recipient}")
            except Exception as e:
                sending_status['failed'] += 1
                logger.error(f"Failed to send to {recipient}: {str(e)}")
            
            # Delay between emails
            time.sleep(campaign.get('delay', 1))
        
        sending_status['active'] = False
        logger.info(f"Campaign completed. Sent: {sending_status['sent']}, Failed: {sending_status['failed']}")
        
    except Exception as e:
        logger.error(f"Campaign error: {str(e)}")
        sending_status['active'] = False

def attach_file_to_message(msg, attachment_path):
    """Helper function to attach a file to a MIME message"""
    if not attachment_path or not os.path.exists(attachment_path):
        return
    
    filename = os.path.basename(attachment_path)
    
    with open(attachment_path, 'rb') as f:
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(f.read())
    
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', f'attachment; filename= {filename}')
    msg.attach(part)
    logger.info(f"Attached file: {filename}")

def create_smtp_connection(smtp_host, smtp_port, use_ssl=False):
    """Create SMTP connection with optional SOCKS proxy support"""
    # Check for proxy configuration from environment variables
    proxy_type = os.getenv('PROXY_TYPE', '').lower()
    proxy_host = os.getenv('PROXY_HOST', '')
    proxy_port = os.getenv('PROXY_PORT', '')
    proxy_username = os.getenv('PROXY_USERNAME', '')
    proxy_password = os.getenv('PROXY_PASSWORD', '')
    
    # If no proxy is configured, use standard SMTP connection
    if not proxy_type or not proxy_host or not proxy_port:
        if use_ssl:
            return smtplib.SMTP_SSL(smtp_host, smtp_port)
        else:
            return smtplib.SMTP(smtp_host, smtp_port)
    
    # Map proxy type to socks constant
    proxy_type_map = {
        'socks5': socks.SOCKS5,
        'socks4': socks.SOCKS4,
        'http': socks.HTTP
    }
    
    if proxy_type not in proxy_type_map:
        logger.warning(f"Unknown proxy type: {proxy_type}. Using direct connection.")
        if use_ssl:
            return smtplib.SMTP_SSL(smtp_host, smtp_port)
        else:
            return smtplib.SMTP(smtp_host, smtp_port)
    
    # Set default socket to use SOCKS proxy
    original_socket = socket.socket
    socks.set_default_proxy(
        proxy_type=proxy_type_map[proxy_type],
        addr=proxy_host,
        port=int(proxy_port),
        username=proxy_username if proxy_username else None,
        password=proxy_password if proxy_password else None
    )
    socket.socket = socks.socksocket
    
    logger.info(f"Using {proxy_type.upper()} proxy {proxy_host}:{proxy_port} for connection to {smtp_host}:{smtp_port}")
    
    try:
        # Create SMTP connection - will automatically use the SOCKS proxy
        if use_ssl:
            server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=30)
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=30)
        return server
    finally:
        # Restore original socket
        socket.socket = original_socket

def send_email_ses(to_email, from_email, from_name, subject, html_content, ses_settings, attachment_path=None):
    """Send email via Amazon SES SMTP"""
    msg = MIMEMultipart('mixed')
    msg['Subject'] = subject
    msg['From'] = formataddr((from_name, from_email))
    msg['To'] = to_email
    
    # Create alternative part for text/html
    msg_alternative = MIMEMultipart('alternative')
    html_part = MIMEText(html_content, 'html')
    msg_alternative.attach(html_part)
    msg.attach(msg_alternative)
    
    # Attach file if provided
    if attachment_path:
        attach_file_to_message(msg, attachment_path)
    
    # Amazon SES SMTP settings - Use environment variables as defaults
    # Priority: campaign settings > environment variables > defaults
    smtp_host = ses_settings.get('host', ses_settings.get('ses_host', os.getenv('SES_SMTP_HOST', 'email-smtp.us-east-1.amazonaws.com')))
    smtp_port = int(ses_settings.get('port', ses_settings.get('ses_port', os.getenv('SES_SMTP_PORT', 587))))
    smtp_user = ses_settings.get('user', ses_settings.get('ses_username', os.getenv('SES_SMTP_USERNAME', '')))
    smtp_pass = ses_settings.get('pass', ses_settings.get('ses_password', os.getenv('SES_SMTP_PASSWORD', '')))
    
    if not smtp_user or not smtp_pass:
        raise Exception("Amazon SES SMTP credentials not configured. Set SES_SMTP_USERNAME and SES_SMTP_PASSWORD in .env file or pass in campaign settings.")
    
    # Connect to Amazon SES SMTP server with optional SOCKS proxy support
    # Use SMTP_SSL for port 465, SMTP with STARTTLS for port 587
    use_ssl = smtp_port == 465
    server = create_smtp_connection(smtp_host, smtp_port, use_ssl=use_ssl)
    
    try:
        if smtp_port != 465:
            server.starttls()  # Only use STARTTLS if not using SSL port
        server.login(smtp_user, smtp_pass)
        server.send_message(msg)
        logger.info(f"Amazon SES email sent to {to_email} via {smtp_host}:{smtp_port}")
    finally:
        server.quit()

def send_email_resend(to_email, from_email, from_name, subject, html_content, api_key, attachment_path=None):
    """Send email via Resend"""
    if not RESEND_AVAILABLE:
        raise Exception("Resend library not available")
    
    resend.api_key = api_key
    
    params = {
        "from": f"{from_name} <{from_email}>",
        "to": [to_email],
        "subject": subject,
        "html": html_content
    }
    
    # Note: Resend attachments support would require additional implementation
    # For now, we'll log a warning if attachment is provided
    if attachment_path:
        logger.warning(f"Resend provider does not support attachments in this implementation (file: {os.path.basename(attachment_path)})")
    
    email = resend.Emails.send(params)
    logger.info(f"Resend email sent to {to_email}, id: {email.get('id')}")
    return email

def send_email_smtp(to_email, from_email, from_name, subject, html_content, smtp_settings, attachment_path=None, cid_image_path=None):
    """Send individual email via SMTP (Generic SMTP server)
    
    Args:
        to_email: Recipient email address
        from_email: Sender email address
        from_name: Sender display name
        subject: Email subject line
        html_content: HTML email content
        smtp_settings: SMTP server configuration
        attachment_path: Path to file attachment (optional)
        cid_image_path: Path to image for CID embedding (optional)
    
    MIME Structure for CID images:
        multipart/mixed (root)
        ├── multipart/related
        │   ├── multipart/alternative
        │   │   ├── text/plain
        │   │   └── text/html (with cid: reference)
        │   └── image (CID attachment)
        └── other attachments
    """
    msg = MIMEMultipart('mixed')
    msg['Subject'] = subject
    msg['From'] = formataddr((from_name, from_email))
    msg['To'] = to_email
    
    # If CID image is provided, use proper MIME hierarchy
    if cid_image_path and os.path.exists(cid_image_path):
        # Create related container for HTML + embedded image
        msg_related = MIMEMultipart('related')
        
        # Create alternative part for text/plain and text/html
        msg_alternative = MIMEMultipart('alternative')
        
        # Add plain text version (strip HTML tags for fallback)
        import re
        plain_text = re.sub('<[^<]+?>', '', html_content)
        plain_text = re.sub(r'\s+', ' ', plain_text).strip()
        text_part = MIMEText(plain_text, 'plain')
        msg_alternative.attach(text_part)
        
        # Add HTML version with CID reference
        html_part = MIMEText(html_content, 'html')
        msg_alternative.attach(html_part)
        
        # Attach alternative to related container
        msg_related.attach(msg_alternative)
        
        # Attach image with CID reference
        try:
            with open(cid_image_path, 'rb') as img_file:
                img_data = img_file.read()
                img_part = MIMEImage(img_data)
                img_part.add_header('Content-ID', '<email_content_image>')
                img_part.add_header('Content-Disposition', 'inline', filename=os.path.basename(cid_image_path))
                msg_related.attach(img_part)
                logger.info(f"✅ CID image embedded: {os.path.basename(cid_image_path)}")
        except Exception as e:
            logger.error(f"❌ Failed to embed CID image: {str(e)}")
        
        # Attach related container to root message
        msg.attach(msg_related)
    else:
        # Standard HTML email without CID image
        msg_alternative = MIMEMultipart('alternative')
        
        # Add plain text fallback
        import re
        plain_text = re.sub('<[^<]+?>', '', html_content)
        plain_text = re.sub(r'\s+', ' ', plain_text).strip()
        text_part = MIMEText(plain_text, 'plain')
        msg_alternative.attach(text_part)
        
        # Add HTML version
        html_part = MIMEText(html_content, 'html')
        msg_alternative.attach(html_part)
        
        msg.attach(msg_alternative)
    
    # Attach file if provided (regular attachment, not embedded)
    if attachment_path:
        attach_file_to_message(msg, attachment_path)
    
    # SMTP server settings - Use environment variables as defaults
    # Priority: campaign settings > environment variables > defaults
    smtp_host = smtp_settings.get('host', os.getenv('SMTP_HOST', 'localhost'))
    smtp_port = smtp_settings.get('port', int(os.getenv('SMTP_PORT', 25)))
    smtp_user = smtp_settings.get('user', os.getenv('SMTP_USERNAME', ''))
    smtp_pass = smtp_settings.get('pass', os.getenv('SMTP_PASSWORD', ''))
    
    # Create SMTP connection with optional SOCKS proxy support
    server = create_smtp_connection(smtp_host, smtp_port, use_ssl=False)
    
    try:
        if smtp_user and smtp_pass:
            server.starttls()
            server.login(smtp_user, smtp_pass)
        
        server.send_message(msg)
        logger.info(f"SMTP email sent to {to_email}")
    finally:
        server.quit()

def send_email_ses_template(to_email, from_email, template_name, template_data):
    """
    Send templated email using AWS SES API
    
    Args:
        to_email: Recipient email address
        from_email: Sender email address (must be verified in SES)
        template_name: Name of the SES template to use
        template_data: Dictionary of template variables (will be converted to JSON)
    
    Returns:
        Message ID if successful, raises exception on failure
    """
    if not ses_client:
        raise Exception("AWS SES client not initialized. Check AWS credentials.")
    
    try:
        # Convert template data to JSON string
        template_data_json = json.dumps(template_data)
        
        # Send templated email
        response = ses_client.send_templated_email(
            Source=from_email,
            Destination={
                'ToAddresses': [to_email],
                'CcAddresses': [],
                'BccAddresses': []
            },
            ReplyToAddresses=[from_email],
            Template=template_name,
            TemplateData=template_data_json
        )
        
        message_id = response['MessageId']
        logger.info(f"SES template email sent to {to_email}, Message ID: {message_id}")
        return message_id
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        logger.error(f"SES template error ({error_code}): {error_message}")
        raise Exception(f"SES Error: {error_message}")
    except Exception as e:
        logger.error(f"Failed to send SES template email: {str(e)}")
        raise

def send_email(to_email, from_email, from_name, subject, html_content, settings, attachment_path=None, cid_image_path=None):
    """Send email using configured provider (Amazon SES, Resend, or SMTP)
    
    Args:
        to_email: Recipient email address
        from_email: Sender email address
        from_name: Sender display name
        subject: Email subject line
        html_content: HTML email content
        settings: Provider settings
        attachment_path: Path to file attachment (optional)
        cid_image_path: Path to image for CID embedding (optional, SMTP only)
    """
    provider = settings.get('provider', 'smtp').lower()
    
    if provider == 'ses' or provider == 'amazon-ses':
        ses_settings = settings.get('ses_settings', settings)
        if cid_image_path:
            logger.warning("CID image embedding not supported for SES provider, using standard HTML")
        return send_email_ses(to_email, from_email, from_name, subject, html_content, ses_settings, attachment_path)
    
    elif provider == 'resend':
        api_key = settings.get('resend_api_key', os.getenv('RESEND_API_KEY'))
        if not api_key:
            raise Exception("Resend API key not configured")
        if cid_image_path:
            logger.warning("CID image embedding not supported for Resend provider, using standard HTML")
        return send_email_resend(to_email, from_email, from_name, subject, html_content, api_key, attachment_path)
    
    else:  # Default to SMTP for backward compatibility
        smtp_settings = settings.get('smtp_settings', settings)
        return send_email_smtp(to_email, from_email, from_name, subject, html_content, smtp_settings, attachment_path, cid_image_path)

@app.route('/api/sending-status', methods=['GET'])
def get_sending_status():
    """Get current sending status"""
    return jsonify(sending_status)

@app.route('/api/stop-sending', methods=['POST'])
def stop_sending():
    """Stop current sending campaign"""
    global sending_status
    sending_status['active'] = False
    return jsonify({'success': True, 'message': 'Sending stopped'})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get overall statistics"""
    stats = {
        'total_subjects': 0,
        'total_from_emails': 0,
        'total_contacts': 0,
        'total_templates': 0,
        'total_campaigns': 0
    }
    
    if os.path.exists(SUBJECTS_DIR):
        for filename in os.listdir(SUBJECTS_DIR):
            if filename.endswith('.txt'):
                filepath = os.path.join(SUBJECTS_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    stats['total_subjects'] += len([l for l in f if l.strip()])
    
    if os.path.exists(FROM_EMAILS_DIR):
        for filename in os.listdir(FROM_EMAILS_DIR):
            if filename.endswith('.txt'):
                filepath = os.path.join(FROM_EMAILS_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    stats['total_from_emails'] += len([l for l in f if l.strip()])
    
    if os.path.exists(CONTACTS_DIR):
        for filename in os.listdir(CONTACTS_DIR):
            filepath = os.path.join(CONTACTS_DIR, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                stats['total_contacts'] += len([l for l in f if l.strip()])
    
    if os.path.exists(TEMPLATES_DIR):
        stats['total_templates'] = len([f for f in os.listdir(TEMPLATES_DIR) if f.endswith('.html') or f.endswith('.txt')])
    
    if os.path.exists(CAMPAIGNS_DIR):
        stats['total_campaigns'] = len([f for f in os.listdir(CAMPAIGNS_DIR) if f.endswith('.json')])
    
    return jsonify(stats)

# ============================================================
# AWS SES TEMPLATE MANAGEMENT ENDPOINTS
# ============================================================

@app.route('/api/ses/templates', methods=['GET'])
def api_fetch_ses_templates():
    """Fetch all AWS SES templates"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import fetch_ses_templates
        
        templates = fetch_ses_templates()
        return jsonify({'success': True, 'templates': templates})
    except Exception as e:
        logger.error(f"Error fetching SES templates: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ses/templates/<template_name>', methods=['GET'])
def api_get_ses_template(template_name):
    """Get specific AWS SES template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_ses_template
        
        template = get_ses_template(template_name)
        if template:
            return jsonify({'success': True, 'template': template})
        return jsonify({'success': False, 'error': 'Template not found'}), 404
    except Exception as e:
        logger.error(f"Error getting SES template: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ses/templates', methods=['POST'])
def api_create_ses_template():
    """Create new AWS SES template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import create_ses_template
        
        data = request.json
        result = create_ses_template(
            data.get('name'),
            data.get('subject'),
            data.get('html'),
            data.get('text', '')
        )
        return jsonify({'success': result})
    except Exception as e:
        logger.error(f"Error creating SES template: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ses/templates/<template_name>', methods=['PUT'])
def api_update_ses_template(template_name):
    """Update existing AWS SES template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import update_ses_template
        
        data = request.json
        result = update_ses_template(
            template_name,
            data.get('subject'),
            data.get('html'),
            data.get('text')
        )
        return jsonify({'success': result})
    except Exception as e:
        logger.error(f"Error updating SES template: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/send-campaign-ses-template', methods=['POST'])
def send_campaign_ses_template():
    """Send email campaign using AWS SES Template API"""
    global sending_status
    
    data = request.json
    campaign_id = data.get('campaign_id')
    template_name = data.get('template_name')
    from_email = data.get('from_email')
    
    if not campaign_id or not template_name or not from_email:
        return jsonify({'error': 'Missing required parameters: campaign_id, template_name, from_email'}), 400
    
    # Load campaign
    filepath = os.path.join(CAMPAIGNS_DIR, f"{campaign_id}.json")
    if not os.path.exists(filepath):
        return jsonify({'error': 'Campaign not found'}), 404
    
    with open(filepath, 'r', encoding='utf-8') as f:
        campaign = json.load(f)
    
    # Start sending in background thread
    thread = threading.Thread(
        target=send_ses_template_emails_background, 
        args=(campaign, template_name, from_email)
    )
    thread.daemon = True
    thread.start()
    
    return jsonify({'success': True, 'message': 'SES Template campaign sending started'})

def send_ses_template_emails_background(campaign, template_name, from_email):
    """Background task to send emails using AWS SES Template API"""
    global sending_status
    
    try:
        # Import required functions from main.py
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import send_templated_email_ses, generate_random_firstname, generate_random_lastname, generate_random_fullname, generate_random_phone, generate_random_date, generate_random_number
        
        # Load contact list
        contact_file = campaign.get('contact_list', '')
        if not contact_file:
            logger.error("No contact list specified in campaign")
            return
        
        contacts_path = os.path.join(CONTACTS_DIR, contact_file)
        if not os.path.exists(contacts_path):
            logger.error(f"Contact list not found: {contacts_path}")
            return
        
        # Read contacts
        with open(contacts_path, 'r', encoding='utf-8') as f:
            contacts = [line.strip() for line in f if line.strip() and '@' in line]
        
        total = len(contacts)
        if total == 0:
            logger.error("No valid contacts found in contact list")
            return
        
        # Initialize sending status
        sending_status = {
            'is_sending': True,
            'total': total,
            'sent': 0,
            'failed': 0,
            'current_email': '',
            'campaign_name': campaign.get('name', 'Untitled'),
            'method': f'SES Template API ({template_name})'
        }
        
        delay = campaign.get('delay', 1)
        
        logger.info(f"Starting SES Template campaign: {campaign.get('name')} with {total} recipients")
        logger.info(f"Using template: {template_name}, From: {from_email}")
        
        # Send emails to each contact
        for contact_email in contacts:
            try:
                sending_status['current_email'] = contact_email
                
                # Generate random data for template variables
                template_data = {
                    'firstname': generate_random_firstname(),
                    'lastname': generate_random_lastname(),
                    'fullname': generate_random_fullname(),
                    'email': contact_email,
                    'id': str(generate_random_number(10000, 99999)),
                    'randomnumber': str(generate_random_number(1000, 9999)),
                    'phone': generate_random_phone(),
                    'date': generate_random_date()
                }
                
                # Send using SES Template API
                message_id = send_templated_email_ses(
                    to_email=contact_email,
                    from_email=from_email,
                    template_name=template_name,
                    template_data=template_data
                )
                
                if message_id:
                    sending_status['sent'] += 1
                    logger.info(f"✅ Sent to {contact_email} - Message ID: {message_id}")
                else:
                    sending_status['failed'] += 1
                    logger.error(f"❌ Failed to send to {contact_email}")
                
                # Delay between emails
                if delay > 0:
                    time.sleep(delay)
                    
            except Exception as e:
                sending_status['failed'] += 1
                logger.error(f"Error sending to {contact_email}: {str(e)}")
        
        logger.info(f"Campaign completed. Sent: {sending_status['sent']}, Failed: {sending_status['failed']}")
        
    except Exception as e:
        logger.error(f"Error in SES template campaign: {str(e)}")
        sending_status['is_sending'] = False
    finally:
        sending_status['is_sending'] = False

@app.route('/api/ses/templates/<template_name>', methods=['DELETE'])
def api_delete_ses_template(template_name):
    """Delete AWS SES template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import delete_ses_template
        
        result = delete_ses_template(template_name)
        return jsonify({'success': result})
    except Exception as e:
        logger.error(f"Error deleting SES template: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/test-ses-template', methods=['POST'])
def test_ses_template():
    """Test AWS SES template sending"""
    try:
        data = request.json
        to_email = data.get('to_email')
        from_email = data.get('from_email')
        template_name = data.get('template_name')
        template_data = data.get('template_data', {})
        
        if not to_email or not from_email or not template_name:
            return jsonify({'error': 'Missing required fields: to_email, from_email, template_name'}), 400
        
        # Send test email
        message_id = send_email_ses_template(to_email, from_email, template_name, template_data)
        
        return jsonify({
            'success': True,
            'message': 'Test email sent successfully',
            'message_id': message_id
        })
        
    except Exception as e:
        logger.error(f"Test SES template error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================
# ROTATION MANAGEMENT ENDPOINTS
# ============================================================

@app.route('/api/rotation/subjects/status', methods=['GET'])
def api_get_subject_status():
    """Get subject rotation status"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_subject_status
        
        status = get_subject_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/subjects/enable', methods=['POST'])
def api_enable_subjects():
    """Enable subject rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import enable_subjects
        
        result = enable_subjects()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/subjects/disable', methods=['POST'])
def api_disable_subjects():
    """Disable subject rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import disable_subjects
        
        result = disable_subjects()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/templates/status', methods=['GET'])
def api_get_template_rotation_status():
    """Get template rotation status"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_template_rotation_status
        
        status = get_template_rotation_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/templates/enable', methods=['POST'])
def api_enable_template_rotation():
    """Enable template rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import enable_template_rotation
        
        result = enable_template_rotation()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/templates/disable', methods=['POST'])
def api_disable_template_rotation():
    """Disable template rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import disable_template_rotation
        
        data = request.json or {}
        result = disable_template_rotation(data.get('template_name'))
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/attachments/status', methods=['GET'])
def api_get_attachment_rotation_status():
    """Get attachment rotation status"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_attachment_rotation_status
        
        status = get_attachment_rotation_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/attachments/enable', methods=['POST'])
def api_enable_attachment_rotation():
    """Enable attachment rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import enable_attachment_rotation
        
        result = enable_attachment_rotation()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation/attachments/disable', methods=['POST'])
def api_disable_attachment_rotation():
    """Disable attachment rotation"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import disable_attachment_rotation
        
        result = disable_attachment_rotation()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================
# ANTIBOT SECURITY ENDPOINTS
# ============================================================

@app.route('/api/antibot/status', methods=['GET'])
def api_get_antibot_status():
    """Get antibot security status"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_antibot_status
        
        status = get_antibot_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/antibot/enable', methods=['POST'])
def api_enable_antibot():
    """Enable antibot security features"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import enable_antibot
        
        result = enable_antibot()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/antibot/disable', methods=['POST'])
def api_disable_antibot():
    """Disable antibot security features"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import disable_antibot
        
        result = disable_antibot()
        return jsonify({'success': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================
# HTML TO IMAGE CONVERSION ENDPOINTS
# ============================================================

@app.route('/api/html-to-image/status', methods=['GET'])
def api_get_html_to_image_status():
    """Get HTML to image conversion status"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_html_to_image_status
        
        status = get_html_to_image_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/html-to-image/enable', methods=['POST'])
def api_enable_html_to_image():
    """Enable HTML to image conversion for emails"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import enable_html_to_image
        
        result = enable_html_to_image()
        return jsonify({'success': result, 'message': 'HTML to image conversion enabled'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/html-to-image/disable', methods=['POST'])
def api_disable_html_to_image():
    """Disable HTML to image conversion for emails"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import disable_html_to_image
        
        result = disable_html_to_image()
        return jsonify({'success': result, 'message': 'HTML to image conversion disabled'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/html-to-image/settings', methods=['POST'])
def api_set_html_to_image_settings():
    """Set HTML to image conversion settings"""
    try:
        data = request.json
        width = data.get('width', 600)
        quality = data.get('quality', 95)
        insert_links = data.get('insert_links_below_image', True)
        link_title = data.get('link_section_title', 'Important Links:')
        
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import EMAIL_CONFIG
        
        EMAIL_CONFIG['image_width'] = width
        EMAIL_CONFIG['image_quality'] = quality
        EMAIL_CONFIG['insert_links_below_image'] = insert_links
        EMAIL_CONFIG['link_section_title'] = link_title
        
        return jsonify({
            'success': True,
            'message': 'HTML to image settings updated',
            'settings': {
                'width': width,
                'quality': quality,
                'insert_links_below_image': insert_links,
                'link_section_title': link_title
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================
# RANDOM DATA GENERATION ENDPOINTS
# ============================================================

@app.route('/api/random/name', methods=['GET'])
def api_generate_random_name():
    """Generate random name"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import generate_random_fullname
        
        name = generate_random_fullname()
        return jsonify({'success': True, 'name': name})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/random/email', methods=['GET'])
def api_generate_random_email():
    """Generate random email"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import generate_random_email
        
        email = generate_random_email()
        return jsonify({'success': True, 'email': email})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/random/phone', methods=['GET'])
def api_generate_random_phone():
    """Generate random phone number"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import generate_random_phone
        
        phone = generate_random_phone()
        return jsonify({'success': True, 'phone': phone})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================
# TEMPLATE VALIDATION ENDPOINTS
# ============================================================

@app.route('/api/templates/validate', methods=['POST'])
def api_validate_template():
    """Validate HTML template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import validate_template
        
        data = request.json
        is_valid, errors = validate_template(data.get('content', ''))
        return jsonify({'success': True, 'valid': is_valid, 'errors': errors})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/templates/placeholders', methods=['POST'])
def api_get_template_placeholders():
    """Extract placeholders from template"""
    try:
        import sys
        sys.path.insert(0, BASE_DIR)
        from main import get_template_placeholders
        
        data = request.json
        placeholders = get_template_placeholders(data.get('content', ''))
        return jsonify({'success': True, 'placeholders': placeholders})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    # Ensure all directories exist
    for directory in [SUBJECTS_DIR, FROM_EMAILS_DIR, CONTACTS_DIR, TEMPLATES_DIR, CAMPAIGNS_DIR, ATTACHMENTS_DIR]:
        os.makedirs(directory, exist_ok=True)
    
    # Use port 8000 for development (port 5000 is used by frontend)
    # In deployment, gunicorn will bind to port 5000 directly
    port = int(os.getenv('PORT', 8000))
    app.run(host='0.0.0.0', port=port, debug=True)
